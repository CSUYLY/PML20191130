%-------------------------------------------------------------------------%
% Two-dimensional simulation with conventional CFS-PML
%-------------------------------------------------------------------------%
%                             Nov. 29, 2019
%                       Liangyong Yang (PhD student)
%     Institute of Geology and Geophysics, Chinese Academy of Sciences
%                Emails: yangliangyong15@mails.ucas.ac.cn
%-------------------------------------------------------------------------%
%                          ������ (�ڶ���ʿ�о���)
%                      �й���ѧԺ��������������о���
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%


clc;
clear;
close all
warning off
tic;
disp('CFS-PML')

tic

J0=1;

%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%

% CFS-PML

find_kappa=21.25;                    % The optimal value of kappa
find_sigma=0.97;% 2.8;                    % The optimal value of sigma
find_alpha=2.5119e-05;% 1e-10;                    % The optimal value of alpha

%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
% Maybe the word 'cell' equal to 'element', I don't know the difference.

NY_Model=100;                  % Number of simulation region cells in the y direction
NZ_Model=100;                  % Number of simulation region cells in the z direction
NPML_Y=12;                     % Number of PML cells in the y direction
NPML_Z=12;                     % Number of PML cells in the z direction

NY=NPML_Y+NY_Model+NPML_Y;     % Total number of cells in the y direction
NZ=NPML_Z+NZ_Model+NPML_Z;     % Total number of cells in the z direction
DY=1*ones(1,NY);           % length of each cell in the y direction
DZ=1*ones(1,NZ);           % length of each cell in the z direction
%--------------------------------------------------------------------------%
DY(1:NPML_Y)=1;            % PML cell thickness
DY(end-NPML_Y+1:end)=1;

DZ(1:NPML_Z)=1;
DZ(end-NPML_Z+1:end)=1;
%--------------------------------------------------------------------------%
% the absorption performance is not sensitive to PML cell thickness

% DY(1:NPML_Y)=2e-4;
% DY(end-NPML_Y+1:end)=2e-4;
%
% DZ(1:NPML_Z)=2e-4;
% DZ(end-NPML_Z+1:end)=2e-4;
%--------------------------------------------------------------------------%
y_axis=[0,cumsum(DY)]-sum(DY)/2;  % The coordinates of y direction
z_axis=[0,cumsum(DZ)]-sum(DZ)/2;  % The coordinates of z direction
%--------------------------------------------------------------------------%
freq=[1e1,1e2];% logspace(-2,5,8); % The frequency range

NYP=NY+1;            % Total node number in y direction
NZP=NZ+1;            % Total node number in z direction
NP=(NY+1)*(NZ+1);    % Total node number of simulation
NE=NY*NZ;            % Total cell(element) number of simulation
ME=zeros(4,NE);      % Allocate memory % Global node number corresponding to Local node number
%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
rho=5*ones(NZ,NY);   % the resistivity of seawater or copper!

sigma=1./rho;        % Conductivity
%--------------------------------------------------------------------------%
% plot the model including host medium and PML
figure;
set(gcf,'unit','centimeters','position',[10 10 10 10]);% Unit:centimeter

imagesc(cumsum(DY)-(sum(DY(1))+sum(DY))/2,cumsum(DZ)-(sum(DZ(1))+sum(DZ))/2,sigma);
hold on
scatter(mean(y_axis),mean(z_axis),'Markerfacecolor','r')
xlabel('y axis');ylabel('z axis')
colormap jet;axis tight;axis equal
line([y_axis(NPML_Y+1),y_axis(NPML_Y+1)],[z_axis(1),z_axis(end)],'linewidth',1.5);
line([y_axis(NY-NPML_Y+1),y_axis(NY-NPML_Y+1)],[z_axis(1),z_axis(end)],'linewidth',1.5);
line([y_axis(1),y_axis(end)],[z_axis(NPML_Z+1),z_axis(NPML_Z+1)],'linewidth',1.5);
line([y_axis(1),y_axis(end)],[z_axis(NZ-NPML_Z+1),z_axis(NZ-NPML_Z+1)],'linewidth',1.5);

text(mean(y_axis),mean(z_axis)+sum(DZ(end/2:end/2+10)),'Current Source','HorizontalAlignment','center','FontName','Times new roman','FontSize',10)
set(gca,'Linewidth',1.5,'FontName','Times new roman','FontSize',10);

saveas(gcf,['2D Model','.fig'])
print(['2D Model','.tif'],'-dtiffn','-r300')
%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
rho=reshape(rho,1,NE);        % Convert to vector

%--------------------------------------------------------------------------%
eps0=1/(36*pi)*1e-9;          % Vacuum permittivity
miu=4*pi*1e-7;                % Magnetic permeability
%--------------------------------------------------------------------------%
% The ratio of Conduction current to Displacement current
rate=mean(mean(sigma))./(2*pi*freq*eps0);
disp('---------------------------------')
disp('Conduction current/Displacement current:');
disp(rate);
disp('---------------------------------')
%--------------------------------------------------------------------------%
% %Find the global node number corresponding to the local node number of each cell
for IY=1:NY
    for IZ=1:NZ
        N=(IY-1)*NZ+IZ;        % cell(element) number
        N1=(IY-1)*(NZ+1)+IZ;   % Global number of the top left corner of the Nth cell
        ME(1,N)=N1;            % the Global number of the top-left corner of the Nth cell
        ME(2,N)=N1+1;          % the Global number of the bottom-left corner of the Nth cell
        ME(3,N)=N1+1+NZ+1;     % the Global number of the bottom-right corner of the Nth cell
        ME(4,N)=N1+NZ+1;       % the Global number of the top-right corner of the Nth cell
    end
end

t1=ME([1;2;3;4;1;2;3;4;1;2;3;4;1;2;3;4],:); % faster than 'repmat'
t2=ME([1;1;1;1;2;2;2;2;3;3;3;3;4;4;4;4],:);

% Location of each cell
n_DZ=repmat((1:NZ),1,NY);
n_DY=repmat((1:NY),NZ,1);
n_DY=reshape(n_DY,1,NE);

%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
% The element stiffness matrix or mass matrix of cell
K1e_temp_1=[2,1,-1,-2;1,2,-2,-1;-1,-2,2,1;-2,-1,1,2];
K1e_temp_2=[2,-2,-1,1;-2,2,1,-1;-1,1,2,-2;1,-1,-2,2];
K1e_par1=reshape(K1e_temp_1,16,1);
K1e_par2=reshape(K1e_temp_2,16,1);
%--------------------------------------------------------------------------%
% The element stiffness matrix or mass matrix of cell
K2e_temp=[4,2,1,2;2,4,2,1;1,2,4,2;2,1,2,4];
K2e_par=reshape(K2e_temp,16,1);
%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%

for nf=1:length(freq)
    
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    w=2*pi*freq(nf);
    %--------------------------------------------------------------------------%
    wavelength=2*pi/(w*sqrt((miu*eps0/2)*(sqrt(1+(sigma(1)/(w*eps0))^2)+1)));
    skindepth=503*sqrt((1/sigma(1))/freq(nf));
    disp([num2str(freq(nf)),'Hz','--Wavelength--',num2str(wavelength),'m','--Skindepth--',num2str(skindepth),'m'])
    
    %--------------------------------------------------------------------------%
    m=1;
    sigma_max = find_sigma*miu*sqrt(miu/eps0)/DZ(end);  % Maximum sigma value in PML
    kappa_max = find_kappa;                             % Maximum kappa value in PML
    alpha_max = find_alpha;
    %--------------------------------------------------------------------------%
    yekappa = ones(1,NY);                               % Initialize the matrix
    yesigma = zeros(1,NY);                              % Initialize the matrix
    yealpha = zeros(1,NY);                              % Initialize the matrix
    zekappa = ones(1,NZ);                               % Initialize the matrix
    zesigma = zeros(1,NZ);                              % Initialize the matrix
    zealpha = zeros(1,NZ);                              % Initialize the matrix
    %--------------------------------------------------------------------------%
    for i=1:NPML_Z
        distance=(NPML_Z+0.5-i)/NPML_Z;
        zesigma(1,i)=sigma_max*(exp(m*distance)-1);     % Exponential spatial scaling
        zekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
        zealpha(1,i)=alpha_max*(exp(m*(1-distance))-1); % The one is different from above zekappa and zesigma
        % zesigma(1,i)=sigma_max*(distance)^m;          % Linear spatial scaling
        % zekappa(1,i)=1+kappa_max*(distance)^m;
        % zealpha(1,i)=alpha_max*((1-distance))^m;
    end
    for i=NPML_Z+NZ_Model+1:NZ
        distance=(i+0.5-(NPML_Z+NZ_Model+1))/NPML_Z;
        zesigma(1,i)=sigma_max*(exp(m*distance)-1);       % Exponential spatial scaling
        zekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
        zealpha(1,i)=alpha_max*(exp(m*(1-distance))-1);   % The one is different from above zekappa and zesigma
        % zesigma(1,i)=sigma_max*(distance)^m;            % Linear spatial scaling
        % zekappa(1,i)=1+kappa_max*(distance)^m;
        % zealpha(1,i)=alpha_max*((1-distance))^m;
    end
    %--------------------------------------------------------------------------%
    for i=1:NPML_Y
        distance=(NPML_Y+0.5-i)/NPML_Y;
        yesigma(1,i)=sigma_max*(exp(m*distance)-1);       % Exponential spatial scaling
        yekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
        yealpha(1,i)=alpha_max*(exp(m*(1-distance))-1);
        %         yesigma(1,i)=sigma_max*(distance)^m;    % Linear spatial scaling
        %         yekappa(1,i)=1+kappa_max*(distance)^m;
        %         yealpha(1,i)=alpha_max*((1-distance))^m;
    end
    for i=NPML_Y+NY_Model+1:NY
        distance=(i+0.5-(NYP-NPML_Y))/NPML_Y;
        yesigma(1,i)=sigma_max*(exp(m*distance)-1);       % Exponential spatial scaling
        yekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
        yealpha(1,i)=alpha_max*(exp(m*(1-distance))-1);
        %         yesigma(1,i)=sigma_max*(distance)^m;    % Linear spatial scaling
        %         yekappa(1,i)=1+kappa_max*(distance)^m;
        %         yealpha(1,i)=alpha_max*((1-distance))^m;
    end
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    yekappa=repmat(yekappa,NZ,1); % convert one-dim vector to two-dim matrix
    yesigma=repmat(yesigma,NZ,1);
    yealpha=repmat(yealpha,NZ,1);
    
    zekappa=repmat(zekappa',1,NY); % convert one-dim vector to two-dim matrix
    zesigma=repmat(zesigma',1,NY);
    zealpha=repmat(zealpha',1,NY);
    
    
    %                 Sey_origin=yekappa+(sqrt(2)*yesigma./((yealpha+1i).*sqrt(w*eps0*sigma)));
    %                 Sez_origin=zekappa+(sqrt(2)*zesigma./((zealpha+1i).*sqrt(w*eps0*sigma)));
    
    Sey_origin = yekappa+(yesigma./(yealpha+1i*w*eps0));
    Sez_origin = zekappa+(zesigma./(zealpha+1i*w*eps0));
    
    %     Sey_origin = yekappa+(yesigma./(1i*w*eps0));
    %     Sez_origin = zekappa+(zesigma./(1i*w*eps0));
    
    S=zekappa+zesigma./zealpha;
    DY(1)*S(1:NPML_Y)
    
    Sey_origin=reshape(Sey_origin,1,NE);       % Convert to one-dim vector
    Sez_origin=reshape(Sez_origin,1,NE);
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    %     Sez_origin = ones(1,NE);
    %     Sey_origin = ones(1,NE);
    %--------------------------------------------------------------------------%
    %-----------Build K1e------------------------------------------------------%
    alpha=(Sez_origin(1:NE)./Sey_origin(1:NE)).*DZ(n_DZ(1:NE))./(6*DY(n_DY(1:NE)));
    belta=(Sey_origin(1:NE)./Sez_origin(1:NE)).*DY(n_DY(1:NE))./(6*DZ(n_DZ(1:NE)));
    K1e=K1e_par1*alpha+K1e_par2*belta;
    K1=sparse(t1,t2,K1e,NP,NP);% Build K1 Matrix of finite element method; [The 'sparse' is very fast than tradition 'for' loop, very recommended!]
    %-----------Build K2e------------------------------------------------------%
    AREA=DY(n_DY(1:NE)).*DZ(n_DZ(1:NE));
    lambda=(Sey_origin(1:NE).*Sez_origin(1:NE)).*(-w*w*miu*eps0+1i*w*miu*sigma(1:NE));
    K2e=(K2e_par/36)*(AREA(1:NE).*lambda); %[matrix size: 16*NE]
    K2=sparse(t1,t2,K2e,NP,NP);  % S = sparse(i,j,s,m,n,nzmax)<= you can find function 'sparse' for details in Matlab website
    %--------------------------------------------------------------------------%
    %-----------Build K3e------------------------------------------------------%
    K3=sparse(NP,NP);
    %--------------------------------------------------------------------------%
    %-----------Assembly Matrix------------------------------------------------%
    K=K1+K2+K3;
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    P=sparse(NP,1);
    
    P((NY+1)*round(NZ/2)+round((NY+1)/2))=-(1i*w*miu)*(J0); % Add the current source at the center of simulation region
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    % Force the top outer boundary electric field equal to 0 (PEC boundary condition)
    for n_top=1:(NZ+1):NP
        K(n_top,n_top)=K(n_top,n_top)*10^10;
        P(n_top)=0;
    end
    
    % Force the bottom outer boundary electric field equal to 0 (PEC boundary condition)
    for n_top=NZ+1:(NZ+1):NP
        K(n_top,n_top)=K(n_top,n_top)*10^10;
        P(n_top)=0;
    end
    
    % Force the left outer boundary electric field equal to 0 (PEC boundary condition)
    for n_top=1:NZP
        
        K(n_top,n_top)=K(n_top,n_top)*10^10;
        P(n_top)=0;
    end
    
    % Force the right outer boundary electric field equal to 0 (PEC boundary condition)
    for n_top=NP-NZP+1:NP
        K(n_top,n_top)=K(n_top,n_top)*10^10;
        P(n_top)=0;
    end
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    Ex=K\P;  %Solve to get the Electric field value
    %--------------------------------------------------------------------------%
    Ex_CFS_PML(:,nf) = Ex;
    %--------------------------------------------------------------------------%
    Ex_show=reshape(Ex,NZ+1,NY+1); % convert one-dim vector to two-dim matrix, which is easy to show
    %-----------------------------------------------------------------%
    %-----------------------------------------------------------------%
    % Compute the analytical solution
    k_wavenumber=sqrt(-1i*w*miu*sigma(1)); % omega*sqrt(eps0*mu0);
    
    r=y_axis((length(y_axis)+1)/2:end);
    Ez_analysis=-1*(J0*w*miu/4)*besselh(0,2,k_wavenumber*r,0);  % Current and electric field have opposite directions
    %-----------------------------------------------------------------%
    %-----------------------------------------------------------------%
    figure
    set(gcf,'unit','centimeters','position',[3 3 24 8]);% Unit:centimeter
    
    subplot(1,2,1)
    % Plot the y-direction electric field curve through the center of the simulation region
    plot(y_axis(NPML_Y+1:NPML_Y+NY_Model+1),abs(Ex_show(round((NZ+1)/2),NPML_Y+1:NPML_Y+NY_Model+1)),'--','Linewidth',0.8);
    hold on
    plot(r(2:end),abs(Ez_analysis(2:end)),'-.','Linewidth',0.8)
    legend('PML Method','Analytic Solution')
    legend('boxoff')
    xlim([y_axis(NPML_Y+1),y_axis(NPML_Y+NY_Model+1)])
    xlabel('y(m)');ylabel('Electric Field(V/m)')
    title(['Frequency: ',num2str(freq(nf)),' Hz'],'FontName','Times new roman','FontSize',10,'FontWeight','bold')
    set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    %-----------------------------------------------------------------%
    %-----------------------------------------------------------------%
    [Y,Z]=meshgrid(y_axis(NPML_Y+1:NPML_Y+NY_Model+1),z_axis(NPML_Z+1:NPML_Z+NZ_Model+1));
    subplot(1,2,2)
    % Plot the electric field curve of the simulated region
    surf(Y,Z,abs(Ex_show(NPML_Z+1:NPML_Z+NZ_Model+1,NPML_Y+1:NPML_Y+NY_Model+1)),'Edgecolor','none');
    colormap jet
    xlabel('y(m)');ylabel('z(m)');zlabel('Electric Field(V/m)')
    axis tight
    title(['Frequency: ',num2str(freq(nf)),' Hz'],'FontName','Times new roman','FontSize',10,'FontWeight','bold')
    set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    
    saveas(gcf,['2D Electric Field-',num2str(freq(nf)),'Hz','.fig'])
    print(['2D Electric Field-',num2str(freq(nf)),'Hz','.tif'],'-dtiffn','-r300')
    %-----------------------------------------------------------------%
    %-----------------------------------------------------------------%
    % If there exist Data of Grid Extension method, then compare the data of PML with that of Grid Extension method
    if exist('Data_Grid_Extension.mat','file')
        
        load Data_Grid_Extension
        
        % compare the electric field of PML, Grid Extension, and Analytic Solution
        figure
        set(gcf,'unit','centimeters','position',[10 10 8.7 5.5]);% Unit:centimeter
        p1=plot(y_axis((length(y_axis)+1)/2:end),abs(Ex_show(round((NZ+1)/2),(size(Ex_show,2)+1)/2:end)),'k-.x','Markersize',4,...
            'MarkerIndices',[9:24:length(y_axis((length(y_axis)+1)/2:end-NPML_Y)),length(y_axis((length(y_axis)+1)/2:end-NPML_Y))+NPML_Y/3,length(y_axis((length(y_axis)+1)/2:end-NPML_Y))+2*NPML_Y/3],'Linewidth',0.8);
        hold on
        p2=plot(y_axis_Grid_Extension((length(y_axis_Grid_Extension)+1)/2:end-Grid_Extension_Y),abs(Ex_Grid_Extension(nf,(size(Ex_Grid_Extension,2)+1)/2:end-Grid_Extension_Y)),...
            'k-o','Markersize',2,'MarkerFaceColor','k','MarkerIndices',17:24:NY_Model_Grid_Extension/2+1,'Linewidth',0.8);
        hold on
        p3=plot(r(2:end),abs(Ez_analysis(2:end)),'k-+','Markersize',4,'MarkerIndices',24:24:length(r),'Linewidth',0.8);
        hold off
        line([sum(DY(1:end-NPML_Y))-sum(DY)/2,sum(DY(1:end-NPML_Y))-sum(DY)/2],[0,max(max(abs(Ex_show)))],'color','k','Linewidth',0.5)
        text(sum(DY(1:NPML_Y+NY_Model+round(NPML_Y/2)))-sum(DY)/2,max(max(abs(Ex_show)))/2,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',8)
        legend([p1 p2 p3],{'PML Method','Grid Extension','Analytic Solution'},'Location','north','FontSize',8)
        legend('boxoff')
        xlabel('r(m)');ylabel('Electric Field(V/m)');
        % title(['Frequency: ',num2str(freq(nf)),' Hz'],'FontName','Times new roman','FontSize',10,'FontWeight','bold')
        
        xlim([0,y_axis(end)])
        set(gca,'xtick',0:0.1:0.5)
        ylim([0,max(abs(Ex_show(round((NZ+1)/2),(size(Ex_show,2)+1)/2:end)))])
        set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10);
        
        saveas(gcf,['Electrical Field-',num2str(freq(nf)),'Hz','-Curve','.fig'])
        print(['Electrical Field-',num2str(freq(nf)),'Hz','-Curve','.tif'],'-dtiffn','-r300')
        %-----------------------------------------------------------------%
        %-----------------------------------------------------------------%
        % Calculate the relative error of Electric field
        tempA=abs(Ez_analysis(1:end-NPML_Y));
        tempB=abs(Ex_show(round((NZ+1)/2),(end+1)/2:end-NPML_Y));
        tempC=abs(Ex_Grid_Extension(nf,(size(Ex_Grid_Extension,2)+1)/2:(size(Ex_Grid_Extension,2)+1)/2+NY_Model_Grid_Extension/2));
        
        A=(Ez_analysis(1:end-NPML_Y));
        B=(Ex_show(round((NZ+1)/2),(end+1)/2:end-NPML_Y));
        C=(Ex_Grid_Extension(nf,(size(Ex_Grid_Extension,2)+1)/2:(size(Ex_Grid_Extension,2)+1)/2+NY_Model_Grid_Extension/2));
        
        %         Relative_Error_PML=abs(tempB-tempA)./max(tempA);
        Relative_Error_PML=abs(tempB-tempA)./(tempA);
        Relative_Error_Grid_Extension=abs(tempC-tempA)./max(tempA);
        
        figure
        set(gcf,'unit','centimeters','position',[10 10 8.7 5.5]);% Unit:centimeter
        % set(gca,'Position',[0.17,0.22,0.75,0.70])
        plot(y_axis((end+1)/2:end-NPML_Y),20*log10(Relative_Error_PML),'k-.x','Markersize',4,...
            'MarkerIndices',9:24:length(y_axis((length(y_axis)+1)/2:end-NPML_Y)),'Linewidth',0.8);
        %         hold on
        %         plot(y_axis((end+1)/2:end-NPML_Y),20*log10(Relative_Error_Grid_Extension),...
        %             'k-o','Markersize',2,'MarkerFaceColor','k','MarkerIndices',5:12:NY_Model_Grid_Extension/2+1,'Linewidth',0.8);
        %         legend('PML Method','Grid Extension')
        %         legend('boxoff')
        xlim([0,y_axis(end)])
        ylim([-140,0])
        %         set(gca,'xtick',0:0.1:0.5)
        %         set(gca,'ytick',-140:20:0)
        xlabel('r(m)');ylabel('Relative Error(dB)')
        set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10);
        
        saveas(gcf,['Relative Error-',num2str(freq(nf)),'Hz','-Curve','.fig'])
        print(['Relative Error-',num2str(freq(nf)),'Hz','-Curve','.tif'],'-dtiffn','-r300')
        %-----------------------------------------------------------------%
        %-----------------------------------------------------------------%
    else
        figure
        % compare the electric field of PML,  and Analytic Solution
        set(gcf,'unit','centimeters','position',[10 10 8.7 5.5]);% Unit:centimeter
        % set(gca,'Position',[0.17,0.22,0.75,0.70])
        p1=plot(y_axis((length(y_axis)+1)/2:end),abs(Ex_show(round((NZ+1)/2),(size(Ex_show,2)+1)/2:end)),'k-.x','Markersize',4,...
            'MarkerIndices',[9:12:length(y_axis((length(y_axis)+1)/2:end-NPML_Y)),length(y_axis((length(y_axis)+1)/2:end-NPML_Y))+NPML_Y/3+1,length(y_axis((length(y_axis)+1)/2:end-NPML_Y))+2*NPML_Y/3+1],'Linewidth',0.8);
        hold on
        p2=plot(r(2:end),abs(Ez_analysis(2:end)),'k-+','Markersize',4,'MarkerIndices',13:12:length(r),'Linewidth',0.8);
        hold off
        line([sum(DY(1:end-NPML_Y))-sum(DY)/2,sum(DY(1:end-NPML_Y))-sum(DY)/2],[0,max(max(abs(Ex_show)))],'color','k','Linewidth',0.8)
        text(sum(DY(1:NPML_Y+NY_Model+round(NPML_Y/2)))-sum(DY)/2,max(max(abs(Ex_show)))/2,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',8)
        legend([p1 p2],{'PML Method','Analytic Solution'},'Location','northwest','NumColumns',1,'FontSize',8)
        legend('boxoff')
        xlabel('r(m)');ylabel('Electric Field(V/m)');
        % title(['Electrical Field-',num2str(freq(nf)),'Hz'],'FontName','Times new roman','FontSize',20)
        set(gca,'xtick',0:0.1:0.5)
        
        set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10);
        
        saveas(gcf,['Electrical Field-',num2str(freq(nf)),'Hz','-Curve','.fig'])
        print(['Electrical Field-',num2str(freq(nf)),'Hz','-Curve','.tif'],'-dtiffn','-r300')
        %-----------------------------------------------------------------%
        % Calculate the relative error of Electric field between PML and analytic solution
        
        tempA=abs(Ez_analysis(1:end-NPML_Y)); % abs(Ex_Grid_Extension(nf,(size(Ex_Grid_Extension,2)+1)/2-NY_Model/2:(size(Ex_Grid_Extension,2)+1)/2+NY_Model/2));
        tempB=abs(Ex_show(round((NZ+1)/2),(end+1)/2:end-NPML_Y));
        
        %         Relative_Error_PML=abs(tempB-tempA)./max(tempA);
        Relative_Error_PML=abs(tempB-tempA)./(tempA);
        
        figure
        set(gcf,'unit','centimeters','position',[10 10 8.7 5.5]);% Unit:centimeter
        % set(gca,'Position',[0.17,0.22,0.75,0.70])
        plot(y_axis((end+1)/2:end-NPML_Y),20*log10(Relative_Error_PML),'k-.x','Markersize',4,...
            'MarkerIndices',[9:12:length(y_axis((length(y_axis)+1)/2:end-NPML_Y)),length(y_axis((length(y_axis)+1)/2:end-NPML_Y))+NPML_Y/3+1,length(y_axis((length(y_axis)+1)/2:end-NPML_Y))+2*NPML_Y/3+1],'Linewidth',0.8);
        legend('PML Method')
        legend('boxoff')
        xlim([0,0.5])
        set(gca,'xtick',0:0.1:0.5)
        set(gca,'ytick',-140:20:0)
        xlabel('r(m)');ylabel('Relative Error(dB)')
        set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10);
        
        saveas(gcf,['Relative Error-',num2str(freq(nf)),'Hz','-Curve','.fig'])
        print(['Relative Error-',num2str(freq(nf)),'Hz','-Curve','.tif'],'-dtiffn','-r300')
        
    end
end

toc


save Ex_CFS_PML Ex_CFS_PML

%-----------------------------------------------------------------%
%-----------------------------------------------------------------%
