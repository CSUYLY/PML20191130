%-------------------------------------------------------------------------%
% This code is to find the best characteristic parameters of the perfectly
% matched layer of the one-dimensional radiation problem. The boundary
% value problem is solved by the finite element method.By comparing with 
% the analytical solution of the radiated electric field of a
% one-dimensional infinitely large energized plate, we find the maximum 
% error under different parameters to obtain the optimal parameters kappa,
% sigma and alpha. In this study the conduction current is much larger than
% the displacement current, and the electromagnetic wave in the medium
% follows the diffusion equation.
%-------------------------------------------------------------------------%
%                             Nov. 29, 2019
%                       Liangyong Yang (PhD student)
%     Institute of Geology and Geophysics, Chinese Academy of Sciences
%                Emails: yangliangyong15@mails.ucas.ac.cn
%-------------------------------------------------------------------------%
%                          ������ (�ڶ���ʿ�о���)
%                      �й���ѧԺ��������������о���
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Output:
% the smallest element value in the matrix, the ordinate are:
%     49    55    52
% 
% recommended kappa is:
%    -1.0400
% 
% recommended sigma is:
%     2.0240
% 
% recommended alpha is:
%     1.6120
% 
% minimum error is:
%    5.1907e-05
% 
% minimum error (dB) is:
%   -85.6955
%-------------------------------------------------------------------------%

clc;
clear;
close all

NM=100;                             % Number of cells in the simulation region
NPML=12;                            % Number of cells in the each side PML region
NE=NPML+NM+NPML;                    % Total number of cells
NP=NE+1;                            % Total number of nodes
DZ=20*ones(1,NE);                   % length of each cell

%--------------------------------------------------------------------------%
find_kappa_range=linspace(-2.0,0,101);       % range of parameter kappa
find_sigma_range=linspace(1.7,2.3,101);      % range of parameter sigma
find_alpha_range=linspace(1.0,2.2,101);      % range of parameter alpha
%--------------------------------------------------------------------------%

Data=zeros(length(find_kappa_range),length(find_sigma_range),length(find_alpha_range));  %Record relative errors of different sigma and alpha

for n_kappa=1:length(find_kappa_range)
    
    disp(n_kappa) % Displace current kappa value
    
    for n_sigma=1:length(find_sigma_range)
        for n_alpha=1:length(find_alpha_range)
            
            
            %---------------------------------%
            %---------------------------------%
            find_kappa=find_kappa_range(n_kappa); %  Possible kappa value in the kappa range
            find_sigma=find_sigma_range(n_sigma); %  Possible sigma value in the sigma range
            find_alpha=find_alpha_range(n_alpha); %  Possible alpha value in the alpha range
            %---------------------------------%
            %---------------------------------%
            z_axis=[0,cumsum(DZ)]-sum(DZ)/2;      % The coordinates of z direction
            
            eps0=1/(36*pi)*1e-9;                  % Vacuum permittivity
            eps1=1;                               % Relative permittivity
            miu=4*pi*1e-7;                        % Magnetic permeability
            %---------------------------------%
            J0=1;                                 % Current magnitude
            %---------------------------------%
            %---------------------------------%
            rho=1000*ones(1,NE);                  % The background Resistivity
            sigma=1./rho;                         % The background Conductivity
            %---------------------------------%
            freq=logspace(-3,3,10);               % The frequency range
            %---------------------------------%
            % Storage the node number of cell
            ME=zeros(2,NE);
            
            for i=1:NE
                ME(1,i)=i;
                ME(2,i)=i+1;
            end
            %---------------------------------%
            
            t1=ME([1;2;1;2],:);  % faster than 'repmat'
            t2=ME([1;1;2;2],:);
            
            % The element stiffness matrix or mass matrix of cell
            K1e_temp=[1,-1;-1,1];
            K1e_temp=reshape(K1e_temp,4,1);
            K1e_par(:,1:NE)=K1e_temp./DZ(1:NE);
            % The element stiffness matrix or mass matrix of cell
            K2e_temp=[1/3,1/6;1/6,1/3];
            K2e_temp=reshape(K2e_temp,4,1);
            K2e_par(:,1:NE)=K2e_temp.*DZ(1:NE);
            %--------------------------------------%
            %--------------------------------------%
            % PML Method
            %--------------------------------------%
            Ex=zeros(NP,length(freq)); %Initialization  matrix of electric field
            
            r_distance=z_axis((length(z_axis)+1)/2:end-NPML); % z range of calcaluting analytic solution
            E_analysis=zeros(length(r_distance),length(freq));
            %--------------------------------------%
            
            for nf=1:length(freq)
                
                f=freq(nf);
                w=2*pi*f;
                
                %--------------------------------------%
                %--------------------------------------%
                %--------------------------------------%
                m=1;
                sigma_max = find_sigma*miu*sqrt(miu/eps0)/DZ(end);  % Maximum sigma value in PML
                kappa_max = find_kappa;                         % Maximum kappa value in PML
                alpha_max = find_alpha;                         % *freq(nf)^(-0.5); %Maximum alpha value in PML, it needs to be greater than 0, and need to be multiplied by freq(nf)^(-0.5) when there is a Direchlet condition.
                %--------------------------------------%
                
                zekappa = ones(1,NE);                           % Initialize the matrix
                zesigma = zeros(1,NE);                          % Initialize the matrix
                zealpha = zeros(1,NE);                          % Initialize the matrix
                
                for i=1:NPML    % The left side PML
                    distance=(NPML+0.5-i)/NPML;                     % Normalized distance
                    zesigma(1,i)=sigma_max*(exp(m*distance)-1);     % Exponential spatial scaling
                    zekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
                    zealpha(1,i)=alpha_max*(exp(m*(1-distance))-1); % The one is different from above zekappa and zesigma
                    % zesigma(1,i)=sigma_max*(distance)^m;          % Linear spatial scaling
                    % zekappa(1,i)=1+kappa_max*(distance)^m;
                    % zealpha(1,i)=alpha_max*((1-distance))^m;
                end
                
                for i=NPML+NM+1:NE     % The right side PML
                    distance=(i-0.5-(NPML+NM))/NPML;                % Normalized distance
                    zesigma(1,i)=sigma_max*(exp(m*distance)-1);     % Exponential spatial scaling
                    zekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
                    zealpha(1,i)=alpha_max*(exp(m*(1-distance))-1); % The one is different from above zekappa and zesigma
                    % zesigma(1,i)=sigma_max*(distance)^m;          % Linear spatial scaling
                    % zekappa(1,i)=1+kappa_max*(distance)^m;
                    % zealpha(1,i)=alpha_max*((1-distance))^m;
                end
                
                
                Sez_origin = zekappa+(sqrt(2)*zesigma./((zealpha+1i).*sqrt(w*eps0.*sigma))); % Construct the key PML parameter
                %--------------------------------------%
                %---------------Build K1e--------------%
                
                K1e=(1./Sez_origin(1:NE)).*K1e_par;
                K1=sparse(t1,t2,K1e,NP,NP); % Build K1 Matrix of finite element method; [The 'sparse' is very fast than tradition 'for' loop, very recommended!]
                
                %---------------Build K2e--------------%
                
                K2e=Sez_origin(1:NE).*(-w*w*miu*eps0+1i*w*miu*sigma).*K2e_par;
                K2=sparse(t1,t2,K2e,NP,NP); % Build K2 Matrix of finite element method; [The 'sparse' is very fast than tradition 'for' loop, very recommended!]
                
                %--------------------------------------%
                %---------------Build K3e--------------%
                K3=sparse(NP,NP);
                
                %------------Assembly matrix-----------%
                v=K1+K2+K3;
                %--------------------------------------%
                P=sparse(NP,1);
                P(round(NP/2))=-(1i*w*miu)*(J0); % Add the current source at the center of simulation region
                %--------------------------------------%
                % This Method is slow
                % Set the perfect electrical conductor at the both outmost side
                %             P(1)=0;
                %             v(:,1)=0;v(1,:)=0;v(1,1)=1;
                %
                %             P(NP)=0;
                %             v(:,NP)=0;v(NP,:)=0;v(NP,NP)=1;
                %--------------------------------------%
                % Set the perfect electrical conductor at the both outmost side
                % This method is fast
                Bid=[1,NP];
                for i=1:length(Bid)
                    v(Bid(i),Bid(i))=v(Bid(i),Bid(i))*10^10;
                    P(Bid(i))=v(Bid(i),Bid(i))*0;
                end
                %---------------------------------------------------%
                Ex(:,nf)=v\P; % Compute the electric field
                %---------------------------------------------------%
                % Compute the analytical solution
                Z=sqrt(1i*w*miu*rho(1));
                k=sqrt(-1i*w*miu*sigma(1));
                
                E_analysis(:,nf)=-1*(Z/2)*J0*exp(-1i*k*r_distance);  % Current and electric field have opposite directions
                %---------------------------------------------------%
                
            end
            
            Exs_FEM=Ex((size(Ex,1)+1)/2:end-NPML,:); % Only compare the field value of right side to current source
            
            Relative_Error=abs(abs(Exs_FEM)-abs(E_analysis))./max(abs(E_analysis)); % compute the the relative error
            
            % maybe you can have other standard, such as sum(sum(20*log10(Relative_Error)))
            Data(n_kappa,n_sigma,n_alpha)=max(max(Relative_Error)); % record the maximum value of the  relative error
            
        end
    end
end



min_x=min(Data(:));% calculates the minimum value of the Data matrix

s=size(Data) ;% calculates the size of the Data matrix

Lin=find(Data<=min_x);% calculates the single subscript of the minimum position

[i,j,k]=ind2sub(s,Lin);% converts the minimum single subscript to a three-dimensional multi-subscript

disp('---------------------------------------------------------------------');
disp('the smallest element value in the matrix, the ordinate are:');disp([i,j,k]);
disp('recommended kappa is:');disp(find_kappa_range(i))
disp('recommended sigma is:');disp(find_sigma_range(j))
disp('recommended alpha is:');disp(find_alpha_range(k))
disp('minimum error is:');disp(min_x);
disp('minimum error (dB) is:');disp(20*log10(min_x));
disp('---------------------------------------------------------------------');

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
[x,y,z]=meshgrid(find_sigma_range,find_kappa_range,find_alpha_range);

figure
set(gcf,'unit','centimeters','position',[10 10 8.7 6.5]);% Unit:centimeter
% slice(x,y,z,20*log10(Data),find_sigma_range(j),find_kappa_range(i),find_alpha_range(k),'EdgeColor','none');
h=slice(x,y,z,20*log10(Data),find_sigma_range(j),find_kappa_range(i),find_alpha_range(k));
set(h, 'EdgeColor', 'none');
view(90+45,25)
colorbar;
% colormap jet
xlabel('\sigma_{max}');ylabel('\kappa_{max}');zlabel('\alpha_{max}')

set(gca,'xtick',1.7:0.2:2.3)
set(gca,'ytick',-2:0.5:0)
set(gca,'ztick',1.0:0.3:2.2)
axis square
axis tight

set(gca,'Linewidth',0.8,'Fontname','Times new roman','Fontsize',10)

saveas(gcf,'Figure1.fig')
print(['Figure1','.tif'],'-dtiffn','-r300')

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%




