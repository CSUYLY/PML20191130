%--------------------------------------------------------------------------%
% ��ص����ά���ݳ��򣻽ṹ������ʸ������Ԫ
% ���ߣ�������
% ���ڣ�20171019
%--------------------------------------------------------------------------%
%
% clear;
clc;
close all;
warning off
disp('��ͳ��')
disp('�õ��������֣���')
disp('��������������޸ĳ�����PMLģ��һ�������񣡣�Ϊ�����һ����һ�γ��������պ���Բ���һά����Ԫ������ǿ�����絼�ʵ�һ�γ���')
% profile on -memory
%--------------------------------------------------------------------------%
eps0=1/(36*pi)*1e-9;       % ��ս�糣��
miu0=pi*4e-7;               % ��մŵ�ϵ��
%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%

solve_choice=1; % solve_choice=1ʱֱ����⣨�죬���ڴ棬��ȷ����solve_choice=2ʱ������⣨���������ڴ棬����ȷ����
maxit=5000; % ����������

N_MODEL_X=12;   % X������������ˮƽ����       % ��������
N_MODEL_Y=12;   % Y��������������ֱֽ������   % ��ż����
N_MODEL_Z=12;   % Z��������������ֱ����       % ��������

Grid_extend_X = 24;
Grid_extend_Y = 24;
Grid_extend_Z = 24;
% Grid_extend_X = 8;
% Grid_extend_Y = 8;
% Grid_extend_Z = 8;

NX=N_MODEL_X+2*Grid_extend_X;   % X������������ˮƽ����       % ��������
NY=N_MODEL_Y+2*Grid_extend_Y;   % Y��������������ֱֽ������   % ��ż����
NZ=N_MODEL_Z+2*Grid_extend_Z;     % Z��������������ֱ����       % ��������
%----------------------------------------------------------------------------------------%
%----------------------------------------------------------------------------------------%
% freq=logspace(-3,3,7);
freq=0.1;% [0.01,1];
%----------------------------------------------------------------------------------------%
%----------------------------------------------------------------------------------------%
main_dx=250; %X�������Ҫ������
main_dy=250; %Y�������Ҫ������
main_dz=250; %Z�������Ҫ������

% extend_DX=250*2.00.^(1:Grid_extend_X);
% extend_DY=250*2.00.^(1:Grid_extend_Y);
% extend_DZ=250*2.00.^(1:Grid_extend_Z);
extend_DX=250*1.25.^(1:Grid_extend_X);
extend_DY=250*1.25.^(1:Grid_extend_Y);
extend_DZ=250*1.25.^(1:Grid_extend_Z);

DX=[fliplr(extend_DX),main_dx*ones(1,N_MODEL_X),extend_DX]; % X����������ʷ����
DY=[fliplr(extend_DY),main_dy*ones(1,N_MODEL_Y),extend_DY]; % Y����������ʷ����
DZ=[fliplr(extend_DZ),main_dz*ones(1,N_MODEL_Z),extend_DZ];
%----------------------------------------------------------------------------------------%
%----------------------------------------------------------------------------------------%
x_axis=cumsum(DX)-DX/2-max(cumsum(DX))/2; % x����ڵ�����
y_axis=[0,cumsum(DY)]-max(cumsum(DY))/2;  % y����Ԫ��������
z_axis=[0,cumsum(DZ)]-sum(DZ(1:Grid_extend_Z));  % x����ڵ�����
%--------------------------------------------------------------------------%
NE=NX*NY*NZ;  % �ܵ�Ԫ��
NP=(NX+1)*(NY+1)*(NZ+1); % �ܽڵ���
%--------------------------------------------------------------------------%
sigma_background=(1/100);

rho_background=1/sigma_background;
%-------------------------------------------------------------------------%
sigma_b=sigma_background*ones(NX,NY,NZ);        % �������ʵĵ絼��
sigma=sigma_b;
%--------------------------------------------------------------------------%
sigma(NX/2-1:NX/2+2,NY/2-1:NY/2+2,Grid_extend_Z+5:Grid_extend_Z+8)=1/0.5;  % �쳣��ĵ絼��
%--------------------------------------------------------------------------%
sigma_b=reshape(sigma_b,[],1);
sigma=reshape(sigma,[],1);
%--------------------------------------------------------------------------%
Point=zeros(NP,3);  % ÿ���ڵ������

Point(:,1)=repmat(([0,cumsum(DX)]-sum(DX)/2)',NP/(NX+1),1);  % ÿ���ڵ��X����
Point(:,2)=repmat(reshape(repmat([0,cumsum(DY)]-sum(DY)/2,NX+1,1),[],1),NZ+1,1);  % ÿ���ڵ��Y����
Point(:,3)=reshape(repmat([0,cumsum(DZ)]-sum(DZ(1:Grid_extend_Z)),(NX+1)*(NY+1),1),[],1);  % ÿ���ڵ��Z����
%--------------------------------------------------------------------------%
NE_DX=zeros(1,NE); % ÿ����Ԫ�ĳ���
NE_DY=zeros(1,NE); % ÿ����Ԫ�Ŀ���
NE_DZ=zeros(1,NE); % ÿ����Ԫ�ĸ߶�
T=zeros(NE,8);     % ÿ����Ԫ��Ӧ��8���ڵ��ȫ�ֱ�ţ���±�123ҳ
for k=1:NZ
    for j=1:NY
        for i=1:NX
            %--------------------------------------------------------------%
            T((k-1)*NX*NY+(j-1)*NX+i,1)=(k-1)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i;   %ÿ����Ԫ1�Žڵ��ȫ�ֱ��
            T((k-1)*NX*NY+(j-1)*NX+i,2)=(k-1)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i+1; %ÿ����Ԫ2�Žڵ��ȫ�ֱ��
            T((k-1)*NX*NY+(j-1)*NX+i,3)=(k-1)*(NX+1)*(NY+1)+(j)*(NX+1)+i+1;   %ÿ����Ԫ3�Žڵ��ȫ�ֱ��
            T((k-1)*NX*NY+(j-1)*NX+i,4)=(k-1)*(NX+1)*(NY+1)+(j)*(NX+1)+i;     %ÿ����Ԫ4�Žڵ��ȫ�ֱ��
            T((k-1)*NX*NY+(j-1)*NX+i,5)=(k)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i;     %ÿ����Ԫ5�Žڵ��ȫ�ֱ��
            T((k-1)*NX*NY+(j-1)*NX+i,6)=(k)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i+1;   %ÿ����Ԫ6�Žڵ��ȫ�ֱ��
            T((k-1)*NX*NY+(j-1)*NX+i,7)=(k)*(NX+1)*(NY+1)+(j)*(NX+1)+i+1;     %ÿ����Ԫ7�Žڵ��ȫ�ֱ��
            T((k-1)*NX*NY+(j-1)*NX+i,8)=(k)*(NX+1)*(NY+1)+(j)*(NX+1)+i;       %ÿ����Ԫ8�Žڵ��ȫ�ֱ��
            %--------------------------------------------------------------%
            NE_DX((k-1)*NX*NY+(j-1)*NX+i)=DX(i);  %ÿ����Ԫ��X���򳤶�
            NE_DY((k-1)*NX*NY+(j-1)*NX+i)=DY(j);  %ÿ����Ԫ��Y���򳤶�
            NE_DZ((k-1)*NX*NY+(j-1)*NX+i)=DZ(k);  %ÿ����Ԫ��Z���򳤶�
            %--------------------------------------------------------------%
        end
    end
end

%--------------------------------------------------------------------------%
% ����ģ��ʾ��ͼ
MESH_plot_rho(NX,NY,NZ,DX,DY,DZ,Grid_extend_X,Grid_extend_Y,Grid_extend_Z,sigma,sigma_background,Point,T)
%--------------------------------------------------------------------------%
EDGE=zeros(NE,12); % ÿ����Ԫ��12���������Ӧ��ȫ����߱��
%----------------------------%
for k=1:NZ
    for i=1:NX
        for j=1:NY
            L1=(k-1)*NX*(NY+1)+(j-1)*NX+i;  %���õ�Ԫ��1����ߡ�
            L2=(k-1)*NX*(NY+1)+j*NX+i;      %���õ�Ԫ��2����ߡ�
            L3=k*NX*(NY+1)+(j-1)*NX+i;      %���õ�Ԫ��3����ߡ�
            L4=k*NX*(NY+1)+j*NX+i;          %���õ�Ԫ��4����ߡ�
            
            EDGE((k-1)*(NX*NY)+(j-1)*(NX)+i,[1,2,3,4])=[L1,L2,L3,L4]; % ��װ
        end
    end
end

clear L1 L2 L3 L4
%----------------------------%
for k=1:NZ
    for i=1:NX
        for j=1:NY
            L5=NX*(NY+1)*(NZ+1)+(k-1)*NY*(NX+1)+(i-1)*NY+j;  %���õ�Ԫ��5����ߡ�
            L6=NX*(NY+1)*(NZ+1)+k*NY*(NX+1)+(i-1)*NY+j;      %���õ�Ԫ��6����ߡ�
            L7=NX*(NY+1)*(NZ+1)+(k-1)*NY*(NX+1)+i*NY+j;      %���õ�Ԫ��7����ߡ�
            L8=NX*(NY+1)*(NZ+1)+k*NY*(NX+1)+i*NY+j;          %���õ�Ԫ��8����ߡ�
            
            EDGE((k-1)*(NX*NY)+(j-1)*(NX)+i,[5,6,7,8])=[L5,L6,L7,L8]; % ��װ
        end
    end
end

clear L5 L6 L7 L8
%----------------------------%
for k=1:NZ
    for i=1:NX
        for j=1:NY
            L9=(2*NX*NY+NX+NY)*(NZ+1)+(k-1)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i;    %���õ�Ԫ��9����ߡ�
            L10=(2*NX*NY+NX+NY)*(NZ+1)+(k-1)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i+1; %���õ�Ԫ��10����ߡ�
            L11=(2*NX*NY+NX+NY)*(NZ+1)+(k-1)*(NX+1)*(NY+1)+(j)*(NX+1)+i;     %���õ�Ԫ��11����ߡ�
            L12=(2*NX*NY+NX+NY)*(NZ+1)+(k-1)*(NX+1)*(NY+1)+(j)*(NX+1)+i+1;   %���õ�Ԫ��12����ߡ�
            
            EDGE((k-1)*(NX*NY)+(j-1)*(NX)+i,[9,10,11,12])=[L9,L10,L11,L12];
        end
    end
end

clear L9 L10 L11 L12
%----------------------------%
%--------------------------------------------------------------------------%
NUM_EDGE=(2*NX*NY+NX+NY)*(NZ+1)+(NX+1)*(NY+1)*NZ;  % �������Ŀ
%--------------------------------------------------------------------------%

Top_E=1:NX*NY; % ����߽絥Ԫ
Bottom_E=NX*NY*(NZ-1)+1:NX*NY*NZ;              % ����߽絥Ԫ
Front_E=zeros(NZ,NX);          % ǰ��߽絥Ԫ
Behind_E=zeros(NZ,NX);         % ����߽絥Ԫ
Left_E=zeros(NZ,NY);           % ����߽絥Ԫ
Right_E=zeros(NZ,NY);          % ����߽絥Ԫ
for i=1:NZ
    Front_E(i,:)=NX*NY-NX+1+(i-1)*(NX*NY):NX*NY+(i-1)*(NX*NY);  %ǰ��
    Behind_E(i,:)=1+(i-1)*(NX*NY):NX+(i-1)*(NX*NY);             %����
    Left_E(i,:)=1+(i-1)*(NX*NY):NX:NX*NY-NX+1+(i-1)*(NX*NY);    %����
    Right_E(i,:)=NX+(i-1)*(NX*NY):NX:NX*NY+(i-1)*(NX*NY);       %����
end
%--------------------------------------------------------------------------%
Top_x=unique(EDGE(Top_E,[1,2]));               % ����߽絥Ԫx����ǿ�ӵĵ�
Bottom_x=unique(EDGE(Bottom_E,[3,4]));         % ����߽絥Ԫx����ǿ�ӵĵ�
Front_x=unique(EDGE(Front_E,[2,4]));           % ǰ��߽絥Ԫx����ǿ�ӵĵ�
Behind_x=unique(EDGE(Behind_E,[1,3]));         % ����߽絥Ԫx����ǿ�ӵĵ�
Left_x=unique(EDGE(Left_E,[1,2,3,4]));         % ����߽絥Ԫx����ǿ�ӵĵ�
Right_x=unique(EDGE(Right_E,[1,2,3,4]));       % ����߽絥Ԫx����ǿ�ӵĵ�

Top_y=unique(EDGE(Top_E,[5,7]));               % ����߽絥Ԫy����ǿ�ӵĵ�
Bottom_y=unique(EDGE(Bottom_E,[6,8]));         % ����߽絥Ԫy����ǿ�ӵĵ�
Left_y=unique(EDGE(Left_E,[5,6]));             % ����߽絥Ԫy����ǿ�ӵĵ�
Right_y=unique(EDGE(Right_E,[7,8]));           % ����߽絥Ԫy����ǿ�ӵĵ�
Front_y=unique(EDGE(Front_E,[5,6,7,8]));       % ǰ��߽絥Ԫy����ǿ�ӵĵ�
Behind_y=unique(EDGE(Behind_E,[5,6,7,8]));     % ����߽絥Ԫy����ǿ�ӵĵ�

Left_z=unique(EDGE(Left_E,[9,11]));            % ����߽絥Ԫz����ǿ�ӵĵ�
Right_z=unique(EDGE(Right_E,[10,12]));         % ����߽絥Ԫz����ǿ�ӵĵ�
Front_z=unique(EDGE(Front_E,[11,12]));         % ǰ��߽絥Ԫz����ǿ�ӵĵ�
Behind_z=unique(EDGE(Behind_E,[9,10]));        % ����߽絥Ԫz����ǿ�ӵĵ�
Top_z=unique(EDGE(Top_E,[9,10,11,12]));        % ����߽絥Ԫz����ǿ�ӵĵ�
Bottom_z=unique(EDGE(Bottom_E,[9,10,11,12]));  % ����߽絥Ԫz����ǿ�ӵĵ�

All_outer_x=unique([Top_x;Bottom_x;Front_x;Behind_x;Left_x;Right_x]);
All_outer_y=unique([Top_y;Bottom_y;Left_y;Right_y;Front_y;Behind_y]);
All_outer_z=unique([Right_z;Left_z;Front_z;Behind_z;Top_z;Bottom_z]);

outer_x=unique([Top_x;Bottom_x;Front_x;Behind_x]);
outer_y=unique([Top_y;Bottom_y;Left_y;Right_y]);
outer_z=unique([Right_z;Left_z;Front_z;Behind_z]);

EDGE_all_x=unique(EDGE(:,1:4));  % ����x���
EDGE_all_y=unique(EDGE(:,5:8));  % ����y���
EDGE_all_z=unique(EDGE(:,9:12)); % ����z���
%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
Exyz=zeros(NUM_EDGE,1);         % �糡ʸ��
%--------------------------------------------------------------------------%
t1=EDGE(:,repmat((1:12)',12,1))'; %ÿ����Ԫ��Ke��Me��װ��K��M����Ҫ������
t2=EDGE(:,reshape(repmat(1:12,12,1),[],1))';%ÿ����Ԫ��Ke��Me��װ��K��M����Ҫ������
%--------------------------------------------------------------------------%
% �ܶ��ص�������������ĺ���ϸ������ϸע����
K1=[2,-2,1,-1;-2,2,-1,1;1,-1,2,-2;-1,1,-2,2];
K2=[2,1,-2,-1;1,2,-1,-2;-2,-1,2,1;-1,-2,1,2];
K3=[2,1,-2,-1;-2,-1,2,1;1,2,-1,-2;-1,-2,1,2];
%--------------------------------------------------------------------------%
Me_11=[8,4,4,2;4,8,2,4;4,2,8,4;2,4,4,8];

M1e14=zeros(12,12);M1e14(1:4,1:4)=Me_11;
M1e58=zeros(12,12);M1e58(5:8,5:8)=Me_11;
M1e912=zeros(12,12);M1e912(9:12,9:12)=Me_11;

M1e14=reshape(M1e14,144,1);
M1e58=reshape(M1e58,144,1);
M1e912=reshape(M1e912,144,1);
%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
Ex_show_Primary_in_Z_direction=zeros(NZ+1,length(freq));
Ex_show_Secondary_in_Z_direction=zeros(NZ+1,length(freq));
Ex_show_Secondary_in_X_direction=zeros(NX,length(freq));
Ex_show_Secondary_in_Y_direction=zeros(NY+1,length(freq));
%--------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
E_Analytical=Analytical_Solution_Function(z_axis,freq,rho_background);
%-------------------------------------------------------------------------%
Ex_secondary_show_2D_YZ_nf=zeros(NZ+1,NY+1,length(freq));
Ex_secondary_show_2D_XZ_nf=zeros(NZ+1,NX,length(freq));

Ex_second_show_Traditional_nf=cell(length(freq));
Ex_show_Traditional_nf=cell(length(freq));
Ey_show_Traditional_nf=cell(length(freq));
Ez_show_Traditional_nf=cell(length(freq));
%-------------------------------------------------------------------------%
tic;

for nf=1:length(freq)
    
    disp('----------------------------')
    disp('��ǰ����Ƶ�ʣ�');
    disp([num2str(freq(nf)),'Hz']);
    disp('----------------------------')
    disp('�������:')
    disp([num2str(503*sqrt((1/sigma_background)/freq(nf))),'m'])
    disp('----------------------------')
    disp('���ؾ���:')
    disp([num2str(sum(extend_DX)),'m'])
    disp('----------------------------')
    disp('���ؾ�����������ȵļ���:')
    disp(num2str(sum(extend_DX)./(503*sqrt((1/sigma_background)/freq(nf)))));
    disp('----------------------------')
    %--------------------------------------------------------------------------%
    
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    omega=2*pi*freq(nf);            % ��Ƶ��
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    Ex_analysis=E_Analytical(nf,:);
    Ex_analysis=repmat(reshape(Ex_analysis,1,1,NZ+1),NY+1,NX);
    Ex_analysis=reshape(Ex_analysis,1,[]);
    
    Ey_analysis=zeros(1,(NX+1)*NY*(NZ+1));
    Ez_analysis=zeros(1,(NX+1)*(NY+1)*NZ);
    
    E_primary=[Ex_analysis,Ey_analysis,Ez_analysis];
    E_primary=E_primary.';
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    Sex_origin=ones(1,NE);
    Sey_origin=ones(1,NE);
    Sez_origin=ones(1,NE);
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    Ke=zeros(144,NE);
    for i=1:NE
        
        Ke1212=zeros(12,12);
        
        
        Ke1212(1:4,1:4)   = (Sez_origin(i)/(Sex_origin(i)*Sey_origin(i)))*(NE_DX(i)*NE_DZ(i)/6/NE_DY(i))*K1+(Sey_origin(i)/(Sez_origin(i)*Sex_origin(i)))*(NE_DX(i)*NE_DY(i)/6/NE_DZ(i))*K2;   %Eexx
        Ke1212(5:8,5:8)   = (Sex_origin(i)/(Sey_origin(i)*Sez_origin(i)))*(NE_DY(i)*NE_DX(i)/6/NE_DZ(i))*K1+(Sez_origin(i)/(Sex_origin(i)*Sey_origin(i)))*(NE_DY(i)*NE_DZ(i)/6/NE_DX(i))*K2;   %Eeyy
        Ke1212(9:12,9:12) = (Sey_origin(i)/(Sez_origin(i)*Sex_origin(i)))*(NE_DZ(i)*NE_DY(i)/6/NE_DX(i))*K1+(Sex_origin(i)/(Sey_origin(i)*Sez_origin(i)))*(NE_DZ(i)*NE_DX(i)/6/NE_DY(i))*K2;   %Eezz
        
        Ke1212(1:4,5:8)=(Sez_origin(i)/(Sex_origin(i)*Sey_origin(i)))*(-NE_DZ(i)/6)*K3;
        Ke1212(5:8,1:4)=(Sez_origin(i)/(Sex_origin(i)*Sey_origin(i)))*(-NE_DZ(i)/6)*K3';
        Ke1212(5:8,9:12)=(Sex_origin(i)/(Sey_origin(i)*Sez_origin(i)))*(-NE_DX(i)/6)*K3;
        Ke1212(9:12,5:8)=(Sex_origin(i)/(Sey_origin(i)*Sez_origin(i)))*(-NE_DX(i)/6)*K3';
        Ke1212(9:12,1:4)=(Sey_origin(i)/(Sez_origin(i)*Sex_origin(i)))*(-NE_DY(i)/6)*K3;
        Ke1212(1:4,9:12)=(Sey_origin(i)/(Sez_origin(i)*Sex_origin(i)))*(-NE_DY(i)/6)*K3';
        
        Ke(:,i)= reshape(Ke1212,144,1);
        
    end
    
    K=sparse(t1,t2,Ke,NUM_EDGE,NUM_EDGE); % ��װK����
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    Me=zeros(144,NE);
    for i=1:NE
        
        Me_temp=zeros(12,12);
        
        Me_temp(1:4,1:4)  = Sey_origin(i)*Sez_origin(i)/Sex_origin(i)*(1i*omega*miu0*sigma(i)+omega*omega*miu0*eps0)*Me_11;
        Me_temp(5:8,5:8)  = Sez_origin(i)*Sex_origin(i)/Sey_origin(i)*(1i*omega*miu0*sigma(i)+omega*omega*miu0*eps0)*Me_11;
        Me_temp(9:12,9:12)= Sex_origin(i)*Sey_origin(i)/Sez_origin(i)*(1i*omega*miu0*sigma(i)+omega*omega*miu0*eps0)*Me_11;
        
        Me1212=(NE_DX(i)*NE_DY(i)*NE_DZ(i)/72)*Me_temp;
        Me(:,i)= reshape(Me1212,144,1);
        
    end
    
    M=sparse(t1,t2,Me,NUM_EDGE,NUM_EDGE); % ��װM����
    %--------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    % Fast
    Kpe1212_14 =  M1e14 .*(Sey_origin(1:NE).*Sez_origin(1:NE)./Sex_origin(1:NE)).*(1i*omega*miu0*(sigma(1:NE)'-sigma_b(1:NE)')).*(NE_DX(1:NE).*NE_DY(1:NE).*NE_DZ(1:NE)/72);
    
    Kpe1212_58 =  M1e58 .*(Sez_origin(1:NE).*Sex_origin(1:NE)./Sey_origin(1:NE)).*(1i*omega*miu0*(sigma(1:NE)'-sigma_b(1:NE)')).*(NE_DX(1:NE).*NE_DY(1:NE).*NE_DZ(1:NE)/72);
    
    Kpe1212_912 = M1e912.*(Sex_origin(1:NE).*Sey_origin(1:NE)./Sez_origin(1:NE)).*(1i*omega*miu0*(sigma(1:NE)'-sigma_b(1:NE)')).*(NE_DX(1:NE).*NE_DY(1:NE).*NE_DZ(1:NE)/72);
    
    Kpe = Kpe1212_14+Kpe1212_58+Kpe1212_912;
    
    Kp=sparse(t1,t2,Kpe,NUM_EDGE,NUM_EDGE); % ��װK����
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    
    %--------------------------------------------------------------------------%
    % �ײ�������߽�����
    % �����桿
    W=sparse(NUM_EDGE,NUM_EDGE);    % ͨ������
    
    for i=1:length(Bottom_E)
        k_wavenum=sqrt(-1i*omega*miu0*sigma(Bottom_E(i)));  % ϣ����ĸ
        We=k_wavenum*(NE_DX(Bottom_E(i))*NE_DY(Bottom_E(i))/6)*[2,1,0,0;1,2,0,0;0,0,2,1;0,0,1,2]; % ͬʱ������x���򼫻���������y���򼫻�������
        % W(EDGE(Bottom_E(i),[1,2,5,7]),EDGE(Bottom_E(i),[1,2,5,7]))=W(EDGE(Bottom_E(i),[1,2,5,7]),EDGE(Bottom_E(i),[1,2,5,7]))+We(1:4,1:4);
        W(EDGE(Bottom_E(i),[3,4,6,8]),EDGE(Bottom_E(i),[3,4,6,8]))=W(EDGE(Bottom_E(i),[3,4,6,8]),EDGE(Bottom_E(i),[3,4,6,8]))+We(1:4,1:4);
    end
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    HH=K-M+W;
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    P=Kp*E_primary;
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    % ǿ�ӵ�һ��߽�������Դ��
    
    for i=1:length(outer_x)
        HH(outer_x(i),outer_x(i))=HH(outer_x(i),outer_x(i))*10^10; % 10^5 ��ֵ���˹���
        P(outer_x(i))=0;
    end
    
    for i=1:length(outer_y)
        HH(outer_y(i),outer_y(i))=HH(outer_y(i),outer_y(i))*10^10; % 10^5 ��ֵ���˹���
        P(outer_y(i))=0;
    end
    
    for i=1:length(outer_z) % ����Ҫ
        HH(outer_z(i),outer_z(i))=HH(outer_z(i),outer_z(i))*10^10;
        P(outer_z(i))=0;
    end
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    disp('��ʼ��⵱ǰƵ�ʵķ�����:');
    disp('�ȴ�...');
    
    if solve_choice==1
        %-------------------------------------------------------------------------%
        % ��ֱ����ⷨ��
        disp('ֱ����ⷨ��')
        Exyz_secondary=HH\P;
        %-------------------------------------------------------------------------%
        
    else
        
        %--------------------------------------------------------------------------%
        % ��������ⷨ��
        tol=1e-40;  % �������
        
        %--------------------------------------------------------------------------%
        % SSORԤ������bicgstab�����ⷨ(by ������)
        Dinv=sparse(1:length(HH),1:length(HH),diag(HH));
        ww=1; %���ɳ�����
        M=(ww*(tril(HH)-Dinv)+Dinv)/sqrt(Dinv)/sqrt(ww*(2-ww));
        disp('Bicgstab��ⷨ��')
        [Exyz_secondary,fl0,rr0,it0,rv0] =bicgstab(HH,P,tol,maxit,M,M.');
        %         disp('QMR��ⷨ��')
        %         [Exyz_secondary,fl0,rr0,it0,rv0] =qmr(HH,P,tol,maxit,M,M.');
        %--------------------------------------------------------------------------%
        figure
        semilogy(rv0/norm(P),'-'); %
        xlabel('Iteration number');
        ylabel('Relative residual');
        %--------------------------------------------------------------------------%
    end
    
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    Exyz=Exyz_secondary+E_primary;
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    EDGE_all_x_show=reshape(EDGE_all_x,[],1);
    Ex_show = Exyz(EDGE_all_x_show);
    Ex_show = full(Ex_show);
    Ex_show = reshape(Ex_show,NX,NY+1,NZ+1);
    
    EDGE_all_y_show=reshape(EDGE_all_y,[],1);
    Ey_show = Exyz(EDGE_all_y_show);
    Ey_show = full(Ey_show);
    Ey_show = reshape(Ey_show,NY,NX+1,NZ+1);
    
    EDGE_all_z_show=reshape(EDGE_all_z,[],1);
    Ez_show = Exyz(EDGE_all_z_show);
    Ez_show = full(Ez_show);
    Ez_show = reshape(Ez_show,NX+1,NY+1,NZ);
    
    Ex_second_show=Exyz_secondary(EDGE_all_x_show);
    Ex_second_show=full(Ex_second_show);
    Ex_second_show = reshape(Ex_second_show,NX,NY+1,NZ+1);
    %--------------------------------------------------------------------------%
    Ex_second_show_Traditional_nf{nf}=Ex_second_show;
    Ex_show_Traditional_nf{nf}=Ex_show;
    Ey_show_Traditional_nf{nf}=Ey_show;
    Ez_show_Traditional_nf{nf}=Ez_show;
    %--------------------------------------------------------------------------%
    Ex_secondary_show_2D_YZ=reshape(Ex_second_show(round((NX+1)/2),:,:),NY+1,NZ+1);
    Ex_secondary_show_2D_YZ=Ex_secondary_show_2D_YZ.';
    
    Ex_secondary_show_2D_XZ=reshape(Ex_second_show(:,round((NY+1)/2),:),NX,NZ+1);
    Ex_secondary_show_2D_XZ=Ex_secondary_show_2D_XZ.';
    %--------------------------------------------------------------------------%
    % Analytic Solution
    Ex_analysis_1D=E_Analytical(nf,:);
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    Ex_secondary_show_2D_YZ_nf(:,:,nf)=Ex_secondary_show_2D_YZ;
    Ex_secondary_show_2D_XZ_nf(:,:,nf)=Ex_secondary_show_2D_XZ;
    
    %     gcf=figure;
    %     set(gcf,'position',[150,100,1200,600])
    %
    %     subplot(1,2,1)
    %     surf(abs(Ex_secondary_show_2D_YZ));
    %     colormap jet
    %     colorbar
    %     xlabel('y(m)')
    %     ylabel('z(m)')
    %     axis tight
    %     axis ij
    %     title(['The secondary Ex filed-',num2str(freq(nf)),'Hz'],'FontSize',10,'FontWeight','bold')
    %     set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    %
    %     subplot(1,2,2)
    %     surf(abs(Ex_secondary_show_2D_XZ));
    %     colormap jet
    %     colorbar
    %     xlabel('x(m)')
    %     ylabel('z(m)')
    %     axis tight
    %     axis ij
    %     title(['The secondary Ex filed-',num2str(freq(nf)),'Hz'],'FontSize',10,'FontWeight','bold')
    %     set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    %
    %     saveas(gcf,[strrep(['The Ex Field of Z-Y & Z-X planes-',num2str(freq(nf)),'Hz','-Traditional Grid Extension Method' ],'.','dot'),'.fig'])
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    Ex_show_Primary_in_Z_direction(:,nf)=reshape(Ex_show(round((NX+1)/2),round((NY+1)/2),:),[],1);
    Ex_show_Secondary_in_Z_direction(:,nf)=reshape(Ex_second_show(round((NX+1)/2),round((NY+1)/2),:),[],1);
    %--------------------------------------------------------------------------%
    %     gcf=figure;
    %     set(gcf,'position',[150,100,1200,600])
    %
    %     subplot(2,2,1)
    %     plot(z_axis(Grid_extend_Z+1:Grid_extend_Z+N_air+N_MODEL_Z+1),abs(Ex_show_Primary_in_Z_direction(Grid_extend_Z+1:Grid_extend_Z+N_air+N_MODEL_Z+1,nf)),'-o','Linewidth',1);
    %     hold on
    %     plot(z_axis(Grid_extend_Z+1:Grid_extend_Z+N_air+N_MODEL_Z+1),abs(Ex_analysis_1D(Grid_extend_Z+1:Grid_extend_Z+N_air+N_MODEL_Z+1)),':d','Linewidth',1);
    %     legend ('with anomaly', 'uniform half-space')
    %     legend('boxoff')
    %     xlabel('z(m)');ylabel('Magnitude');
    %     title(['Ex Total Field in z direction','-',num2str(freq(nf)),'Hz'],'FontSize',10,'FontWeight','bold')
    %     set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    %     %--------------------------------------------------------------------------%
    %
    %     subplot(2,2,2)
    %     plot(abs(Ex_show_Secondary_in_Z_direction(:,nf)),'-o','Linewidth',1);
    %     line([Grid_extend_Z+1,Grid_extend_Z+1],[0,1],'color','k')
    %     line([NZ-Grid_extend_Z+1,NZ-Grid_extend_Z+1],[0,1],'color','k')
    %     xlabel('z(m)');ylabel('Magnitude');
    %     title(['Ex Secondary Field in z direction','-',num2str(freq(nf)),'Hz'],'FontSize',10,'FontWeight','bold')
    %     set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    %--------------------------------------------------------------------------%
    Ex_show_Secondary_in_Y_direction(:,nf)=abs(Ex_secondary_show_2D_YZ(Grid_extend_Z+7,:));
    Ex_show_Secondary_in_X_direction(:,nf)=abs(Ex_secondary_show_2D_XZ(Grid_extend_Z+7,:));
    
    %     subplot(2,2,3)
    %     plot(Ex_show_Secondary_in_Y_direction(:,nf),'-o','Linewidth',1);
    %     line([Grid_extend_Y+1,Grid_extend_Y+1],[0,1],'color','k')
    %     line([NY-Grid_extend_Y+1,NY-Grid_extend_Y+1],[0,1],'color','k')
    %     xlabel('y(m)');ylabel('Magnitude');
    %     set(gca,'Linewidth',1)
    %     title(['Ex Secondary Field-y direction-depth:',num2str(sum(DZ(1:10-1))),'m'],'FontSize',10,'FontWeight','bold')
    %     set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    %     %--------------------------------------------------------------------------%
    %     subplot(2,2,4)
    %     plot(Ex_show_Secondary_in_X_direction(:,nf),'-o','Linewidth',1);
    %     line([Grid_extend_X+0.5,Grid_extend_X+0.5],[0,1],'color','k')
    %     line([NX-Grid_extend_X+0.5,NX-Grid_extend_X+0.5],[0,1],'color','k')
    %     xlabel('x(m)');ylabel('Magnitude');
    %     set(gca,'Linewidth',1)
    %     title(['Ex Secondary Field-x direction-depth:',num2str(sum(DZ(1:10-1))),'m','-',num2str(freq(nf)),'Hz'],'FontSize',10,'FontWeight','bold')
    %     set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    %
    %     saveas(gcf,[strrep(['The Electric Field Curves-',num2str(freq(nf)),'Hz','-Traditional Grid Extension Method' ],'.','dot'),'.fig'])
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    %     [X,Y,Z]=meshgrid(1:NY+1,1:NX,1:NZ+1);
    %
    %     gcf=figure;
    %     set(gcf,'position',[150,100,1200,600])
    %
    %     subplot(2,2,1)
    %     slice(X,Y,Z,abs(Ex_show),[round((NY+1)/2)],[round((NX+1)/2)],[round(NZ/2)])
    %     xlabel('y(m)')
    %     ylabel('x(m)')
    %     axis tight
    %     set(gca,'zdir','reverse')
    %     title('Ex-Total Field','FontSize',10,'FontWeight','bold')
    %     set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    %     colorbar
    %     colormap jet
    %     %--------------------------------------------------------------------------%
    %     %--------------------------------------------------------------------------%
    %     subplot(2,2,2)
    %
    %     slice(X,Y,Z,abs(Ex_second_show),[round((NY+1)/2)],[round((NX+1)/2)],[round(NZ/2)])
    %     xlabel('y(m)')
    %     ylabel('x(m)')
    %     axis tight
    %     set(gca,'zdir','reverse')
    %     title('Ex-Second Field','FontSize',10,'FontWeight','bold')
    %     set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    %     colorbar
    %     colormap jet
    %     %--------------------------------------------------------------------------%
    %     subplot(2,2,3)
    %
    %     slice(abs(Ey_show),[round(NX/2)],[round(NY/2)],[round(NZ/2)])
    %     xlabel('x(m)')
    %     ylabel('y(m)')
    %     set(gca,'zdir','reverse')
    %     axis tight
    %     title('Ey-Total Field','FontSize',10,'FontWeight','bold')
    %     set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    %     colorbar
    %     colormap jet
    %     %--------------------------------------------------------------------------%
    %     subplot(2,2,4)
    %
    %     slice(abs(Ez_show),[round(NY/2)],[round(NX/2)],[round(NZ/2)])
    %     set(gca,'zdir','reverse')
    %     xlabel('y(m)')
    %     ylabel('x(m)')
    %     axis tight
    %     title('Ez-Total Field','FontSize',10,'FontWeight','bold')
    %     set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    %     colorbar
    %     colormap jet
    %
    %     saveas(gcf,[strrep(['The Electric Field Slices-',num2str(freq(nf)),'Hz','-Traditional Grid Extension Method' ],'.','dot'),'.fig'])
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    
    
    disp('���������')
    disp('-------------------------')
    
end

toc

%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%


x_axis_traditional=x_axis;
y_axis_traditional=y_axis;
z_axis_traditional=z_axis;
NX_traditional =NX;
NY_traditional =NY;
NZ_traditional =NZ;
DX_traditional =DX;
DY_traditional =DY;
DZ_traditional =DZ;


save FM_traditional_Data...
    x_axis_traditional y_axis_traditional z_axis_traditional...
    NX_traditional NY_traditional NZ_traditional Grid_extend_X Grid_extend_Y Grid_extend_Z...
    DX_traditional DY_traditional DZ_traditional extend_DX extend_DY extend_DZ...
    Ex_show_Primary_in_Z_direction Ex_show_Secondary_in_Z_direction Ex_show_Secondary_in_Y_direction...
    Ex_show_Secondary_in_X_direction...
    Ex_secondary_show_2D_XZ_nf Ex_secondary_show_2D_YZ_nf
