clc;clear;close all

load workspace

[X,Y]=meshgrid(x_axis(NPML_Y+1:end-NPML_Y),y_axis(NPML_X+1:end-NPML_X));

for nf=1:length(freq)
    
    gcf=figure;
    set(gcf,'unit','centimeters','position',[5 5 16.8 10.5]);% Unit:centimeter
    
    subplot(2,3,1)
    surfc(X,Y,pc_ALL(NPML_X+1:end-NPML_X,NPML_Y+1:end-NPML_Y,nf));
    xlabel('\it{x}\rm{(m)}');ylabel('\it{y}\rm{(m)}');zlabel('Apparent Resistivity(\Omega\cdotm)')
    % box on
    title('(a)')
    if freq(nf)<=1
        zlim([0,150])
        set(gca,'ztick',0:50:150)
    elseif freq(nf)>1
        zlim([0,120])
        set(gca,'ztick',0:40:120)
    end
    xlim([-2000,2000])
    set(gca,'xtick',[-2000,0,2000])
    set(gca,'ytick',[-2000,0,2000])
    %     ytickangle(45)
    %     xtickangle(65)
    % title(['Apparent resistivity-',num2str(freq(nf)),'Hz',],'Fontname','Times new roman')
    set(gca,'Linewidth',0.8,'Fontname','Times new roman','Fontsize',10)%
    set(gca,'Position',[0.079,0.587,0.195,0.367])
    %-------------------------------------------------------------------------%
    subplot(2,3,2)
    plot(x_axis(NPML_Y+1:end-NPML_Y),(pc_ALL(round((NY+1+1)/2),NPML_Y+1:end-NPML_Y,nf)),'-o','Markersize',1.5,'color',[0.85,0.33,0.1],'Markerfacecolor',[0.85,0.33,0.1],'Markeredgecolor',[0.85,0.33,0.1],'Linewidth',0.8)
    hold on
    plot(x_axis_traditional(1:end),(pc_ALL_traditional(round((NY_traditional+1)/2),1:end,nf)),':o','Markersize',4.5,'color',[0,0.45,0.74],'Linewidth',0.8)
    legend('PML Method','Grid Extension','Location','best')
    legend('boxoff')
    xlim([-4000,4000])
    if freq(nf)==10
        ylim([0,110])
    end
    xlabel('\it{x}\rm{(m)}');ylabel('\rho_{a}(\Omega\cdotm)')
    % axis tight
    title('(b)')
    % title(['The Apparent resistivity-\it{y }\rm{direction(in the middle)}'],'Fontname','Times new roman')
    set(gca,'Linewidth',0.8,'Fontname','Times new roman','Fontsize',10)%
    set(gca,'Position',[0.372,0.603,0.254,0.34])
    %-------------------------------------------------------------------------%
    subplot(2,3,3)
    plot(y_axis(NPML_X+1:end-NPML_X),(pc_ALL(NPML_X+1:end-NPML_X,round((NX+1)/2),nf)),'-o','Markersize',1.5,'color',[0.85,0.33,0.1],'Markerfacecolor',[0.85,0.33,0.1],'Markeredgecolor',[0.85,0.33,0.1],'Linewidth',0.8)
    hold on
    plot(y_axis_traditional(1:end),(pc_ALL_traditional(1:end,round((NX_traditional+1)/2),nf)),':o','Markersize',4.5,'color',[0,0.45,0.74],'Linewidth',0.8)
    legend('PML Method','Grid Extension','Location','north','Fontsize',8)
    legend('boxoff')
    xlim([-4000,4000])
    ylim([0,120])
    if freq(nf)==10
        ylim([0,125])
    end
    xlabel('\it{y}\rm{(m)}');ylabel('\rho_{a}(\Omega\cdotm)')
    % axis tight
    title('(c)')
    % title(['The Phase-\it{x }\rm{direction(in the middle)}'],'Fontname','Times new roman')
    set(gca,'Linewidth',0.8,'Fontname','Times new roman','Fontsize',10)%
    set(gca,'Position',[0.722,0.603,0.254,0.34])
    %-------------------------------------------------------------------------%
    subplot(2,3,4)
    surfc(X,Y,phase_ALL(NPML_X+1:end-NPML_X,NPML_Y+1:end-NPML_Y,nf));
    % box on
    xlabel('\it{x}\rm{(m)}');ylabel('\it{y}\rm{(m)}');zlabel('Phase(��)')
    xlim([-2000,2000])
    set(gca,'xtick',[-2000,0,2000])
    set(gca,'ytick',[-2000,0,2000])
    %     ytickangle(45)
    %     xtickangle(55)
    title('(d)')
    if freq(nf)==0.1
        zlim([-60,-40])
    elseif freq(nf)==10
        zlim([-70,-40])
    end
    % title(['Phase-',num2str(freq(nf)),'Hz',],'Fontname','Times new roman')
    set(gca,'Linewidth',0.8,'Fontname','Times new roman','Fontsize',10)%
    set(gca,'Position',[0.074,0.078,0.204,0.373])
    %-------------------------------------------------------------------------%
    subplot(2,3,5)
    plot(x_axis(NPML_Y+1:end-NPML_Y),(phase_ALL(round((NY+1+1)/2),NPML_Y+1:end-NPML_Y,nf)),'-o','Markersize',1.5,'color',[0.85,0.33,0.1],'Markerfacecolor',[0.85,0.33,0.1],'Markeredgecolor',[0.85,0.33,0.1],'Linewidth',0.8)
    hold on
    plot(x_axis_traditional(1:end),(phase_ALL_traditional(round((NY_traditional+1)/2),1:end,nf)),':o','Markersize',4.5,'color',[0,0.45,0.74],'Linewidth',0.8)
    legend('PML Method','Grid Extension','Location','best')
    legend('boxoff')
    xlim([-4000,4000])
    ylim([min(phase_ALL(round((NY+1+1)/2),NPML_Y+1:end-NPML_Y,nf))-1,max(phase_ALL(round((NY+1+1)/2),NPML_Y+1:end-NPML_Y,nf))+1])
    xlabel('\it{x}\rm{(m)}');ylabel('\phi(��)')
    % axis tight
    title('(e)')
    if freq(nf)==0.1
        ylim([-60,-40])
    elseif freq(nf)==10
        ylim([-70,-40])
    end
    % title(['The Apparent resistivity-\it{y }\rm{direction(in the middle)}'],'Fontname','Times new roman')
    set(gca,'Linewidth',0.8,'Fontname','Times new roman','Fontsize',10)%
    set(gca,'Position',[0.37,0.11,0.254,0.34])
    %-------------------------------------------------------------------------%
    subplot(2,3,6)
    plot(y_axis(NPML_X+1:end-NPML_X),(phase_ALL(NPML_X+1:end-NPML_X,round((NX+1)/2),nf)),'-o','Markersize',1.5,'color',[0.85,0.33,0.1],'Markerfacecolor',[0.85,0.33,0.1],'Markeredgecolor',[0.85,0.33,0.1],'Linewidth',0.8)
    hold on
    plot(y_axis_traditional(1:end),(phase_ALL_traditional(1:end,round((NX_traditional+1)/2),nf)),':o','Markersize',4.5,'color',[0,0.45,0.74],'Linewidth',0.8)
    legend('PML Method','Grid Extension','Location','north','Fontsize',8)
    legend('boxoff')
    xlim([-4000,4000])
    ylim([min(phase_ALL(NPML_X+1:end-NPML_X,round((NX+1)/2),nf))-1,max(phase_ALL(NPML_X+1:end-NPML_X,round((NX+1)/2),nf))+1])
    xlabel('\it{y}\rm{(m)}');ylabel('\phi(��)')
    % axis tight
    title('(f)')
    if freq(nf)==0.1
        ylim([-60,-40])
    elseif freq(nf)==10
        ylim([-70,-40])
    end
    % title(['The Phase-\it{x }\rm{direction(in the middle)}'],'Fontname','Times new roman')
    set(gca,'Linewidth',0.8,'Fontname','Times new roman','Fontsize',10)%
    set(gca,'Position',[0.722,0.11,0.254,0.341])
    %-------------------------------------------------------------------------%
    saveas(gcf,[strrep(['The Apparent Resistivity & Phase Plots',num2str(freq(nf)),'Hz' ],'.','dot'),'.fig'])
    
end


%
% gcf=figure;
% set(gcf,'outerposition',get(0,'screensize'));
%
% for nf=1:length(freq)
%
%     xi=[0 250 500 750 1000 1500 2000];
%     if freq(nf)==0.1
%         PcaverageXY0=[2.08  6.51  50.32  117.5  135.53  130.51 121.04];
%         errorxy=[1.04 1.48 3.03 2.38 1.27 1.40 1.16];
%     elseif freq(nf)==10
%         PcaverageXY0=[14.10  18.13  42.14  97.85  107.01  103.06  99.24];
%         errorxy=[3.96 5.89 15.32 16.20 12.02 4.85 0.55];
%     end
%
%     plot(x_axis(NPML_Y+1:end-NPML_Y),(pc_ALL(round((NY+1+1)/2),NPML_Y+1:end-NPML_Y,nf)),'-*','Linewidth',0.8)
%     hold on
%     plot(x_axis_traditional(NPML_Y+1:end-NPML_Y),(pc_ALL_traditional(round((NY_traditional+1+1)/2),NPML_Y+1:end-NPML_Y,nf)),'-o','Linewidth',0.8)
%     if freq(nf)==0.1||freq(nf)==10
%         hold on
%         errorbar(xi,PcaverageXY0,errorxy,'b','LineStyle','none');
%     end
%     grid on
%     title(['Apparent Resistivity in x Direction-',num2str(freq(nf)),'Hz'],'FontWeight','bold')
%     legend('PML Method','Grid Extension')
%     legend('boxoff')
%     xlim([x_axis_traditional(NPML_Y+1),x_axis_traditional(end-NPML_Y)])
%     % set(gca,'YScale','log');
%     set(gca,'Linewidth',0.8,'Fontname','Times new roman','FontWeight','bold')
%     %-------------------------------------------------------------------------%
% end
%
% gcf=figure;
% set(gcf,'outerposition',get(0,'screensize'));
%
%
%
% for nf=1:length(freq)
%
%     xi=[0 250 500 750 1000 1500 2000];
%     if freq(nf)==0.1
%         PcaverageXY0=[2.08  6.51  50.32  117.5  135.53  130.51 121.04];
%         errorxy=[1.04 1.48 3.03 2.38 1.27 1.40 1.16];
%     elseif freq(nf)==10
%         PcaverageXY0=[14.10  18.13  42.14  97.85  107.01  103.06  99.24];
%         errorxy=[3.96 5.89 15.32 16.20 12.02 4.85 0.55];
%     end
%
%     plot(y_axis(NPML_X+1:end-NPML_X),(pc_ALL(NPML_X+1:end-NPML_X,round((NX+1)/2),nf)),'-*','Linewidth',0.8)
%     hold on
%     plot(y_axis_traditional(NPML_X+1:end-NPML_X),(pc_ALL_traditional(NPML_X+1:end-NPML_X,round((NX_traditional+1)/2),nf)),'-o','Linewidth',0.8)
%     grid on
%     title(['Apparent Resistivity in y Direction',num2str(freq(nf)),'Hz'],'FontWeight','bold')
%     legend('PML Method','Grid Extension')
%     legend('boxoff')
%     xlim([y_axis_traditional(NPML_X+1),y_axis_traditional(end-NPML_X)])
%     % set(gca,'YScale','log');
%     set(gca,'Linewidth',0.8,'Fontname','Times new roman','FontWeight','bold')
%     saveas(gcf,[strrep(['Apparent Resistivity in y Direction-',num2str(freq(nf)),'Hz' ],'.','dot'),'.fig'])
%     %-------------------------------------------------------------------------%
%
% end