%-------------------------------------------------------------------------%
% Three-dimensional Code
%-------------------------------------------------------------------------%
%                             Nov. 29, 2019
%                       Liangyong Yang (PhD student)
%     Institute of Geology and Geophysics, Chinese Academy of Sciences
%                Emails: yangliangyong15@mails.ucas.ac.cn
%-------------------------------------------------------------------------%
%                          ������ (�ڶ���ʿ�о���)
%                      �й���ѧԺ��������������о���
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%


clear;
clc;
close all;
warning off
disp('PML Method')

% profile on -memory

%-------------------------------------------------------------------------%
load FM_traditional_Data
load Ex_show_Secondary_in_Y_direction_CFS_PML
%-------------------------------------------------------------------------%
eps0=1/(36*pi)*1e-9;       % Vacuum dielectric constant
miu0=pi*4e-7;               % Vacuum permeability
%-------------------------------------------------------------------------%
m=1;

find_kappa=3;
find_sigma=0.84;
find_alpha=2.08;

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%

solve_choice=1; % solve_choice=1 solve directly (fast, memory consuming, accurate); solve_choice=2 iterative solve (slow, little memory consuming, inaccurate);
maxit=5000;     % The maximum number of iterations

N_MODEL_X=12;   % Grid number in X direction; horizontal right
N_MODEL_Y=12;   % Grid number in Y direction; vertical paper facing inward
N_MODEL_Z=12;   % Grid number in Z direction; vertical upward

NPML_X = 6;
NPML_Y = 6;
NPML_Z = 6;

NX=N_MODEL_X+2*NPML_X;
NY=N_MODEL_Y+2*NPML_Y;
NZ=N_MODEL_Z+2*NPML_Z;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% freq=logspace(-3,3,7);
freq=0.1;% [0.01,1];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
main_dx=250; % main grid spacing in X direction
main_dy=250; % main grid spacing in Y direction
main_dz=250; % main grid spacing in Z direction

% PML_DX=50;
% PML_DY=50;
% PML_DZ=50;

% PML_DX=5;
% PML_DY=5;
% PML_DZ=5;

PML_DX=5e-2; % PML cell thickness in X direction
PML_DY=5e-2; % PML cell thickness in Y direction
PML_DZ=5e-2; % PML cell thickness in Z direction

DX=[PML_DX*ones(1,NPML_X),main_dx*ones(1,N_MODEL_X),PML_DX*ones(1,NPML_X)];
DY=[PML_DY*ones(1,NPML_Y),main_dy*ones(1,N_MODEL_Y),PML_DY*ones(1,NPML_Y)];
DZ=[PML_DZ*ones(1,NPML_Z),main_dz*ones(1,N_MODEL_Z),PML_DZ*ones(1,NPML_Z)];

% DX=[fliplr(250*1.6.^(1:NPML_X)),main_dx*ones(1,N_MODEL_X),250*1.6.^(1:NPML_X)];
% DY=[fliplr(250*1.6.^(1:NPML_Y)),main_dy*ones(1,N_MODEL_Y),250*1.6.^(1:NPML_Y)];
% DZ=[fliplr(250*1.6.^(1:NPML_Z)),Air_DZ,[5,5,5,235/2,235/2],main_dz*ones(1,N_MODEL_Z-5),250*1.6.^(1:NPML_Z)];

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
x_axis=cumsum(DX)-DX/2-max(cumsum(DX))/2; % Node coordinate in x direction
y_axis=[0,cumsum(DY)]-max(cumsum(DY))/2;  % Element center coordinate in y direction
z_axis=[0,cumsum(DZ)]-sum(DZ(1:NPML_Z));  % Node coordinates in z direction
%-------------------------------------------------------------------------%
NE=NX*NY*NZ;               % Total number of elements
NP=(NX+1)*(NY+1)*(NZ+1);   % Total number of nodes
%-------------------------------------------------------------------------%
sigma_background=(1/100);

rho_background=1/sigma_background;
%-------------------------------------------------------------------------%
sigma_b=sigma_background*ones(NX,NY,NZ);                     % Conductivity of background medium
sigma=sigma_b;
%-------------------------------------------------------------------------%
sigma(NX/2-1:NX/2+2,NY/2-1:NY/2+2,NPML_Z+5:NPML_Z+8)=1/0.5;  % Conductivity of abnormal body
%-------------------------------------------------------------------------%
sigma_b=reshape(sigma_b,[],1);
sigma=reshape(sigma,[],1);
%-------------------------------------------------------------------------%
Point=zeros(NP,3);  % Coordinates of each node

Point(:,1)=repmat(([0,cumsum(DX)]-sum(DX)/2)',NP/(NX+1),1);                         % X coordinate of each node
Point(:,2)=repmat(reshape(repmat([0,cumsum(DY)]-sum(DY)/2,NX+1,1),[],1),NZ+1,1);    % Y coordinate of each node
Point(:,3)=reshape(repmat([0,cumsum(DZ)]-sum(DZ(1:NPML_Z)),(NX+1)*(NY+1),1),[],1);  % Z coordinate of each node
%-------------------------------------------------------------------------%
NE_DX=zeros(1,NE); % Length of each element
NE_DY=zeros(1,NE); % Width of each element
NE_DZ=zeros(1,NE); % Height of each element
T=zeros(NE,8);     % The global number of the 8 nodes corresponding to each element;
for k=1:NZ
    for j=1:NY
        for i=1:NX
            %--------------------------------------------------------------%
            T((k-1)*NX*NY+(j-1)*NX+i,1)=(k-1)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i;   % The global number of node 1 of each element
            T((k-1)*NX*NY+(j-1)*NX+i,2)=(k-1)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i+1; % The global number of node 2 of each element
            T((k-1)*NX*NY+(j-1)*NX+i,3)=(k-1)*(NX+1)*(NY+1)+(j)*(NX+1)+i+1;   % The global number of node 3 of each element
            T((k-1)*NX*NY+(j-1)*NX+i,4)=(k-1)*(NX+1)*(NY+1)+(j)*(NX+1)+i;     % The global number of node 4 of each element
            T((k-1)*NX*NY+(j-1)*NX+i,5)=(k)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i;     % The global number of node 5 of each element
            T((k-1)*NX*NY+(j-1)*NX+i,6)=(k)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i+1;   % The global number of node 6 of each element
            T((k-1)*NX*NY+(j-1)*NX+i,7)=(k)*(NX+1)*(NY+1)+(j)*(NX+1)+i+1;     % The global number of node 7 of each element
            T((k-1)*NX*NY+(j-1)*NX+i,8)=(k)*(NX+1)*(NY+1)+(j)*(NX+1)+i;       % The global number of node 8 of each element
            %--------------------------------------------------------------%
            NE_DX((k-1)*NX*NY+(j-1)*NX+i)=DX(i);      % X-direction length of each element
            NE_DY((k-1)*NX*NY+(j-1)*NX+i)=DY(j);      % Y-direction length of each element
            NE_DZ((k-1)*NX*NY+(j-1)*NX+i)=DZ(k);      % Z-direction length of each element
            %--------------------------------------------------------------%
        end
    end
end

%-------------------------------------------------------------------------%
% Draw the model schematic
MESH_plot_rho(NX,NY,NZ,DX,DY,DZ,NPML_X,NPML_Y,NPML_Z,sigma,sigma_background,Point,T)
set(gca,'xtick',-1500:1500:1500)
set(gca,'ytick',-1500:1500:1500)
saveas(gcf,['Model','.fig'])
print(['Model','.tif'],'-dtiffn','-r300')
%-------------------------------------------------------------------------%
EDGE=zeros(NE,12); % Global edge number corresponding to 12 edges of each element
%----------------------------%
for k=1:NZ
    for i=1:NX
        for j=1:NY
            L1=(k-1)*NX*(NY+1)+(j-1)*NX+i;  % Edge 1 of the element
            L2=(k-1)*NX*(NY+1)+j*NX+i;      % Edge 2 of the element
            L3=k*NX*(NY+1)+(j-1)*NX+i;      % Edge 3 of the element
            L4=k*NX*(NY+1)+j*NX+i;          % Edge 4 of the element
            
            EDGE((k-1)*(NX*NY)+(j-1)*(NX)+i,[1,2,3,4])=[L1,L2,L3,L4]; % Assemble
        end
    end
end

clear L1 L2 L3 L4
%----------------------------%
for k=1:NZ
    for i=1:NX
        for j=1:NY
            L5=NX*(NY+1)*(NZ+1)+(k-1)*NY*(NX+1)+(i-1)*NY+j;  % Edge 5 of the element
            L6=NX*(NY+1)*(NZ+1)+k*NY*(NX+1)+(i-1)*NY+j;      % Edge 6 of the element
            L7=NX*(NY+1)*(NZ+1)+(k-1)*NY*(NX+1)+i*NY+j;      % Edge 7 of the element
            L8=NX*(NY+1)*(NZ+1)+k*NY*(NX+1)+i*NY+j;          % Edge 8 of the element
            
            EDGE((k-1)*(NX*NY)+(j-1)*(NX)+i,[5,6,7,8])=[L5,L6,L7,L8]; % Assemble
        end
    end
end

clear L5 L6 L7 L8
%----------------------------%
for k=1:NZ
    for i=1:NX
        for j=1:NY
            L9=(2*NX*NY+NX+NY)*(NZ+1)+(k-1)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i;    % Edge 9 of the element
            L10=(2*NX*NY+NX+NY)*(NZ+1)+(k-1)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i+1; % Edge 10 of the element
            L11=(2*NX*NY+NX+NY)*(NZ+1)+(k-1)*(NX+1)*(NY+1)+(j)*(NX+1)+i;     % Edge 11 of the element
            L12=(2*NX*NY+NX+NY)*(NZ+1)+(k-1)*(NX+1)*(NY+1)+(j)*(NX+1)+i+1;   % Edge 12 of the element
            
            EDGE((k-1)*(NX*NY)+(j-1)*(NX)+i,[9,10,11,12])=[L9,L10,L11,L12];
        end
    end
end

clear L9 L10 L11 L12
%----------------------------%
%-------------------------------------------------------------------------%
NUM_EDGE=(2*NX*NY+NX+NY)*(NZ+1)+(NX+1)*(NY+1)*NZ;  % Total number of edges
%-------------------------------------------------------------------------%
Top_E=1:NX*NY;                      % Top surface element
Bottom_E=NX*NY*(NZ-1)+1:NX*NY*NZ;   % Bottom surface element
Front_E=zeros(NZ,NX);               % Front surface element
Behind_E=zeros(NZ,NX);              % Behind surface element
Left_E=zeros(NZ,NY);                % Left surface element
Right_E=zeros(NZ,NY);               % Right surface element
for i=1:NZ
    Front_E(i,:)=NX*NY-NX+1+(i-1)*(NX*NY):NX*NY+(i-1)*(NX*NY);  % Front
    Behind_E(i,:)=1+(i-1)*(NX*NY):NX+(i-1)*(NX*NY);             % Behind
    Left_E(i,:)=1+(i-1)*(NX*NY):NX:NX*NY-NX+1+(i-1)*(NX*NY);    % Left
    Right_E(i,:)=NX+(i-1)*(NX*NY):NX:NX*NY+(i-1)*(NX*NY);       % Right
end
%-------------------------------------------------------------------------%
Top_x=unique(EDGE(Top_E,[1,2]));                 % The point imposed on the the outer x-direction of top side element
Bottom_x=unique(EDGE(Bottom_E,[3,4]));
Front_x=unique(EDGE(Front_E,[2,4]));
Behind_x=unique(EDGE(Behind_E,[1,3]));
Left_x=unique(EDGE(Left_E,[1,2,3,4]));
Right_x=unique(EDGE(Right_E,[1,2,3,4]));

Top_y=unique(EDGE(Top_E,[5,7]));
Bottom_y=unique(EDGE(Bottom_E,[6,8]));
Left_y=unique(EDGE(Left_E,[5,6]));
Right_y=unique(EDGE(Right_E,[7,8]));
Front_y=unique(EDGE(Front_E,[5,6,7,8]));
Behind_y=unique(EDGE(Behind_E,[5,6,7,8]));

Left_z=unique(EDGE(Left_E,[9,11]));
Right_z=unique(EDGE(Right_E,[10,12]));
Front_z=unique(EDGE(Front_E,[11,12]));
Behind_z=unique(EDGE(Behind_E,[9,10]));
Top_z=unique(EDGE(Top_E,[9,10,11,12]));
Bottom_z=unique(EDGE(Bottom_E,[9,10,11,12]));

All_outer_x=unique([Top_x;Bottom_x;Front_x;Behind_x;Left_x;Right_x]);
All_outer_y=unique([Top_y;Bottom_y;Left_y;Right_y;Front_y;Behind_y]);
All_outer_z=unique([Right_z;Left_z;Front_z;Behind_z;Top_z;Bottom_z]);

outer_x=unique([Top_x;Bottom_x;Front_x;Behind_x]);
outer_y=unique([Top_y;Bottom_y;Left_y;Right_y]);
outer_z=unique([Right_z;Left_z;Front_z;Behind_z]);

EDGE_all_x=unique(EDGE(:,1:4));  % All x edges
EDGE_all_y=unique(EDGE(:,5:8));  % All y edges
EDGE_all_z=unique(EDGE(:,9:12)); % All z edges
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
Exyz=zeros(NUM_EDGE,1);        % Electric field vector
%-------------------------------------------------------------------------%
t1=EDGE(:,repmat((1:12)',12,1))';               % The coordinates of each element for Ke or Me assembled into K or M
t2=EDGE(:,reshape(repmat(1:12,12,1),[],1))';    % The coordinates of each element for Ke or Me assembled into K or M
%-------------------------------------------------------------------------%
K1=[2,-2,1,-1;-2,2,-1,1;1,-1,2,-2;-1,1,-2,2];
K2=[2,1,-2,-1;1,2,-1,-2;-2,-1,2,1;-1,-2,1,2];
K3=[2,1,-2,-1;-2,-1,2,1;1,2,-1,-2;-1,-2,1,2];
%-------------------------------------------------------------------------%
Me_11=[8,4,4,2;4,8,2,4;4,2,8,4;2,4,4,8];

M1e14=zeros(12,12);M1e14(1:4,1:4)=Me_11;
M1e58=zeros(12,12);M1e58(5:8,5:8)=Me_11;
M1e912=zeros(12,12);M1e912(9:12,9:12)=Me_11;

M1e14=reshape(M1e14,144,1);
M1e58=reshape(M1e58,144,1);
M1e912=reshape(M1e912,144,1);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
Ex_show_Primary_in_Z_direction_PML=zeros(NZ+1,length(freq));
Ex_show_Secondary_in_Z_direction_PML=zeros(NZ+1,length(freq));
Ex_show_Secondary_in_X_direction_PML=zeros(NX,length(freq));
Ex_show_Secondary_in_Y_direction_PML=zeros(NY+1,length(freq));
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
E_Analytical=Analytical_Solution_Function(z_axis,freq,rho_background);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
tic;

for nf=1:length(freq)
    
    disp('-------------------------')
    disp('Current calculation frequency:');
    disp([num2str(freq(nf)),'Hz']);
    
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    omega=2*pi*freq(nf);         % Angular frequency
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    Ex_analysis=E_Analytical(nf,:);
    Ex_analysis=repmat(reshape(Ex_analysis,1,1,NZ+1),NY+1,NX);
    Ex_analysis=reshape(Ex_analysis,1,[]);
    
    Ey_analysis=zeros(1,(NX+1)*NY*(NZ+1));
    Ez_analysis=zeros(1,(NX+1)*(NY+1)*NZ);
    
    E_primary=[Ex_analysis,Ey_analysis,Ez_analysis];
    E_primary=E_primary.';
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    m=1;
    sigma_max = find_sigma*miu0*sqrt(miu0/eps0)/DZ(end);
    kappa_max = find_kappa;%
    alpha_max = find_alpha;%
    %-------------------------------------------------------------------------%
    xekappa = ones(1,NX);
    xesigma = zeros(1,NX);
    xealpha = zeros(1,NX);
    yekappa = ones(1,NY);
    yesigma = zeros(1,NY);
    yealpha = zeros(1,NY);
    zekappa = ones(1,NZ);
    zesigma = zeros(1,NZ);
    zealpha = zeros(1,NZ);
    %-------------------------------------------------------------------------%
    for i=1:NPML_X
        % distance=(NPML_X-i)/(NPML_X-1);
        distance=(NPML_X+0.5-i)/NPML_X;
        xesigma(1,i)=sigma_max*(exp(m*distance)-1);
        xekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
        xealpha(1,i)=alpha_max*(exp(m*(1-distance))-1);
    end
    
    for i=NPML_X+N_MODEL_X+1:NX
        % distance=(i-(NPML_X+N_MODEL_X+1))/(NPML_X-1);
        distance=(i-0.5-(NPML_X+N_MODEL_X))/NPML_X;
        xesigma(1,i)=sigma_max*(exp(m*distance)-1);
        xekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
        xealpha(1,i)=alpha_max*(exp(m*(1-distance))-1);
    end
    
    for i=1:NPML_Y
        % distance=(NPML_Y-i)/(NPML_Y-1);
        distance=(NPML_Y+0.5-i)/NPML_Y;
        yesigma(1,i)=sigma_max*(exp(m*distance)-1);
        yekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
        yealpha(1,i)=alpha_max*(exp(m*(1-distance))-1);
    end
    
    for i=NPML_Y+N_MODEL_Y+1:NY
        % distance=(i-(NPML_Y+N_MODEL_Y+1))/(NPML_Y-1);
        distance=(i-0.5-(NPML_Y+N_MODEL_Y))/NPML_Y;
        yesigma(1,i)=sigma_max*(exp(m*distance)-1);
        yekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
        yealpha(1,i)=alpha_max*(exp(m*(1-distance))-1);
    end
    
    for i=1:NPML_Z
        % distance=(NPML_Z-i)/(NPML_Z-1);
        distance=(NPML_Z+0.5-i)/NPML_Z;
        zesigma(1,i)=sigma_max*(exp(m*distance)-1);
        zekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
        zealpha(1,i)=alpha_max*(exp(m*(1-distance))-1);
    end
    
    for i=NPML_Z+N_MODEL_Z+1:NZ
        % distance=(i-(NPML_Z+N_MODEL_Z+1))/(NPML_Z-1);
        distance=(i-0.5-(NPML_Z+N_MODEL_Z))/NPML_Y;
        zesigma(1,i)=sigma_max*(exp(m*distance)-1);
        zekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
        zealpha(1,i)=alpha_max*(exp(m*(1-distance))-1);
    end
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    
    Sex_origin = xekappa+(sqrt(2)*xesigma./((xealpha-1i).*sqrt(omega*eps0.*sigma_background)));
    Sex_origin = repmat(Sex_origin,[NY,1,NZ]);
    Sex_origin = reshape(permute(Sex_origin,[2,1,3]),1,[]);
    
    Sey_origin = yekappa+(sqrt(2)*yesigma./((yealpha-1i).*sqrt(omega*eps0.*sigma_background)));
    Sey_origin = repmat(Sey_origin.',[1,NX,NZ]);
    Sey_origin = reshape(permute(Sey_origin,[2,1,3]),1,[]);
    
    Sez_origin = zekappa+(sqrt(2)*zesigma./((zealpha-1i).*sqrt(omega*eps0.*sigma_background)));
    Sez_origin = Sez_origin.';
    Sez_origin = repmat(reshape(Sez_origin,1,1,NZ),NY,NX);
    Sez_origin = reshape(Sez_origin,1,[]);
    
    %-------------------------------------------------------------------------%
    %     Sex_origin=ones(1,NE);
    %     Sey_origin=ones(1,NE);
    %     Sez_origin=ones(1,NE);
    %-------------------------------------------------------------------------%
    Ke=zeros(144,NE);
    for i=1:NE
        
        Ke1212=zeros(12,12);
        
        
        Ke1212(1:4,1:4)   = (Sez_origin(i)/(Sex_origin(i)*Sey_origin(i)))*(NE_DX(i)*NE_DZ(i)/6/NE_DY(i))*K1+(Sey_origin(i)/(Sez_origin(i)*Sex_origin(i)))*(NE_DX(i)*NE_DY(i)/6/NE_DZ(i))*K2;   %Eexx
        Ke1212(5:8,5:8)   = (Sex_origin(i)/(Sey_origin(i)*Sez_origin(i)))*(NE_DY(i)*NE_DX(i)/6/NE_DZ(i))*K1+(Sez_origin(i)/(Sex_origin(i)*Sey_origin(i)))*(NE_DY(i)*NE_DZ(i)/6/NE_DX(i))*K2;   %Eeyy
        Ke1212(9:12,9:12) = (Sey_origin(i)/(Sez_origin(i)*Sex_origin(i)))*(NE_DZ(i)*NE_DY(i)/6/NE_DX(i))*K1+(Sex_origin(i)/(Sey_origin(i)*Sez_origin(i)))*(NE_DZ(i)*NE_DX(i)/6/NE_DY(i))*K2;   %Eezz
        
        Ke1212(1:4,5:8)=(Sez_origin(i)/(Sex_origin(i)*Sey_origin(i)))*(-NE_DZ(i)/6)*K3;
        Ke1212(5:8,1:4)=(Sez_origin(i)/(Sex_origin(i)*Sey_origin(i)))*(-NE_DZ(i)/6)*K3';
        Ke1212(5:8,9:12)=(Sex_origin(i)/(Sey_origin(i)*Sez_origin(i)))*(-NE_DX(i)/6)*K3;
        Ke1212(9:12,5:8)=(Sex_origin(i)/(Sey_origin(i)*Sez_origin(i)))*(-NE_DX(i)/6)*K3';
        Ke1212(9:12,1:4)=(Sey_origin(i)/(Sez_origin(i)*Sex_origin(i)))*(-NE_DY(i)/6)*K3;
        Ke1212(1:4,9:12)=(Sey_origin(i)/(Sez_origin(i)*Sex_origin(i)))*(-NE_DY(i)/6)*K3';
        
        Ke(:,i)= reshape(Ke1212,144,1);
        
    end
    
    K=sparse(t1,t2,Ke,NUM_EDGE,NUM_EDGE); % Assemble the K matrix
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    Me=zeros(144,NE);
    for i=1:NE
        
        Me_temp=zeros(12,12);
        
        Me_temp(1:4,1:4)  = Sey_origin(i)*Sez_origin(i)/Sex_origin(i)*(1i*omega*miu0*sigma(i)+omega*omega*miu0*eps0)*Me_11;
        Me_temp(5:8,5:8)  = Sez_origin(i)*Sex_origin(i)/Sey_origin(i)*(1i*omega*miu0*sigma(i)+omega*omega*miu0*eps0)*Me_11;
        Me_temp(9:12,9:12)= Sex_origin(i)*Sey_origin(i)/Sez_origin(i)*(1i*omega*miu0*sigma(i)+omega*omega*miu0*eps0)*Me_11;
        
        Me1212=(NE_DX(i)*NE_DY(i)*NE_DZ(i)/72)*Me_temp;
        Me(:,i)= reshape(Me1212,144,1);
        
    end
    
    M=sparse(t1,t2,Me,NUM_EDGE,NUM_EDGE); % Assemble M matrix
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    % Fast
    Kpe1212_14 =  M1e14 .*(Sey_origin(1:NE).*Sez_origin(1:NE)./Sex_origin(1:NE)).*(1i*omega*miu0*(sigma(1:NE)'-sigma_b(1:NE)')).*(NE_DX(1:NE).*NE_DY(1:NE).*NE_DZ(1:NE)/72);
    
    Kpe1212_58 =  M1e58 .*(Sez_origin(1:NE).*Sex_origin(1:NE)./Sey_origin(1:NE)).*(1i*omega*miu0*(sigma(1:NE)'-sigma_b(1:NE)')).*(NE_DX(1:NE).*NE_DY(1:NE).*NE_DZ(1:NE)/72);
    
    Kpe1212_912 = M1e912.*(Sex_origin(1:NE).*Sey_origin(1:NE)./Sez_origin(1:NE)).*(1i*omega*miu0*(sigma(1:NE)'-sigma_b(1:NE)')).*(NE_DX(1:NE).*NE_DY(1:NE).*NE_DZ(1:NE)/72);
    
    Kpe = Kpe1212_14+Kpe1212_58+Kpe1212_912;
    
    Kp=sparse(t1,t2,Kpe,NUM_EDGE,NUM_EDGE); % Assemble the Kp matrix
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    HH=K-M;
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    P=Kp*E_primary;
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    % Imposed the first type of boundary conditions [source]
    
    for i=1:length(outer_x)
        HH(outer_x(i),outer_x(i))=HH(outer_x(i),outer_x(i))*10^10;
        P(outer_x(i))=0;
    end
    
    for i=1:length(outer_y)
        HH(outer_y(i),outer_y(i))=HH(outer_y(i),outer_y(i))*10^10;
        P(outer_y(i))=0;
    end
    
    for i=1:length(outer_z)
        HH(outer_z(i),outer_z(i))=HH(outer_z(i),outer_z(i))*10^10;
        P(outer_z(i))=0;
    end
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    
    disp('Start solving the system of equations for the current frequency:');
    disp('Waiting...');
    
    if solve_choice==1
        %-------------------------------------------------------------------------%
        disp('Direct solution!')
        Exyz_secondary=HH\P;
        %-------------------------------------------------------------------------%
        
    else
        
        %-------------------------------------------------------------------------%
        % Iterative solution
        tol=1e-40; % Tolerance error
        
        %-------------------------------------------------------------------------%
        % SSOR preprocessed bicgstab iterative solution (by Huang Xiangyu)
        Dinv=sparse(1:length(HH),1:length(HH),diag(HH));
        ww=1;% Super Relaxation Factor
        M=(ww*(tril(HH)-Dinv)+Dinv)/sqrt(Dinv)/sqrt(ww*(2-ww));
        %         disp('Bicgstab Solution!')
        %         [Exyz_secondary,fl0,rr0,it0,rv0] =bicgstab(HH,P,tol,maxit,M,M.');
        disp('QMR Solution!')
        [Exyz_secondary,fl0,rr0,it0,rv0] =qmr(HH,P,tol,maxit,M,M.');
        %-------------------------------------------------------------------------%
        figure
        semilogy(rv0/norm(P),'-'); %
        xlabel('Iteration number');
        ylabel('Relative residual');
        %-------------------------------------------------------------------------%
    end
    
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    Exyz=Exyz_secondary+E_primary;
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    
    %% Plot Figure
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    EDGE_all_x_show=reshape(EDGE_all_x,[],1);
    Ex_show = Exyz(EDGE_all_x_show);
    Ex_show = full(Ex_show);
    Ex_show = reshape(Ex_show,NX,NY+1,NZ+1);
    
    EDGE_all_y_show=reshape(EDGE_all_y,[],1);
    Ey_show = Exyz(EDGE_all_y_show);
    Ey_show = full(Ey_show);
    Ey_show = reshape(Ey_show,NY,NX+1,NZ+1);
    
    EDGE_all_z_show=reshape(EDGE_all_z,[],1);
    Ez_show = Exyz(EDGE_all_z_show);
    Ez_show = full(Ez_show);
    Ez_show = reshape(Ez_show,NX+1,NY+1,NZ);
    
    Ex_second_show=Exyz_secondary(EDGE_all_x_show);
    Ex_second_show=full(Ex_second_show);
    Ex_second_show = reshape(Ex_second_show,NX,NY+1,NZ+1);
    
    Ex_secondary_show_2D_YZ=reshape(Ex_second_show(round((NX+1)/2),:,:),NY+1,NZ+1);
    Ex_secondary_show_2D_YZ=Ex_secondary_show_2D_YZ.';
    
    Ex_secondary_show_2D_XZ=reshape(Ex_second_show(:,round((NY+1)/2),:),NX,NZ+1);
    Ex_secondary_show_2D_XZ=Ex_secondary_show_2D_XZ.';
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    
    Ex_analysis_1D=E_Analytical(nf,:);
    
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    
    Ex_show_Primary_in_Z_direction_PML(:,nf)=reshape(Ex_show(round((NX+1)/2),round((NY+1)/2),:),[],1);
    Ex_show_Secondary_in_Z_direction_PML(:,nf)=reshape(Ex_second_show(round((NX+1)/2),round((NY+1)/2),:),[],1);
    
    Ex_show_Secondary_in_Y_direction_PML(:,nf)=abs(Ex_secondary_show_2D_YZ(NPML_Z+7,:));
    Ex_show_Secondary_in_X_direction_PML(:,nf)=abs(Ex_secondary_show_2D_XZ(NPML_Z+7,:));
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    
    gcf=figure;
    set(gcf,'unit','centimeters','position',[5 5 16.8 10.5]);% element:centimeter
    
    subplot(2,2,1)
    p1=plot(z_axis,abs(Ex_show_Primary_in_Z_direction_PML(:,nf)),'-o','color',[0.85,0.33,0.1],'Markersize',1.5,'Markerfacecolor',[0.85,0.33,0.1],'Markeredgecolor',[0.85,0.33,0.1],'Linewidth',0.8);
    hold on
    p2=plot(z_axis_traditional,abs(Ex_show_Primary_in_Z_direction(:,nf)),'-.o','color',[0,0.45,0.74],'Markersize',4.5,'Linewidth',0.8);
    hold on
    p3=plot(z_axis,abs(Ex_analysis_1D),'-.','color',[.49,0.18,0.56],'Linewidth',0.8);
    
    line([z_axis(NPML_Z+1),z_axis(NPML_Z+1)],[0,max(max(max(abs(Ex_show))))],'color','k','Linewidth',0.8)
    line([z_axis(NPML_Z+1),z_axis(NPML_Z+1)],[0,max(max(max(abs(Ex_show))))],'color','k','Linewidth',0.8)
    line([z_axis(end-NPML_Z),z_axis(end-NPML_Z)],[0,max(max(max(abs(Ex_show))))],'color','k','Linewidth',0.8)
    
    legend([p1 p2 p3],'Total Field-PML Method','Total Field-Grid Extension','Primary Field','Location','best')
    legend('boxoff')
    
    text((z_axis(1)+z_axis(NPML_Z+1))/2,1/2,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',8,'color',[0.93,0.19,0.13],'rotation',90)
    text((z_axis(NPML_Z+1)+z_axis(NPML_Z+1))/2,1/2,'Air','HorizontalAlignment','center','FontName','Times new roman','FontSize',8,'color',[0.93,0.19,0.13])
    text((z_axis(NPML_Z+1)+z_axis(end-NPML_Z))/2,1/2,'Model Region','HorizontalAlignment','center','FontName','Times new roman','FontSize',8,'color',[0.93,0.19,0.13])
    text((z_axis(end-NPML_Z)+z_axis(end))/2,1/2,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',8,'color',[0.93,0.19,0.13],'rotation',90)
    
    xlim([min(z_axis),max(z_axis)])
    ylim([0,1.2])
    xlabel('z(m)');ylabel('Electric Field (V/m)');
    title('(a)')
    % title(['Ex Total Field in z direction','-',num2str(freq(nf)),'Hz'],'Fontname','Times new roman')
    
    set(gca,'position',[0.062,0.58,0.42,0.34])
    set(gca,'Linewidth',0.8,'Fontname','Times new roman')
    %-------------------------------------------------------------------------%
    subplot(2,2,2)
    
    p1=plot(x_axis(NPML_X+1:end-NPML_X),abs(Ex_show_Secondary_in_X_direction_PML(NPML_X+1:end-NPML_X,nf)),'-o','color',[0.85,0.33,0.1],'Markersize',1.5,'Markerfacecolor',[0.85,0.33,0.1],'Markeredgecolor',[0.85,0.33,0.1],'Linewidth',0.8);
    hold on
    p2=plot(x_axis_traditional(length(extend_DX)+1:size(Ex_show_Secondary_in_X_direction,1)-length(extend_DX)),Ex_show_Secondary_in_X_direction(length(extend_DX)+1:size(Ex_show_Secondary_in_X_direction,1)-length(extend_DX),nf),'-.o','color',[0,0.45,0.74],'Markersize',4.5,'Linewidth',0.8);
    
    line([x_axis(NPML_X+1),x_axis(NPML_X+1)],[0,1],'color','k')
    line([x_axis(end-NPML_X),x_axis(end-NPML_X)],[0,1],'color','k')
    
    legend([p1 p2],'PML Method','Grid Extension','Location','best')
    legend('boxoff')
    
    text((x_axis(1)+x_axis(NPML_X+1))/2,1/2,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',8,'color',[0.93,0.19,0.13],'rotation',90)
    text((x_axis(NPML_X+1)+x_axis(end-NPML_X))/2,1/2,'Model Region','HorizontalAlignment','center','FontName','Times new roman','FontSize',8,'color',[0.93,0.19,0.13])
    text((x_axis(end-NPML_X)+x_axis(end))/2,1/2,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',8,'color',[0.93,0.19,0.13],'rotation',90)
    
    
    xlim([min(x_axis),max(x_axis)])
    xlabel('x(m)');ylabel('Electric Field (V/m)');
    title('(b)')
    % title(['Ex Secondary Field in x direction with depth ',num2str(sum(DZ(1:10-1))),'m'],'Fontname','Times new roman')
    
    set(gca,'position',[0.563,0.58,0.42,0.34])
    set(gca,'Linewidth',0.8,'Fontname','Times new roman')
    
    %-------------------------------------------------------------------------%
    subplot(2,2,3)
    
    p1=plot(y_axis,abs(Ex_show_Secondary_in_Y_direction_PML(:,nf)),'-o','color',[0.85,0.33,0.1],'Markersize',1.5,'Markerfacecolor',[0.85,0.33,0.1],'Markeredgecolor',[0.85,0.33,0.1],'Linewidth',0.8);
    hold on
    p2=plot(y_axis_traditional,Ex_show_Secondary_in_Y_direction(:,nf),'-.o','color',[0,0.45,0.74],'Markersize',4.5,'Linewidth',0.8);
    
    line([y_axis(NPML_Y+1),y_axis(NPML_Y+1)],[0,1],'color','k')
    line([y_axis(end-NPML_Y),y_axis(end-NPML_Y)],[0,1],'color','k')
    
    legend([p1 p2],'PML Method','Grid Extension','Location','best')
    legend('boxoff')
    
    text((y_axis(1)+y_axis(NPML_Y+1))/2,1/2,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',8,'color',[0.93,0.19,0.13],'rotation',90)
    text((y_axis(NPML_Y+1)+y_axis(end-NPML_Y))/2,1/2,'Model Region','HorizontalAlignment','center','FontName','Times new roman','FontSize',8,'color',[0.93,0.19,0.13])
    text((y_axis(end-NPML_Y)+y_axis(end))/2,1/2,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',8,'color',[0.93,0.19,0.13],'rotation',90)
    
    xlim([min(y_axis),max(y_axis)])
    xlabel('y(m)');ylabel('Electric Field (V/m)');
    title('(c)')
    % title(['Ex Secondary Field in y direction with depth ',num2str(sum(DZ(1:10-1))),'m'],'Fontname','Times new roman')
    
    set(gca,'position',[0.062,0.11,0.42,0.34])
    set(gca,'Linewidth',0.8,'Fontname','Times new roman')
    %-------------------------------------------------------------------------%
    subplot(2,2,4)
    
    p1=plot(z_axis,abs(Ex_show_Secondary_in_Z_direction_PML(:,nf)),'-o','color',[0.85,0.33,0.1],'Markersize',1.5,'Markerfacecolor',[0.85,0.33,0.1],'Markeredgecolor',[0.85,0.33,0.1],'Linewidth',0.8);
    hold on
    p2=plot(z_axis_traditional,abs(Ex_show_Secondary_in_Z_direction(:,nf)),'-.o','color',[0,0.45,0.74],'Markersize',4.5,'Linewidth',0.8);
    
    
    line([z_axis(NPML_Z+1),z_axis(NPML_Z+1)],[0,1],'color','k','Linewidth',0.8)
    line([z_axis(NPML_Z+1),z_axis(NPML_Z+1)],[0,1],'color','k','Linewidth',0.8)
    line([z_axis(end-NPML_Z),z_axis(end-NPML_Z)],[0,1],'color','k','Linewidth',0.8)
    
    legend([p1 p2],'PML Method','Grid Extension','Location','best')
    legend('boxoff')
    
    text((z_axis(1)+z_axis(NPML_Z+1))/2,1/2,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',8,'color',[0.93,0.19,0.13],'rotation',90)
    text((z_axis(NPML_Z+1)+z_axis(NPML_Z+1))/2,1/2,'Air','HorizontalAlignment','center','FontName','Times new roman','FontSize',8,'color',[0.93,0.19,0.13])
    text((z_axis(NPML_Z+1)+z_axis(end-NPML_Z))/2,1/2,'Model Region','HorizontalAlignment','center','FontName','Times new roman','FontSize',8,'color',[0.93,0.19,0.13])
    text((z_axis(end-NPML_Z)+z_axis(end))/2,1/2,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',8,'color',[0.93,0.19,0.13],'rotation',90)
    
    xlim([min(z_axis),max(z_axis)])
    xlabel('z(m)');ylabel('Electric Field (V/m)');
    title('(d)')
    % title(['Ex Secondary Field in z direction','-',num2str(freq(nf)),'Hz'],'Fontname','Times new roman')
    
    set(gca,'position',[0.563,0.11,0.42,0.34])
    set(gca,'Linewidth',0.8,'Fontname','Times new roman')
    
    %-------------------------------------------------------------------------%
    saveas(gcf,[strrep(['The Secondary Ex Field in different direction at ',num2str(freq(nf)),'Hz' ],'.','dot'),'.fig'])
    %-------------------------------------------------------------------------%
    % ����������
    Ex_PML_Y=Ex_show_Secondary_in_Y_direction_PML(NPML_Y+1:end-NPML_Y,nf);
    Ex_PML_Y_Traditional=Ex_show_Secondary_in_Y_direction(Grid_extend_Y+1:end-Grid_extend_Y,nf);
    Ex_CFS_PML_Y=Ex_show_Secondary_in_Y_direction_CFS_PML(NPML_Y+1:end-NPML_Y,nf);
    
    Relative_Error_Ex_Y=abs(abs(Ex_PML_Y)-abs(Ex_PML_Y_Traditional))./abs(Ex_PML_Y_Traditional);
    Relative_Error_Ex_Y_CFS_PML=abs(abs(Ex_CFS_PML_Y)-abs(Ex_PML_Y_Traditional))./abs(Ex_PML_Y_Traditional);
    
    gcf=figure;
    set(gcf,'unit','centimeters','position',[10 10 8.7 5.5]);% element:centimeter
    
    p1=plot(y_axis(NPML_Y+1:end-NPML_Y),20*log10(Relative_Error_Ex_Y_CFS_PML),'-.s','color',[0.75,0.75,0.75],'Markersize',5.5);
    hold on
    p2=plot(y_axis(NPML_Y+1:end-NPML_Y),20*log10(Relative_Error_Ex_Y),'r-o','Markersize',2,'Markerfacecolor','r');
    
    legend([p1 p2],'CFS-PML','Proposed PML','Location','best')
    legend('boxoff')
    xlim([-1600,1600])
    set(gca,'xtick',-1500:500:1500)
    if nf==1
        ylim([-130,-40])
    elseif nf==2
        ylim([-160,-40])
    end
    xlabel('y(m)');
    ylabel('Reflection Error(dB)')
    set(gca,'Linewidth',0.8,'Fontname','Times new roman','FontSize',10)
    
    saveas(gcf,[strrep(['Reflection Error in y direction at ',num2str(freq(nf)),'Hz' ],'.','dot'),'.fig'])
    print([strrep(['Reflection Error in y direction at ',num2str(freq(nf)),'Hz' ],'.','dot'),'.tif'],'-dtiffn','-r300')
    %-------------------------------------------------------------------------%
    gcf=figure;
    set(gcf,'unit','centimeters','position',[10 10 8.7 5.5]);% element:centimeter
    
    subplot('position', [0.114794061302682,0.22055303030303,0.051091954022989,0.70444696969697]);
    
    p1=plot(y_axis_traditional(1:Grid_extend_X+1),Ex_show_Secondary_in_Y_direction(1:Grid_extend_X+1,nf),'b-.o','Markersize',4.5,'Linewidth',0.8);
    hold on
    p2=plot(y_axis(1:NPML_Y+1),abs(Ex_show_Secondary_in_Y_direction_CFS_PML(1:NPML_Y+1,nf)),'-.s','color',[0.75,0.75,0.75],'Markersize',5.5,'Markeredgecolor',[0.75,0.75,0.75],'Linewidth',0.8);
    hold on
    p3=plot(y_axis(1:NPML_Y+1),abs(Ex_show_Secondary_in_Y_direction_PML(1:NPML_Y+1,nf)),'r-o','Markersize',1.5,'Markerfacecolor','r','Markeredgecolor','r','Linewidth',0.8);
    
    
    
    text((y_axis(1)+y_axis(NPML_Y+1))/2,1/2,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',8,'color','k','rotation',90)
    
    xlim([y_axis(1),y_axis(NPML_Y+1)])
    ylim([0,1])
    
    set(gca,'xtick',[-1500.3],'XtickLabelRotation',-30)
    % set(gca,'ytick',[])
    ylabel('Electric Field (V/m)');
    set(gca,'Linewidth',0.8,'Fontname','Times new roman','FontSize',9)
    
    %-------------------------------------------------------------------------%
    
    subplot('position',[0.188566050004195,0.22055303030303,0.656419582179714,0.70444696969697]);
    
    p1=plot(y_axis_traditional(Grid_extend_X+1:N_MODEL_Y+Grid_extend_X+1),Ex_show_Secondary_in_Y_direction(Grid_extend_X+1:N_MODEL_Y+Grid_extend_X+1,nf),'b-.o','Markersize',4.5,'Linewidth',0.8);
    hold on
    p2=plot(y_axis(NPML_Y+1:N_MODEL_Y+NPML_Y+1),abs(Ex_show_Secondary_in_Y_direction_CFS_PML(NPML_Y+1:N_MODEL_Y+NPML_Y+1,nf)),'-.s','color',[0.75,0.75,0.75],'Markersize',8.5,'Markeredgecolor',[0.75,0.75,0.75],'Linewidth',0.8);
    hold on
    p3=plot(y_axis(NPML_Y+1:N_MODEL_Y+NPML_Y+1),abs(Ex_show_Secondary_in_Y_direction_PML(NPML_Y+1:N_MODEL_Y+NPML_Y+1,nf)),'r-o','Markersize',1.5,'Markerfacecolor','r','Markeredgecolor','r','Linewidth',0.8);
    
    
    legend([p1 p2 p3],'Grid Extension','CFS-PML','Proposed PML','Location','best')
    legend('boxoff')
    
    text((y_axis(NPML_Y+1)+y_axis(end-NPML_Y))/2,1/2,'Model Region','HorizontalAlignment','center','FontName','Times new roman','FontSize',8,'color','k')
    
    xlim([min(y_axis),max(y_axis)])
    xlabel('y(m)');% ylabel('Electric Field (V/m)');
    
    % title(['Ex Secondary Field in y direction with depth ',num2str(sum(DZ(1:10-1))),'m'],'Fontname','Times new roman')
    
    set(gca,'xtick',-1500:500:1500,'XtickLabelRotation',-30)
    set(gca,'ytick',[])
    set(gca,'Linewidth',0.8,'Fontname','Times new roman','FontSize',9)
    
    %-------------------------------------------------------------------------%
    subplot('position', [0.868707595715525,0.22055303030303,0.051091954022989,0.70444696969697]);
    
    
    p1=plot(y_axis_traditional(N_MODEL_Y+Grid_extend_X+1:end),Ex_show_Secondary_in_Y_direction(N_MODEL_Y+Grid_extend_X+1:end,nf),'b-.o','Markersize',4.5,'Linewidth',0.8);
    hold on
    p2=plot(y_axis(N_MODEL_Y+NPML_Y+1:end),abs(Ex_show_Secondary_in_Y_direction_CFS_PML(N_MODEL_Y+NPML_Y+1:end,nf)),'-.s','color',[0.75,0.75,0.75],'Markersize',5.5,'Markeredgecolor',[0.75,0.75,0.75],'Linewidth',0.8);
    hold on
    p3=plot(y_axis(N_MODEL_Y+NPML_Y+1:end),abs(Ex_show_Secondary_in_Y_direction_PML(N_MODEL_Y+NPML_Y+1:end,nf)),'r-o','Markersize',1.5,'Markerfacecolor','r','Markeredgecolor','r','Linewidth',0.8);
    
    text((y_axis(end-NPML_Y)+y_axis(end))/2,1/2,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',8,'color','k','rotation',90)
    %
    xlim([y_axis(N_MODEL_Y+NPML_Y+1),y_axis(end)])
    ylim([0,1])
    
    % title(['Ex Secondary Field in y direction with depth ',num2str(sum(DZ(1:10-1))),'m'],'Fontname','Times new roman')
    
    set(gca,'xtick',[1500.3],'XtickLabelRotation',-30)
    set(gca,'ytick',[])
    % set(gca,'position',[0.864446855573537,0.08333100399401,0.125333758068767,0.905482143657204])
    set(gca,'Linewidth',0.8,'Fontname','Times new roman','FontSize',9)
    
    
    saveas(gcf,[strrep(['The Secondary Ex Field in y direction at ',num2str(freq(nf)),'Hz' ],'.','dot'),'.fig'])
    print([strrep(['The Secondary Ex Field in y direction at ',num2str(freq(nf)),'Hz' ],'.','dot'),'.tif'],'-dtiffn','-r300')
    %-------------------------------------------------------------------------%
    %-------------------------------------------------------------------------%
    
    disp('Calculation Finished!')
    disp('-------------------------')
    
end

toc

% profile viewer


