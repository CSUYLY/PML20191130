function E_Analytical=Analytical_Solution_Function(z_axis,freq,rho_background)

% The interface between the air layer and the earth layer is located at z=0.
% The position of the air layer is z<0, and the position of the earth medium is z>=0.

A2=1;

z=z_axis;
z1=z(1:find(z==0)-1); %The position of the air layer
z2=z(find(z==0):end); %The position of the earth medium

rho1=rho_background;
rho2=rho_background;

E_Analytical=zeros(length(freq),length(z));

for nf=1:length(freq)
    
    f=freq(nf);
    miu0=4*pi*1e-7;
    w=2*pi*f;
    
    k1=sqrt(-1i*w*miu0*(1/rho1));
    k2=sqrt(-1i*w*miu0*(1/rho2));
    
    E_nf(1:length(z1))=(k1+k2)/(2*k1)*A2*exp(-k1*z1)+(k1-k2)/(2*k1)*A2*exp(k1*z1);
    E_nf(length(z1)+1:length(z))=A2*exp(-k2*z2);
    
    E_Analytical(nf,:)=E_nf;
    
end

figure
plot(z,abs(E_Analytical),'-.');
line([0,0],[0,1.1*max(max(abs(E_Analytical)))],'color','k')
ylim([0,1.1*max(max(abs(E_Analytical)))])
xlabel('Depth(m)')
ylabel('Electric Field(V/m)')
grid on
set(gca,'Fontname','Times new roman','FontWeight','bold')
