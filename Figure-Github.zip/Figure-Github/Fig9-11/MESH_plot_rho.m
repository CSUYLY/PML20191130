function MESH_plot_rho(NX,NY,NZ,DX,DY,DZ,NPML_X,NPML_Y,NPML_Z,sigma,sigma_background,Point,T)
% ����ά����

%--------------------------------------------------------------------------%
NE=NX*NY*NZ;  % �ܵ�Ԫ��
%--------------------------------------------------------------------------%
x_axis=[0,cumsum(DX)]-sum(DX)/2;
y_axis=[0,cumsum(DY)]-sum(DY)/2;
z_axis=[0,cumsum(DZ)]-sum(DZ(1:NPML_Z));
%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
figure
% set(gcf,'unit','centimeters','position',[5 5 10 10]);% Unit:centimeter
set(gcf,'unit','centimeters','position',[10 10 8.7 6.5]);% Unit:centimeter

for n=1:NE
    
    % �����豳���ĵ�����Ϊ100��������ĵ�����Ϊ1e9��
    if sigma(n)~=sigma_background&&sigma(n)
        
        vert=[Point(T(n,1),:);Point(T(n,2),:);Point(T(n,3),:);Point(T(n,4),:);Point(T(n,5),:);Point(T(n,6),:);Point(T(n,7),:);Point(T(n,8),:)];
        fac=[1 2 6 5;2 3 7 6;3 4 8 7;4 1 5 8;1 2 3 4;5 6 7 8 ];
        
        if 1/sigma(n)<1000
            patch('Faces',fac,'Vertices',vert,'FaceColor',[0.28,0.94,0.61],'FaceAlpha',1);  % patch function
        elseif 1/sigma(n)>=1000&&1/sigma(n)<2000
            patch('Faces',fac,'Vertices',vert,'FaceColor','m','FaceAlpha',1);  % patch function
        else
            patch('Faces',fac,'Vertices',vert,'FaceColor','b','FaceAlpha',1);  % patch function
        end
        
        hold on
    end
end

alpha(0.5);
%--------------------------------------------------------------------------%

% [X,Y]=meshgrid([min(x_axis),max(x_axis)],[min(y_axis),max(y_axis)]);
% 
% Z=0*ones(size(X,1),size(Y,2));
% A=surf(X,Y,Z,'facecolor',[0.63,0.87,0.62]);
% 
% % �����ڲ����͸���ȡ�
% alpha(A,0.3);
%--------------------------------------------------------------------------%
% Boundary of Modeling Area
line([x_axis(1),x_axis(1)],[y_axis(1),y_axis(end)],[z_axis(1),z_axis(1)],'linewidth',1,'color',[0.07,0.62,1.00])
line([x_axis(end),x_axis(end)],[y_axis(1),y_axis(end)],[z_axis(1),z_axis(1)],'linewidth',1,'color',[0.07,0.62,1.00])
line([x_axis(1),x_axis(end)],[y_axis(1),y_axis(1)],[z_axis(1),z_axis(1)],'linewidth',1,'color',[0.07,0.62,1.00])
line([x_axis(1),x_axis(end)],[y_axis(end),y_axis(end)],[z_axis(1),z_axis(1)],'linewidth',1,'color',[0.07,0.62,1.00])

line([x_axis(1),x_axis(1)],[y_axis(1),y_axis(1)],[z_axis(1),z_axis(end)],'linewidth',1,'color',[0.07,0.62,1.00])
line([x_axis(end),x_axis(end)],[y_axis(1),y_axis(1)],[z_axis(1),z_axis(end)],'linewidth',1,'color',[0.07,0.62,1.00])
line([x_axis(1),x_axis(1)],[y_axis(end),y_axis(end)],[z_axis(1),z_axis(end)],'linewidth',1,'color',[0.07,0.62,1.00])
line([x_axis(end),x_axis(end)],[y_axis(end),y_axis(end)],[z_axis(1),z_axis(end)],'linewidth',1,'color',[0.07,0.62,1.00])

line([x_axis(1),x_axis(1)],[y_axis(1),y_axis(end)],[z_axis(end),z_axis(end)],'linewidth',1,'color',[0.07,0.62,1.00])
line([x_axis(end),x_axis(end)],[y_axis(1),y_axis(end)],[z_axis(end),z_axis(end)],'linewidth',1,'color',[0.07,0.62,1.00])
line([x_axis(1),x_axis(end)],[y_axis(1),y_axis(1)],[z_axis(end),z_axis(end)],'linewidth',1,'color',[0.07,0.62,1.00])
line([x_axis(1),x_axis(end)],[y_axis(end),y_axis(end)],[z_axis(end),z_axis(end)],'linewidth',1,'color',[0.07,0.62,1.00])
%--------------------------------------------------------------------------%

% Boundary of PML Area
line([x_axis(NPML_X+1),x_axis(NPML_X+1)],[y_axis(NPML_Y+1),y_axis(end-NPML_Y)],[z_axis(NPML_Z+1),z_axis(NPML_Z+1)],'Linestyle','-.','linewidth',1,'color',[0.75,0.00,0.75])
line([x_axis(end-NPML_X),x_axis(end-NPML_X)],[y_axis(NPML_Y+1),y_axis(end-NPML_Y)],[z_axis(NPML_Z+1),z_axis(NPML_Z+1)],'Linestyle','-.','linewidth',1,'color',[0.75,0.00,0.75])
line([x_axis(NPML_X+1),x_axis(end-NPML_X)],[y_axis(NPML_Y+1),y_axis(NPML_Y+1)],[z_axis(NPML_Z+1),z_axis(NPML_Z+1)],'Linestyle','-.','linewidth',1,'color',[0.75,0.00,0.75])
line([x_axis(NPML_X+1),x_axis(end-NPML_X)],[y_axis(end-NPML_Y),y_axis(end-NPML_Y)],[z_axis(NPML_Z+1),z_axis(NPML_Z+1)],'Linestyle','-.','linewidth',1,'color',[0.75,0.00,0.75])

line([x_axis(NPML_X+1),x_axis(NPML_X+1)],[y_axis(NPML_Y+1),y_axis(NPML_Y+1)],[z_axis(NPML_Z+1),z_axis(end-NPML_Z)],'Linestyle','-.','linewidth',1,'color',[0.75,0.00,0.75])
line([x_axis(end-NPML_X),x_axis(end-NPML_X)],[y_axis(NPML_Y+1),y_axis(NPML_Y+1)],[z_axis(NPML_Z+1),z_axis(end-NPML_Z)],'Linestyle','-.','linewidth',1,'color',[0.75,0.00,0.75])
line([x_axis(NPML_X+1),x_axis(NPML_X+1)],[y_axis(end-NPML_Y),y_axis(end-NPML_Y)],[z_axis(NPML_Z+1),z_axis(end-NPML_Z)],'Linestyle','-.','linewidth',1,'color',[0.75,0.00,0.75])
line([x_axis(end-NPML_X),x_axis(end-NPML_X)],[y_axis(end-NPML_Y),y_axis(end-NPML_Y)],[z_axis(NPML_Z+1),z_axis(end-NPML_Z)],'Linestyle','-.','linewidth',1,'color',[0.75,0.00,0.75])

line([x_axis(NPML_X+1),x_axis(NPML_X+1)],[y_axis(NPML_Y+1),y_axis(end-NPML_Y)],[z_axis(end-NPML_Z),z_axis(end-NPML_Z)],'Linestyle','-.','linewidth',1,'color',[0.75,0.00,0.75])
line([x_axis(end-NPML_X),x_axis(end-NPML_X)],[y_axis(NPML_Y+1),y_axis(end-NPML_Y)],[z_axis(end-NPML_Z),z_axis(end-NPML_Z)],'Linestyle','-.','linewidth',1,'color',[0.75,0.00,0.75])
line([x_axis(NPML_X+1),x_axis(end-NPML_X)],[y_axis(NPML_Y+1),y_axis(NPML_Y+1)],[z_axis(end-NPML_Z),z_axis(end-NPML_Z)],'Linestyle','-.','linewidth',1,'color',[0.75,0.00,0.75])
line([x_axis(NPML_X+1),x_axis(end-NPML_X)],[y_axis(end-NPML_Y),y_axis(end-NPML_Y)],[z_axis(end-NPML_Z),z_axis(end-NPML_Z)],'Linestyle','-.','linewidth',1,'color',[0.75,0.00,0.75])
%--------------------------------------------------------------------------%

grid on

axis ij
axis equal
axis tight
set(gca,'zdir','reverse')


% view(-45,16)

grid on
xlabel('x(m)')
ylabel('y(m)')
zlabel('z(m)')

set(gca,'xtick',-2000:1000:2000)
set(gca,'ytick',-2000:1000:2000)

view(-20,15)

text((x_axis(1)+x_axis(NPML_X))/2,(y_axis(1)+y_axis(NPML_Y))/2,(z_axis(1)+z_axis(end))/2,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',6,'rotation',90);
text((x_axis(end-NPML_X)+x_axis(end))/2,(y_axis(end-NPML_Y)+y_axis(end))/2,(z_axis(1)+z_axis(end))/2,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',6,'rotation',90);
text((x_axis(1)+x_axis(NPML_X))/2,(y_axis(end-NPML_Y)+y_axis(end))/2,(z_axis(1)+z_axis(end))/2,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',6,'rotation',90);
text((x_axis(end-NPML_X)+x_axis(end))/2,(y_axis(1)+y_axis(NPML_Y))/2,(z_axis(1)+z_axis(end))/2,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',6,'rotation',90);
text((x_axis(1)+x_axis(end))/2,(y_axis(1)+y_axis(end))/2,(z_axis(1)+z_axis(NPML_Z))/2,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',6);
text((x_axis(1)+x_axis(end))/2,(y_axis(1)+y_axis(end))/2,(z_axis(end-NPML_Z)+z_axis(end))/2,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',6);




set(gca,'FontName','Times New roman','FontSize',10) %,'FontWeight','bold'







