%-------------------------------------------------------------------------%
% This code tests the truncation effect of low-frequency PML in the 
% one-dimensional radiation problem. The finite element simulation results
% with PML are compared with analytical solutions and traditional 
% the third-class boundary condition method.
%-------------------------------------------------------------------------%
%                             Nov. 29, 2019
%                       Liangyong Yang (PhD student)
%     Institute of Geology and Geophysics, Chinese Academy of Sciences
%                Emails: yangliangyong15@mails.ucas.ac.cn
%-------------------------------------------------------------------------%
%                          ������ (�ڶ���ʿ�о���)
%                      �й���ѧԺ��������������о���
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%

clc;
clear;
close all
tic

NM=100;                             % Number of cells in the simulation region
NPML=12;                            % Number of cells in the each side PML region
NE=NPML+NM+NPML;                    % Total number of cells
NP=NE+1;                            % Total number of nodes
DZ=20*ones(1,NE);                   % length of each cell
%---------------------------------%
% find_kappa=-1.040;                    % The optimal kappa value
% find_sigma=2.8700;                    % The optimal sigma value
% find_alpha=1.6000;                    % The optimal alpha value

find_kappa=-1.040;                    % The optimal value of kappa
find_sigma=2.0240;                    % The optimal value of sigma
find_alpha=1.6120;                    % The optimal value of alpha
%---------------------------------%
z_axis=[0,cumsum(DZ)]-sum(DZ)/2;      % The coordinates of z direction

eps0=1/(36*pi)*1e-9;                  % Vacuum permittivity
eps1=1;                               % Relative permittivity
miu=4*pi*1e-7;                        % Magnetic permeability
%---------------------------------%
J0=1;                                 % Current magnitude
%---------------------------------%
%---------------------------------%
rho=1000*ones(1,NE);                  % The background Resistivity
sigma=1./rho;                         % The background Conductivity
%---------------------------------%
%---------------------------------%
freq=[1,100];                         % The frequency range
%---------------------------------%
% Storage the node number of cell
ME=zeros(2,NE);

for i=1:NE
    ME(1,i)=i;
    ME(2,i)=i+1;
end
%---------------------------------%

t1=ME([1;2;1;2],:);  % faster than 'repmat'
t2=ME([1;1;2;2],:);

% The element stiffness matrix or mass matrix of cell
K1e_temp=[1,-1;-1,1];
K1e_temp=reshape(K1e_temp,4,1);
K1e_par(:,1:NE)=K1e_temp./DZ(1:NE);
% The element stiffness matrix or mass matrix of cell
K2e_temp=[1/3,1/6;1/6,1/3];
K2e_temp=reshape(K2e_temp,4,1);
K2e_par(:,1:NE)=K2e_temp.*DZ(1:NE);
%--------------------------------------%
%%
% Traditional the Third boundary condition
Ex_Tradition=zeros(NP,length(freq));
%--------------------------------------%
for nf=1:length(freq)
    
    f=freq(nf);
    w=2*pi*f; % Angular frequency
    %---------------Build K1e--------------%
    K1e=K1e_par;
    K1=sparse(t1,t2,K1e,NP,NP);
    %---------------Build K2e--------------%
    K2e=(-w*w*miu*eps0+1i*w*miu*sigma).*K2e_par;
    K2=sparse(t1,t2,K2e,NP,NP);
    %---------------Build K3e--------------%
    K3=sparse(NP,NP);
    
    a=1i*sqrt(-1i*w*miu/rho(NE));
    K3(1,1)=a;            % the left side
    K3(NP,NP)=a;          % the right side
    %------------Assembly matrix-----------%
    v=K1+K2+K3;
    %--------------------------------------%
    P=sparse(NP,1);
    P(round(NP/2))=-(1i*w*miu)*(J0); % Add the current source at the center of simulation region
    %--------------------------------------%
    Ex_Tradition(:,nf)=v\P;
    %--------------------------------------%
    
end

%%
% PML Method

%--------------------------------------%
Ex=zeros(NP,length(freq));
%--------------------------------------%

for nf=1:length(freq)
    
    f=freq(nf);
    w=2*pi*f; % Angular frequency
    %--------------------------------------%
    m=1;
    sigma_max = find_sigma*miu*sqrt(miu/eps0)/DZ(end);  % Maximum sigma value in PML
    kappa_max = find_kappa;                             % Maximum kappa value in PML
    alpha_max = find_alpha;                             % *freq(nf)^(-0.5); %Maximum alpha value in PML, it needs to be greater than 0, and need to be multiplied by freq(nf)^(-0.5) when there is a Direchlet condition.
    %--------------------------------------%
    zekappa = ones(1,NE);                           % Initialize the matrix
    zesigma = zeros(1,NE);                          % Initialize the matrix
    zealpha = zeros(1,NE);                          % Initialize the matrix
    
    for i=1:NPML    % The left side PML
        distance=(NPML+0.5-i)/NPML;                     % Normalized distance
        zesigma(1,i)=sigma_max*(exp(m*distance)-1);     % Exponential spatial scaling
        zekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
        zealpha(1,i)=alpha_max*(exp(m*(1-distance))-1); % The one is different from above zekappa and zesigma
        % zesigma(1,i)=sigma_max*(distance)^m;          % Linear spatial scaling
        % zekappa(1,i)=1+kappa_max*(distance)^m;
        % zealpha(1,i)=alpha_max*((1-distance))^m;
    end
    
    for i=NPML+NM+1:NE     % The right side PML
        distance=(i-0.5-(NPML+NM))/NPML;                % Normalized distance
        zesigma(1,i)=sigma_max*(exp(m*distance)-1);     % Exponential spatial scaling
        zekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
        zealpha(1,i)=alpha_max*(exp(m*(1-distance))-1); % The one is different from above zekappa and zesigma
        % zesigma(1,i)=sigma_max*(distance)^m;          % Linear spatial scaling
        % zekappa(1,i)=1+kappa_max*(distance)^m;
        % zealpha(1,i)=alpha_max*((1-distance))^m;
    end
    
    Sez_origin = zekappa+(sqrt(2)*zesigma./((zealpha+1i).*sqrt(w*eps0.*sigma))); % Construct the key PML parameter
    
    %--------------------------------------%
    %---------------Build K1e--------------%
    K1e=(1./Sez_origin(1:NE)).*K1e_par;
    K1=sparse(t1,t2,K1e,NP,NP); % Build K1 Matrix of finite element method; [The 'sparse' is very fast than tradition 'for' loop, very recommended!]
    %---------------Build K2e--------------%
    K2e=Sez_origin(1:NE).*(-w*w*miu*eps0+1i*w*miu*sigma).*K2e_par;
    K2=sparse(t1,t2,K2e,NP,NP); % Build K2 Matrix of finite element method; [The 'sparse' is very fast than tradition 'for' loop, very recommended!]
    %--------------------------------------%
    %---------------Build K3e--------------%
    K3=sparse(NP,NP);
    
    %------------Assembly matrix-----------%
    v=K1+K2+K3;
    %--------------------------------------%
    %--------------------------------------%
    P=sparse(NP,1);
    P(round(NP/2))=-(1i*w*miu)*(J0); % Add the current source at the center of simulation region
    %--------------------------------------%
    % This Method is slow
    % Set the perfect electrical conductor at the both outmost side
    %             P(1)=0;
    %             v(:,1)=0;v(1,:)=0;v(1,1)=1;
    %
    %             P(NP)=0;
    %             v(:,NP)=0;v(NP,:)=0;v(NP,NP)=1;
    %--------------------------------------%
    % Set the perfect electrical conductor at the both outmost side
    % This method is fast
    Bid=[1,NP];
    for i=1:length(Bid)
        v(Bid(i),Bid(i))=v(Bid(i),Bid(i))*10^10;
        P(Bid(i))=v(Bid(i),Bid(i))*0;
    end
    %---------------------------------------------------%
    %---------------------------------------------------%
    Ex(:,nf)=v\P; % Compute the electric field
    %---------------------------------------------------%
    %---------------------------------------------------%
    % Compute the analytical solution
    r_distance=z_axis((length(z_axis)+1)/2:end);
    
    Z=sqrt(1i*w*miu*rho(1));
    k=sqrt(-1i*w*miu*sigma(1));
    
    E_analysis=-1*(Z/2)*J0*exp(-1i*k*r_distance);  % Current and electric field have opposite directions
    
    %---------------------------------------------------%
    Exs_PML_FEM=Ex((size(Ex,1)+1)/2:end-NPML,nf).';
    
    Exs_Tradition_FEM=Ex_Tradition((size(Ex_Tradition,1)+1)/2:end-NPML,nf).';
    
    Relative_Error_Tradition=abs(abs(Exs_PML_FEM)-abs(Exs_Tradition_FEM))./max(abs(Exs_Tradition_FEM));
    
    Relative_Error_Analysis=abs(abs(Exs_PML_FEM)-abs(E_analysis(1:end-NPML)))./abs(max(E_analysis(1:end-NPML)));
    
    %---------------------------------------------------%
    %---------------------------------------------------%
    
    figure
    set(gcf,'unit','centimeters','position',[10 10 8.7 5.5]);%ͼ�ε�������
    
    p1=plot(z_axis((length(z_axis)+1)/2:end),abs(Ex((size(Ex,1)+1)/2:end,nf)),'k-.x','Markersize',4,...
        'MarkerIndices',[9:12:length(z_axis((length(z_axis)+1)/2:end-NPML)),length(z_axis((length(z_axis)+1)/2:end-NPML))+NPML/3+1,length(z_axis((length(z_axis)+1)/2:end-NPML))+2*NPML/3+1],'Linewidth',0.8);
    hold on
    p2=plot(z_axis((length(z_axis)+1)/2:end),abs(Ex_Tradition((size(Ex_Tradition,1)+1)/2:end,nf)),'k-o','Markersize',2,'MarkerFaceColor','k','MarkerIndices',5:12:length(z_axis((length(z_axis)+1)/2:end)),'Linewidth',0.8);
    hold on
    p3=plot(r_distance,abs(E_analysis),'k-+','Markersize',4,'MarkerIndices',13:12:length(r_distance),'Linewidth',0.8);
    hold off
    
    axis tight
    
    if freq(nf)==1
        ylim([0,0.05])
        line([sum(DZ(1:NPML+NM))-sum(DZ)/2,sum(DZ(1:NPML+NM))-sum(DZ)/2],[0,0.05],'color','k','Linewidth',0.5)
        text(sum(DZ(1:NPML+NM+round(NPML/2)))-sum(DZ)/2,max(max(abs((Ex(:,nf)))))/2,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',10)
    elseif freq(nf)==100
        ylim([0,0.5])
        line([sum(DZ(1:NPML+NM))-sum(DZ)/2,sum(DZ(1:NPML+NM))-sum(DZ)/2],[0,0.5],'color','k','Linewidth',0.5)
        text(sum(DZ(1:NPML+NM+round(NPML/2)))-sum(DZ)/2,0.35,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',10)
    end
    
    legend([p1 p2 p3],{'PML Method','Third-Order Boundary Condition','Analytic Solution'},'Location','southwest','FontSize',8)
    legend('boxoff')
    
    set(gca,'xtick',0:200:1200);%set(gca,'xticklabel',{'-1.5','-1','-0.5','0'})
    
    xlabel('r(m)');ylabel('Electric Field(V/m)');
    
    set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10);
    % title(['Electric field attenuation-',num2str(freq(nf)),'Hz'],'FontName','Times new roman','FontSize',20)
    saveas(gcf,['Electric field attenuation-','10e',num2str(log10(freq(nf))),'Hz','.fig'])
    print(['Electric field attenuation-','10e',num2str(log10(freq(nf))),'Hz','.tif'],'-dtiffn','-r300')
    %---------------------------------------------------%
    %---------------------------------------------------%
    figure
    set(gcf,'unit','centimeters','position',[10 10 8.7 5.5]);% Unit:centimeter
    
    %     plot(r_distance(1:end-NPML),20*log10(Relative_Error_Tradition),'k-','Linewidth',1.0);
    %     hold on
    plot(r_distance(1:end-NPML),20*log10(Relative_Error_Analysis),'k-.x','Markersize',4,'MarkerIndices',9:12:length(z_axis((length(z_axis)+1)/2:end-NPML)),'Linewidth',1.0);
    
    set(gca,'xtick',0:200:1000);%set(gca,'xticklabel',{'-1.5','-1','-0.5','0'})
    
    xlabel('r(m)');ylabel('Relative Error(dB)');
    set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10);
    
    % title(['Relative Error-',num2str(freq(nf)),'Hz'],'FontName','Times new roman','FontSize',20)
    saveas(gcf,['Relative Error-','10e',num2str(log10(freq(nf))),'Hz','.fig'])
    print(['Relative Error-','10e',num2str(log10(freq(nf))),'Hz','.tif'],'-dtiffn','-r300')
    %---------------------------------------------------%
    
    
    
end



toc

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%


