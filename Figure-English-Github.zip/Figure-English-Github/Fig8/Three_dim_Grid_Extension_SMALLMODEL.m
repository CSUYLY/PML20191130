%-------------------------------------------------------------------------%
% This code uses the traditional grid continuation method to calculate the
% finite element solution of the three-dimensional radiation problem. 
% Limited to the computing power of the computer, the number of extended 
% grids is only 12 layers, and the size of the extended grids gradually
% increases.
% This result provides a reference for the PML method
%-------------------------------------------------------------------------%
% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
%                            DON'T RUN THIS CODE
% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
% Since this code uses the direct method to solve the system of equations,
% it is very memory intensive. I run this program on a server with very
% large memory. If you have a particularly large server, you can try 
% running this program. If you have a good iterative method for solving 
% the system of equations, you can modify this code and then run it on your
% personal computer, otherwise your personal computer will crash!
%-------------------------------------------------------------------------%
%                             Nov. 29, 2019
%                       Liangyong Yang (PhD student)
%     Institute of Geology and Geophysics, Chinese Academy of Sciences
%                Emails: yangliangyong15@mails.ucas.ac.cn
%-------------------------------------------------------------------------%
%                          ������ (�ڶ���ʿ�о���)
%                      �й���ѧԺ��������������о���
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%


clear;
clc;
close all;
warning off
disp('Grid Extension Method')
% profile on -memory
%--------------------------------------------------------------------------%
I0=100;
dL=0.01;
%--------------------------------------------------------------------------%
% [Field source is set at Z direction]

N_MODEL_X = 20; % number of grids in X direction; horizontal to the right% [even number]
N_MODEL_Y = 60; % number of grids in Y direction; vertical to the paper face% [even number]
N_MODEL_Z = 11;  % number of grids in Z direction; vertical up% [odd number]

% N_MODEL_X = 8; % number of grids in X direction; horizontal to the right% [even number]
% N_MODEL_Y = 14; % number of grids in Y direction; vertical to the paper face% [even number]
% N_MODEL_Z = 5;  % number of grids in Z direction; vertical up% [odd number]

NPML_X = 16;
NPML_Y = 16;
NPML_Z = 16;

NX = N_MODEL_X + 2 * NPML_X;% number of grids in X direction; horizontal to the right% [odd number]
NY = N_MODEL_Y + 2 * NPML_Y;% number of grids in Y direction; vertical to the paper face% [even number]
NZ = N_MODEL_Z + 2 * NPML_Z;% number of grids in Z direction; vertical up% [odd number]
%--------------------------------------------------------------------------%
solve_choice = 1; % directly solve when solve_choice = 1 (fast, memory-consuming, accurate); solve iteratively when solve_choice = 2 (slow, small memory, inaccurate);
maxit = 5000;% maximum iterations
%----------------------------------------------------------------------------------------%
freq=1e5; % [1e5,1e7]; % Frequency
%----------------------------------------------------------------------------------------%
main_dx = 0.01;  % grid spacing in X direction
main_dy = 0.01;  % grid spacing in Y direction
main_dz = 0.01;  % grid spacing in Z direction

extend_PML_X=0.01*1.5.^(0:NPML_X-1); % Grid Extension in X direction
extend_PML_Y=0.01*1.5.^(0:NPML_Y-1); % Grid Extension in Y direction
extend_PML_Z=0.01*1.5.^(0:NPML_Z-1); % Grid Extension in Z direction

disp(['The length of grid extension:',num2str(min([sum(extend_PML_X),sum(extend_PML_Y),sum(extend_PML_Z)])),'m']);
disp('--------------------------------------------------------------------------')

DX=[fliplr(extend_PML_X),main_dx*ones(1,N_MODEL_X),extend_PML_X];
DY=[fliplr(extend_PML_Y),main_dy*ones(1,N_MODEL_Y),extend_PML_Y];
DZ=[fliplr(extend_PML_Z),main_dz*ones(1,N_MODEL_Z),extend_PML_Z];
%----------------------------------------------------------------------------------------%
%----------------------------------------------------------------------------------------%
x_axis=[0,cumsum(DX)]-max(cumsum(DX))/2;  % X coordinate of each edge
y_axis=[0,cumsum(DY)]-max(cumsum(DY))/2;  % Y coordinate of each edge
z_axis=cumsum(DZ)-DZ/2-sum(DZ)/2;         % Z coordinate of each edge
%--------------------------------------------------------------------------%
NE=NX*NY*NZ;               % total units
NP=(NX+1)*(NY+1)*(NZ+1);   % total nodes

eps0=1/(36*pi)*1e-9;       % dielectric constant of vacuum
miu0=pi*4e-7;              % vacuum permeability
%--------------------------------------------------------------------------%
sigma_background=(1/1);    % Conductivity of background medium
sigma=sigma_background*ones(NX,NY,NZ);
%--------------------------------------------------------------------------%
sigma=reshape(sigma,[],1);
%--------------------------------------------------------------------------%
Point=zeros(NP,3);  % Coordinates of each node

Point(:,1)=repmat(([0,cumsum(DX)])',NP/(NX+1),1);                       % X coordinate of each node
Point(:,2)=repmat(reshape(repmat([0,cumsum(DY)],NX+1,1),[],1),NZ+1,1);  % Y coordinate of each node
Point(:,3)=reshape(repmat([0,cumsum(DZ)],(NX+1)*(NY+1),1),[],1);        % Z coordinate of each node
%--------------------------------------------------------------------------%
NE_DX = zeros(1,NE); % length of each cell
NE_DY = zeros(1,NE); % width of each cell
NE_DZ = zeros(1,NE); % height of each cell
T = zeros(NE,8);     % Corresponding Global number of 8 Local node number of each cell

for k=1:NZ
    for j=1:NY
        for i=1:NX
            %--------------------------------------------------------------%
            T((k-1)*NX*NY+(j-1)*NX+i,1)=(k-1)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i;   % Global number of node 1 of each cell
            T((k-1)*NX*NY+(j-1)*NX+i,2)=(k-1)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i+1; % Global number of node 2 of each cell
            T((k-1)*NX*NY+(j-1)*NX+i,3)=(k-1)*(NX+1)*(NY+1)+(j)*(NX+1)+i+1;   % Global number of node 3 of each cell
            T((k-1)*NX*NY+(j-1)*NX+i,4)=(k-1)*(NX+1)*(NY+1)+(j)*(NX+1)+i;     % Global number of node 4 of each cell
            T((k-1)*NX*NY+(j-1)*NX+i,5)=(k)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i;     % Global number of node 5 of each cell
            T((k-1)*NX*NY+(j-1)*NX+i,6)=(k)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i+1;   % Global number of node 6 of each cell
            T((k-1)*NX*NY+(j-1)*NX+i,7)=(k)*(NX+1)*(NY+1)+(j)*(NX+1)+i+1;     % Global number of node 7 of each cell
            T((k-1)*NX*NY+(j-1)*NX+i,8)=(k)*(NX+1)*(NY+1)+(j)*(NX+1)+i;       % Global number of node 8 of each cell
            %--------------------------------------------------------------%
            NE_DX((k-1)*NX*NY+(j-1)*NX+i)=DX(i);               % Length of each cell in X direction
            NE_DY((k-1)*NX*NY+(j-1)*NX+i)=DY(j);               % Length of each cell in Y direction
            NE_DZ((k-1)*NX*NY+(j-1)*NX+i)=DZ(k);               % Length of each cell in Z direction
            %--------------------------------------------------------------%
        end
    end
end

%--------------------------------------------------------------------------%
% Draw the model diagram
% MESH_plot_rho(NX,NY,NZ,DX,DY,DZ,NPML_X,NPML_Y,NPML_Z,N_air,sigma,sigma_background,Point,T)
%--------------------------------------------------------------------------%
EDGE=zeros(NE,12); % Global edge number corresponding to 12 edges of each cell
%----------------------------%
for k=1:NZ
    for i=1:NX
        for j=1:NY
            L1=(k-1)*NX*(NY+1)+(j-1)*NX+i;                     % edge 1 of this cell
            L2=(k-1)*NX*(NY+1)+j*NX+i;                         % edge 2 of this cell
            L3=k*NX*(NY+1)+(j-1)*NX+i;                         % edge 3 of this cell
            L4=k*NX*(NY+1)+j*NX+i;                             % edge 4 of this cell
            
            EDGE((k-1)*(NX*NY)+(j-1)*(NX)+i,[1,2,3,4])=[L1,L2,L3,L4];% assembly
        end
    end
end

clear L1 L2 L3 L4
%----------------------------%
for k=1:NZ
    for i=1:NX
        for j=1:NY
            L5=NX*(NY+1)*(NZ+1)+(k-1)*NY*(NX+1)+(i-1)*NY+j;    % edge 5 of this cell
            L6=NX*(NY+1)*(NZ+1)+k*NY*(NX+1)+(i-1)*NY+j;        % edge 6 of this cell
            L7=NX*(NY+1)*(NZ+1)+(k-1)*NY*(NX+1)+i*NY+j;        % edge 7 of this cell
            L8=NX*(NY+1)*(NZ+1)+k*NY*(NX+1)+i*NY+j;            % edge 8 of this cell
            
            EDGE((k-1)*(NX*NY)+(j-1)*(NX)+i,[5,6,7,8])=[L5,L6,L7,L8]; % assembly
        end
    end
end

clear L5 L6 L7 L8
%----------------------------%
for k=1:NZ
    for i=1:NX
        for j=1:NY
            L9=(2*NX*NY+NX+NY)*(NZ+1)+(k-1)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i;    % edge 9 of this cell
            L10=(2*NX*NY+NX+NY)*(NZ+1)+(k-1)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i+1; % edge 10 of this cell
            L11=(2*NX*NY+NX+NY)*(NZ+1)+(k-1)*(NX+1)*(NY+1)+(j)*(NX+1)+i;     % edge 11 of this cell
            L12=(2*NX*NY+NX+NY)*(NZ+1)+(k-1)*(NX+1)*(NY+1)+(j)*(NX+1)+i+1;   % edge 12 of this cell
            
            EDGE((k-1)*(NX*NY)+(j-1)*(NX)+i,[9,10,11,12])=[L9,L10,L11,L12]; % assembly
        end
    end
end

clear L9 L10 L11 L12
%----------------------------%
%--------------------------------------------------------------------------%
NUM_EDGE=(2*NX*NY+NX+NY)*(NZ+1)+(NX+1)*(NY+1)*NZ;  %Total number of edges


NUM_EDGE_SOURCE=(2*NX*NY+NX+NY)*(NZ+1)+((NX+1)*(NY+1)*NZ+1)/2;  % Node location of current source

% % na=NY/2;  % ������ڵ�������Ԫ�ϣ�����˼�Ǽ��ڵ��ĸ������.
% % NUM_EDGE_SOURCE=(2*NX*NY+NX+NY)*(NZ+1)+(NZ-1)/2*(NX+1)*(NY+1)+na*(NX+1)+(NX)/2+1;
%
% na=NPML_Y+4;  % ������ڵ�������Ԫ�ϣ�����˼�Ǽ��ڵ��ĸ������.
% NUM_EDGE_SOURCE=(2*NX*NY+NX+NY)*(NZ+1)+(NZ-1)/2*(NX+1)*(NY+1)+na*(NX+1)+(NX)/2+1;
%--------------------------------------------------------------------------%
Top_E=1:NX*NY;                      % Topmost cell
Bottom_E=NX*NY*(NZ-1)+1:NX*NY*NZ;   % Bottommost cell
Front_E=zeros(NZ,NX);               % Foremost cell
Behind_E=zeros(NZ,NX);              % Backmost cell
Left_E=zeros(NZ,NY);                % Leftmost cell
Right_E=zeros(NZ,NY);               % Rightmost cell
for i=1:NZ
    Front_E(i,:)=NX*NY-NX+1+(i-1)*(NX*NY):NX*NY+(i-1)*(NX*NY);
    Behind_E(i,:)=1+(i-1)*(NX*NY):NX+(i-1)*(NX*NY);
    Left_E(i,:)=1+(i-1)*(NX*NY):NX:NX*NY-NX+1+(i-1)*(NX*NY);
    Right_E(i,:)=NX+(i-1)*(NX*NY):NX:NX*NY+(i-1)*(NX*NY);
end
%--------------------------------------------------------------------------%
Top_x=unique(EDGE(Top_E,[1,2]));                % Topmost x-direction edge
Bottom_x=unique(EDGE(Bottom_E,[3,4]));          % Bottommost x-direction edge
Front_x=unique(EDGE(Front_E,[2,4]));
Behind_x=unique(EDGE(Behind_E,[1,3]));

Top_y=unique(EDGE(Top_E,[5,7]));                % Topmost y-direction edge
Bottom_y=unique(EDGE(Bottom_E,[6,8]));          % Bottommost y-direction edge
Left_y=unique(EDGE(Left_E,[5,6]));
Right_y=unique(EDGE(Right_E,[7,8]));

Right_z=unique(EDGE(Right_E,[10,12]));
Left_z=unique(EDGE(Left_E,[9,11]));
Front_z=unique(EDGE(Front_E,[11,12]));
Behind_z=unique(EDGE(Behind_E,[9,10]));

outer_x=unique([Top_x;Bottom_x;Front_x;Behind_x]);
outer_y=unique([Top_y;Bottom_y;Left_y;Right_y]);
outer_z=unique([Right_z;Left_z;Front_z;Behind_z]);
%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
EDGE_all_x=unique(EDGE(:,1:4));                       % All x edges
EDGE_all_y=unique(EDGE(:,5:8));                       % All y edges
EDGE_all_z=unique(EDGE(:,9:12));                      % All z edges
%--------------------------------------------------------------------------%
% MESH_plot(Point,T,top_E,Front_E,Right_E,Air_DZ);    % plot mesh
%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
Exyz=zeros(NUM_EDGE,1);                               % Electric field of all edges
%--------------------------------------------------------------------------%
t1=EDGE(:,repmat((1:12)',12,1))';           % Coordinates required for the assembly of Ke or Me of each cell into K or M
t2=EDGE(:,reshape(repmat(1:12,12,1),[],1))';% Coordinates required for the assembly of Ke or Me of each cell into K or M
%--------------------------------------------------------------------------%
% These parameters are described in detail in many finite element method books and articles, and are not commented in detail
K1=[2,-2,1,-1;-2,2,-1,1;1,-1,2,-2;-1,1,-2,2];
K2=[2,1,-2,-1;1,2,-1,-2;-2,-1,2,1;-1,-2,1,2];
K3=[2,1,-2,-1;-2,-1,2,1;1,2,-1,-2;-1,-2,1,2];

%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
Ez_Grid_Extension=zeros(NY+1,length(freq));
%--------------------------------------------------------------------------%
for nf=1:length(freq)
    
    disp('Current calculated frequency:');
    disp(['==>',num2str(freq(nf)),' Hz','<==']);
    disp(['Skin Depth:',num2str(503*sqrt((1/sigma_background)/freq(nf))),' m']);
    %--------------------------------------------------------------------------%
    % Conduction current/Displacement current
    rate=mean(mean(mean(sigma)))./(2*pi*freq(nf)*eps0);
    disp('-----------------------------------------')
    disp('Conduction current/Displacement current:');
    disp(num2str(rate));
    %--------------------------------------------------------------------------%
    % Wave length
    Wavelength=2*pi./(2*pi*freq(nf).*sqrt((miu0*eps0/2)*(sqrt(1+(sigma(1)./(2*pi*freq(nf)*eps0)).^2)+1)));
    disp('-----------------------------------------')
    disp('Wavelength:');
    disp([num2str(Wavelength),' m']);
    disp('-----------------------------------------')
    
    tic;
    %--------------------------------------------------------------------------%
    omega=2*pi*freq(nf);         % Angular frequency
    %--------------------------------------------------------------------------%
    % Stiffness Matrix
    
    Ke=zeros(144,NE);
    for i=1:NE
        
        Ke1212=zeros(12,12);
        
        Ke1212(1:4,1:4)   = (NE_DX(i)*NE_DZ(i)/6/NE_DY(i))*K1 + (NE_DX(i)*NE_DY(i)/6/NE_DZ(i))*K2;   %Eexx
        Ke1212(5:8,5:8)   = (NE_DY(i)*NE_DX(i)/6/NE_DZ(i))*K1 + (NE_DY(i)*NE_DZ(i)/6/NE_DX(i))*K2;   %Eeyy
        Ke1212(9:12,9:12) = (NE_DZ(i)*NE_DY(i)/6/NE_DX(i))*K1 + (NE_DZ(i)*NE_DX(i)/6/NE_DY(i))*K2;   %Eezz
        
        Ke1212(1:4,5:8)=  (-NE_DZ(i)/6)*K3;
        Ke1212(5:8,1:4)=  (-NE_DZ(i)/6)*K3';
        Ke1212(5:8,9:12)= (-NE_DX(i)/6)*K3;
        Ke1212(9:12,5:8)= (-NE_DX(i)/6)*K3';
        Ke1212(9:12,1:4)= (-NE_DY(i)/6)*K3;
        Ke1212(1:4,9:12)= (-NE_DY(i)/6)*K3';
        
        Ke(:,i)= reshape(Ke1212,144,1);
        
    end
    
    K=sparse(t1,t2,Ke,NUM_EDGE,NUM_EDGE);  % Assembled K matrix
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    % Mass Matrix
    
    M1=[4,2,2,1;2,4,1,2;2,1,4,2;1,2,2,4];
    
    Me=zeros(144,NE);
    for i=1:NE
        
        Me_temp=zeros(12,12);
        
        Me_temp(1:4,1:4)  = (-omega*omega*eps0*miu0+1i*omega*miu0*sigma(i))*M1;
        Me_temp(5:8,5:8)  = (-omega*omega*eps0*miu0+1i*omega*miu0*sigma(i))*M1;
        Me_temp(9:12,9:12)= (-omega*omega*eps0*miu0+1i*omega*miu0*sigma(i))*M1;
        
        Me1212=(NE_DX(i)*NE_DY(i)*NE_DZ(i)/36)*Me_temp;
        Me(:,i)= reshape(Me1212,144,1);
        
    end
    
    M=sparse(t1,t2,Me,NUM_EDGE,NUM_EDGE); % Assembled M matrix
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    HH=K+M;
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    P=sparse(NUM_EDGE,1);
    
    P(NUM_EDGE_SOURCE)=-1i*omega*miu0*I0*dL;
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    % Imposes the First-order boundary condition (PEC boundary condition)
    for i=1:length(Top_x)
        HH(Top_x(i),Top_x(i))=HH(Top_x(i),Top_x(i))*10^10;
        P(Top_x(i))=0;
    end
    
    for i=1:length(Top_y)
        HH(Top_y(i),Top_y(i))=HH(Top_y(i),Top_y(i))*10^10;
        P(Top_y(i))=0;
    end
    
    for i=1:length(Bottom_x)
        HH(Bottom_x(i),Bottom_x(i))=HH(Bottom_x(i),Bottom_x(i))*10^10;
        P(Bottom_x(i))=0;
    end
    
    for i=1:length(Bottom_y)
        HH(Bottom_y(i),Bottom_y(i))=HH(Bottom_y(i),Bottom_y(i))*10^10;
        P(Bottom_y(i))=0;
    end
    
    for i=1:length(Left_y)
        HH(Left_y(i),Left_y(i))=HH(Left_y(i),Left_y(i))*10^10;
        P(Left_y(i))=0;
    end
    
    for i=1:length(Right_y)
        HH(Right_y(i),Right_y(i))=HH(Right_y(i),Right_y(i))*10^10;
        P(Right_y(i))=0;
    end
    
    for i=1:length(Front_x)
        HH(Front_x(i),Front_x(i))=HH(Front_x(i),Front_x(i))*10^10;
        P(Front_x(i))=0;
    end
    
    for i=1:length(Behind_x)
        HH(Behind_x(i),Behind_x(i))=HH(Behind_x(i),Behind_x(i))*10^10;
        P(Behind_x(i))=0;
    end
    
    for i=1:length(outer_z)
        HH(outer_z(i),outer_z(i))=HH(outer_z(i),outer_z(i))*10^10;
        P(outer_z(i))=0;
    end
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    
    disp('Start solving the system of equations:');
    
    if solve_choice==1
        %--------------------------------------------------------------------------%
        % [Direct solution method]
        disp('Direct solution!')
        disp('waiting...');
        Exyz=HH\P;
        %--------------------------------------------------------------------------%
    else
        %--------------------------------------------------------------------------%
        % [Iterative solution method]
        tol = 1e-40;% tolerance error
        %--------------------------------------------------------------------------%
        % SSOR pre-processed bicgstab iterative solution (by Huang Xiangyu)
        Dinv=sparse(1:length(HH),1:length(HH),diag(HH));
        ww=1; % super relaxation factor
        M=(ww*(tril(HH)-Dinv)+Dinv)/sqrt(Dinv)/sqrt(ww*(2-ww));
        %           % disp ('Bicgstab solution!')
        %         [Exyz_secondary,fl0,rr0,it0,rv0] =bicgstab(HH,P,tol,maxit,M,M.');
        disp ('QMR solution!')
        disp('waiting...');
        [Exyz,fl0,rr0,it0,rv0] =qmr(HH,P,tol,maxit,M,M.');
        %--------------------------------------------------------------------------%
        figure
        semilogy(rv0/norm(P),'-'); %
        xlabel('Iteration number');
        ylabel('Relative residual');
        %--------------------------------------------------------------------------%
    end
    
    disp('Calculation Finished!')
    toc
    disp('--------------------------------------------------------------------------')
    
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    % Analytical Solution; A book written in Chinese by Jishan He(Controllable source audio magnetotelluric method-page:36)
    k=sqrt(-1i*omega*miu0*sigma(1)); % Wave number
    R=y_axis(NPML_Y+1:end-NPML_Y);
    Ez_analysis=-1*((1/sigma(1))*I0*dL/(4*pi))*(1./(R.^3)).*exp(1i*k*R).*(1-1i*k*R-k*k*R.*R);
    
    k=omega*sqrt(miu0*(eps0-1i*sigma(1)/omega));% k=omega*sqrt(miu0*eps0);
    R=y_axis(NPML_Y+1:end-NPML_Y);
    % Ez_analysis1=(-1i*omega*I0*dL*miu0./(4*pi*R)).*(1+1i./(k*R)-1./((k*R).^2)).*exp(1i*k*R);
    Ez_analysis1=(-1i*omega*I0*dL*miu0./(4*pi*R)).*(1-1i./(k*R)-1./((k*R).^2)).*exp(-1i*k*R);
    %--------------------------------------------------------------------------%
    % drawing
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    EDGE_all_x_show=reshape(EDGE_all_x,[],1);
    Ex_show = Exyz(EDGE_all_x_show);
    Ex_show = full(Ex_show);
    Ex_show = reshape(Ex_show,NX,NY+1,NZ+1);
    
    EDGE_all_y_show=reshape(EDGE_all_y,[],1);
    Ey_show = Exyz(EDGE_all_y_show);
    Ey_show = full(Ey_show);
    Ey_show = reshape(Ey_show,NY,NX+1,NZ+1);
    
    EDGE_all_z_show=reshape(EDGE_all_z,[],1);
    Ez_show = Exyz(EDGE_all_z_show);
    Ez_show = full(Ez_show);
    Ez_show = reshape(Ez_show,NX+1,NY+1,NZ);
    %--------------------------------------------------------------------------%
    Ez_show_2D_XY=reshape(Ez_show(:,:,round((NZ+1)/2)),NX+1,NY+1);
    Ez_show_2D_XY=Ez_show_2D_XY.';
    
    Ez_show_2D_YZ=reshape(Ez_show(round((NX+1+1)/2),:,:),NY+1,NZ);
    Ez_show_2D_YZ=Ez_show_2D_YZ.';
    
    Ez_show_2D_XZ=reshape(Ez_show(:,round((NY+1+1)/2),:),NX+1,NZ);
    Ez_show_2D_XZ=Ez_show_2D_XZ.';
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    figure;
    
    subplot(3,1,1)
    %     surf([cumsum(DX)]-diff([0,cumsum(DX)])/2,[0,cumsum(DZ)],abs(Ex_secondary_show_2D_XZ));
    surf(abs(Ez_show_2D_XY));
    colormap jet
    colorbar
    xlabel('x(m)')
    ylabel('y(m)')
    % set(gca,'zscale','log')
    set(gca,'Linewidth',1.0,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    axis tight
    axis ij
    title(['The Ez filed-',num2str(freq(nf)),'Hz'])
    
    subplot(3,1,2)
    %     surf([0,cumsum(DY)],[0,cumsum(DZ)],abs(Ex_secondary_show_2D_YZ));
    surf(abs(Ez_show_2D_YZ));
    colormap jet
    colorbar
    xlabel('y(m)')
    ylabel('z(m)')
    % set(gca,'zscale','log')
    set(gca,'Linewidth',1.0,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    axis tight
    axis ij
    title(['The Ez filed-',num2str(freq(nf)),'Hz'])
    
    subplot(3,1,3)
    %     surf([cumsum(DX)]-diff([0,cumsum(DX)])/2,[0,cumsum(DZ)],abs(Ex_secondary_show_2D_XZ));
    surf(abs(Ez_show_2D_XZ));
    colormap jet
    colorbar
    xlabel('x(m)')
    ylabel('z(m)')
    % set(gca,'zscale','log')
    set(gca,'Linewidth',1.0,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    axis tight
    axis ij
    title(['The Ez filed-',num2str(freq(nf)),'Hz'])
    
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    
    figure;
    
    subplot(3,1,1)
    semilogy(z_axis,abs(reshape(Ez_show(round((NX+1+1)/2),round((NY+1+1)/2),:),[],1)),'-o','Linewidth',1);
    
    axis tight
    line([sum(DZ(1:NPML_Z))-sum(DZ)/2,sum(DZ(1:NPML_Z))-sum(DZ)/2],[0,max(max(max(abs(Ez_show))))],'color','k','Linewidth',1)
    line([sum(DZ(1:end-NPML_Z))-sum(DZ)/2,sum(DZ(1:end-NPML_Z))-sum(DZ)/2],[0,max(max(max(abs(Ez_show))))],'color','k','Linewidth',1)
    set(gca,'Linewidth',1.0,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    xlabel('z-axis');ylabel('Magnitude');title(['Ez Total Field in z direction','-',num2str(freq(nf)),'Hz'])
    
    %--------------------------------------------------------------------------%
    subplot(3,1,2)
    plot(y_axis(NPML_Y+1:end-NPML_Y),abs(reshape(Ez_show(round((NX+1+1)/2),NPML_Y+1:end-NPML_Y,round((NZ+1)/2)),[],1)),'-o','Linewidth',1);
    hold on
    plot(R,abs(Ez_analysis),'-o')
    
    line([sum(DY(1:NPML_Y))-sum(DY)/2,sum(DY(1:NPML_Y))-sum(DY)/2],[0,max(max(max(abs(Ez_show))))],'color','k','Linewidth',1)
    line([sum(DY(1:end-NPML_Y))-sum(DY)/2,sum(DY(1:end-NPML_Y))-sum(DY)/2],[0,max(max(max(abs(Ez_show))))],'color','k','Linewidth',1)
    set(gca,'Linewidth',1.0,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    xlabel('y-axis');ylabel('Magnitude');title(['Ez Total Field in y direction','-',num2str(freq(nf)),'Hz'])
    %--------------------------------------------------------------------------%
    
    subplot(3,1,3)
    semilogy(x_axis(NPML_Z+1:end-NPML_Z),abs(reshape(Ez_show(NPML_Z+1:end-NPML_Z,round((NY+1+1)/2),round((NZ+1)/2)),[],1)),'-o','Linewidth',1);
    hold on
    plot(R,Ez_analysis,'-o')
    
    line([sum(DX(1:NPML_X))-sum(DX)/2,sum(DX(1:NPML_X))-sum(DX)/2],[0,max(max(max(abs(Ez_show))))],'color','k','Linewidth',1)
    line([sum(DX(1:end-NPML_X))-sum(DX)/2,sum(DX(1:end-NPML_X))-sum(DX)/2],[0,max(max(max(abs(Ez_show))))],'color','k','Linewidth',1)
    set(gca,'Linewidth',1.0,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    xlabel('x-axis');ylabel('Magnitude');title(['Ez Total Field in x direction','-',num2str(freq(nf)),'Hz'])
    
    % saveas(gcf,[strrep(['The Ex Field in different direction at ',num2str(freq(nf)),'Hz' ],'.','dot'),'.fig'])
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    [X,Y,Z]=meshgrid(1:NY+1,1:NX,1:NZ+1);
    
    figure;
    slice(X,Y,Z,abs(log10(Ex_show)),[round((NY+1)/2)],[round((NX+1)/2)],[round(NZ/2)])
    view(-100,15)
    xlabel('y axis')
    ylabel('x axis')
    title('log10(Ex)-Total Field')
    set(gca,'zdir','reverse')
    colorbar
    colormap jet
    set(gca,'Linewidth',1.0,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    % saveas(gcf,[strrep(['The Ex-Total Field at ',num2str(freq(nf)),'Hz' ],'.','dot'),'.fig'])
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    
    figure;
    slice(abs(log10(Ey_show)),[round(NX/2)],[round(NY/2)],[round(NZ/2)])
    title('log10(Ey)-Total Field')
    set(gca,'zdir','reverse')
    xlabel('x axis')
    ylabel('y axis')
    colorbar
    colormap jet
    set(gca,'Linewidth',1.0,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    % saveas(gcf,[strrep(['The Ey-Total Field at ',num2str(freq(nf)),'Hz' ],'.','dot'),'.fig'])
    %--------------------------------------------------------------------------%
    
    figure;
    slice(abs(log10(Ez_show)),[round(NY/2)],[round(NX/2)],[round(NZ/2)])
    title('log10(Ez)-Total Field')
    set(gca,'zdir','reverse')
    xlabel('y axis')
    ylabel('x axis')
    colorbar
    colormap jet
    set(gca,'Linewidth',1.0,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    % saveas(gcf,[strrep(['The Ez-Total Field at ',num2str(freq(nf)),'Hz' ],'.','dot'),'.fig'])
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    
    Ez_numerical=reshape(Ez_show(round((NX+1+1)/2),:,round((NZ+1)/2)),[],1);
    %--------------------------------------------------%
    %--------------------------------------------------%
    figure;
    
    p1=plot(y_axis,abs(Ez_numerical),'-*','Linewidth',1.0);
    hold on
    p2=plot(R,abs(Ez_analysis),'-o','Linewidth',1.0);
    hold off
    
    line([y_axis(NPML_Y+1),y_axis(NPML_Y+1)],[0,1.2*max(max(max(abs(Ez_show))))],'color','k','Linewidth',1)
    line([y_axis(end-NPML_Y),y_axis(end-NPML_Y)],[0,1.2*max(max(max(abs(Ez_show))))],'color','k','Linewidth',1)
    
    legend([p1 p2],{'Grid Extension','Analytic Solution'},'Location','north','FontSize',10)
    legend('boxoff')
    
    text(y_axis(NPML_Y-2),0.6*max(max(max(abs(Ez_show)))),'Grid Extension Region','HorizontalAlignment','center','FontName','Times new roman','FontSize',10)
    text(y_axis(end-NPML_Y+3),0.6*max(max(max(abs(Ez_show)))),'Grid Extension Region','HorizontalAlignment','center','FontName','Times new roman','FontSize',10)
    
    xlabel('r(m)');ylabel('Electric Field(V/m)');
    set(gca,'Linewidth',1.0,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    xlabel('y-axis');ylabel('Magnitude');title(['Ez Total Field in y direction','-',num2str(freq(nf)),'Hz'])
    xlim([4*min(R),4*max(R)])
    ylim([0,1.2*max(max(max(abs(Ez_show))))])
    
    % saveas(gcf,['Comparision-Analytical Solution-Grid Extension',num2str(freq(nf)),'Hz','.fig'])
    
    %--------------------------------------------------%
    %--------------------------------------------------%
    % Analytic solution is singular at r = 0
    TempA=Ez_numerical((end+1)/2+1:end-NPML_Y).';
    TempB=Ez_analysis((end+1)/2+1:end);
    
    Relative_Error=abs(abs(TempA)-abs(TempB))./max(abs(TempB));
    
    gcf=figure;
    
    subplot(3,1,1)
    plot(y_axis((end+1)/2+1:end-NPML_Y),abs(TempA),'-*','Linewidth',1.5)
    hold on
    plot(y_axis((end+1)/2+1:end-NPML_Y),abs(TempB),'-o','Linewidth',1.5)
    xlabel('r(m)');ylabel('Electric Field(V/m)');
    set(gca,'Linewidth',1.0,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    
    subplot(3,1,2)
    plot(y_axis((end+1)/2+1:end-NPML_Y),Relative_Error,'-o','Linewidth',1.5)
    axis tight
    xlabel('r(m)');ylabel('Relative Error(dB)');
    set(gca,'Linewidth',1.0,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    
    subplot(3,1,3)
    plot(y_axis((end+1)/2+1:end-NPML_Y),20*log10(Relative_Error),'-o','Linewidth',1.5)
    axis tight
    xlabel('r(m)');ylabel('Relative Error(dB)');
    set(gca,'Linewidth',1.0,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    
    saveas(gcf,['Relative-Error-Analytical Solution-Grid Extension',num2str(freq(nf)),'Hz','.fig'])
    
    
    %--------------------------------------------------%
    % record the field value of Grid Extension method
    Ez_Grid_Extension(:,nf)=Ez_numerical;
    %--------------------------------------------------%
    
end




%--------------------------------------------------%
%--------------------------------------------------%

y_axis_Grid_Extension=y_axis;
NPML_Y_Grid_Extension=NPML_Y;
save Ez_Grid_Extension Ez_Grid_Extension y_axis_Grid_Extension NPML_Y_Grid_Extension




