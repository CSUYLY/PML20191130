%-------------------------------------------------------------------------%
% This code tests the truncation effect of low-frequency PML in the 
% three-dimensional radiation problem. The finite element simulation results
% with PML are compared with traditional grid extension method.
%-------------------------------------------------------------------------%
% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
%                            DON'T RUN THIS CODE
% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
% Since this code uses the direct method to solve the system of equations,
% it is very memory intensive. I run this program on a server with very
% large memory. If you have a particularly large server, you can try 
% running this program. If you have a good iterative method for solving 
% the system of equations, you can modify this code and then run it on your
% personal computer, otherwise your personal computer will crash!
%-------------------------------------------------------------------------%
%                             Nov. 29, 2019
%                       Liangyong Yang (PhD student)
%     Institute of Geology and Geophysics, Chinese Academy of Sciences
%                Emails: yangliangyong15@mails.ucas.ac.cn
%-------------------------------------------------------------------------%
%                          ������ (�ڶ���ʿ�о���)
%                      �й���ѧԺ��������������о���
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%

clear;
clc;
close all;
warning off
disp('PML Method')
% profile on -memory
%--------------------------------------------------------------------------%
I0=100;
dL=0.01;
%--------------------------------------------------------------------------%
find_kappa=-0.2;         % The optimal value of kappa
find_sigma=1.00;         % The optimal value of sigma
find_alpha=1.60;         % The optimal value of alpha
%--------------------------------------------------------------------------%
% [Field source is set at Z direction]

N_MODEL_X = 20; % number of grids in X direction; horizontal to the right% [even number]
N_MODEL_Y = 60; % number of grids in Y direction; vertical to the paper face% [even number]
N_MODEL_Z = 11;  % number of grids in Z direction; vertical up% [odd number]

% N_MODEL_X = 8; % number of grids in X direction; horizontal to the right% [even number]
% N_MODEL_Y = 14; % number of grids in Y direction; vertical to the paper face% [even number]
% N_MODEL_Z = 5;  % number of grids in Z direction; vertical up% [odd number]

NPML_X = 12;
NPML_Y = 12;
NPML_Z = 12;

NX = N_MODEL_X + 2 * NPML_X;% number of grids in X direction; horizontal to the right% [odd number]
NY = N_MODEL_Y + 2 * NPML_Y;% number of grids in Y direction; vertical to the paper face% [even number]
NZ = N_MODEL_Z + 2 * NPML_Z;% number of grids in Z direction; vertical up% [odd number]
%--------------------------------------------------------------------------%
solve_choice = 1; % directly solve when solve_choice = 1 (fast, memory-consuming, accurate); solve iteratively when solve_choice = 2 (slow, small memory, inaccurate);
maxit = 5000;% maximum iterations
%----------------------------------------------------------------------------------------%
freq=1e5; % [1e5,1e7]; % Frequency
%----------------------------------------------------------------------------------------%
main_dx = 0.01;  % grid spacing in X direction
main_dy = 0.01;  % grid spacing in Y direction
main_dz = 0.01;  % grid spacing in Z direction

PML_thickness=0.002;
DX=[PML_thickness*ones(1,NPML_X),main_dx*ones(1,N_MODEL_X),PML_thickness*ones(1,NPML_X)];
DY=[PML_thickness*ones(1,NPML_Y),main_dy*ones(1,N_MODEL_Y),PML_thickness*ones(1,NPML_Y)];
DZ=[PML_thickness*ones(1,NPML_Z),main_dz*ones(1,N_MODEL_Z),PML_thickness*ones(1,NPML_Z)];
%----------------------------------------------------------------------------------------%
%----------------------------------------------------------------------------------------%
x_axis=[0,cumsum(DX)]-max(cumsum(DX))/2;  % X coordinate of each edge
y_axis=[0,cumsum(DY)]-max(cumsum(DY))/2;  % Y coordinate of each edge
z_axis=cumsum(DZ)-DZ/2-sum(DZ)/2;         % Z coordinate of each edge
%--------------------------------------------------------------------------%
NE=NX*NY*NZ;               % total units
NP=(NX+1)*(NY+1)*(NZ+1);   % total nodes

eps0=1/(36*pi)*1e-9;       % dielectric constant of vacuum
miu0=pi*4e-7;              % vacuum permeability
%--------------------------------------------------------------------------%
sigma_background=(1/1);    % Conductivity of background medium
sigma=sigma_background*ones(NX,NY,NZ);
%--------------------------------------------------------------------------%
sigma=reshape(sigma,[],1);
%--------------------------------------------------------------------------%
Point=zeros(NP,3);  % Coordinates of each node

Point(:,1)=repmat(([0,cumsum(DX)])',NP/(NX+1),1);                       % X coordinate of each node
Point(:,2)=repmat(reshape(repmat([0,cumsum(DY)],NX+1,1),[],1),NZ+1,1);  % Y coordinate of each node
Point(:,3)=reshape(repmat([0,cumsum(DZ)],(NX+1)*(NY+1),1),[],1);        % Z coordinate of each node
%--------------------------------------------------------------------------%
NE_DX = zeros(1,NE); % length of each cell
NE_DY = zeros(1,NE); % width of each cell
NE_DZ = zeros(1,NE); % height of each cell
T = zeros(NE,8);     % Corresponding Global number of 8 Local node number of each cell

for k=1:NZ
    for j=1:NY
        for i=1:NX
            %--------------------------------------------------------------%
            T((k-1)*NX*NY+(j-1)*NX+i,1)=(k-1)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i;   % Global number of node 1 of each cell
            T((k-1)*NX*NY+(j-1)*NX+i,2)=(k-1)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i+1; % Global number of node 2 of each cell
            T((k-1)*NX*NY+(j-1)*NX+i,3)=(k-1)*(NX+1)*(NY+1)+(j)*(NX+1)+i+1;   % Global number of node 3 of each cell
            T((k-1)*NX*NY+(j-1)*NX+i,4)=(k-1)*(NX+1)*(NY+1)+(j)*(NX+1)+i;     % Global number of node 4 of each cell
            T((k-1)*NX*NY+(j-1)*NX+i,5)=(k)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i;     % Global number of node 5 of each cell
            T((k-1)*NX*NY+(j-1)*NX+i,6)=(k)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i+1;   % Global number of node 6 of each cell
            T((k-1)*NX*NY+(j-1)*NX+i,7)=(k)*(NX+1)*(NY+1)+(j)*(NX+1)+i+1;     % Global number of node 7 of each cell
            T((k-1)*NX*NY+(j-1)*NX+i,8)=(k)*(NX+1)*(NY+1)+(j)*(NX+1)+i;       % Global number of node 8 of each cell
            %--------------------------------------------------------------%
            NE_DX((k-1)*NX*NY+(j-1)*NX+i)=DX(i);               % Length of each cell in X direction
            NE_DY((k-1)*NX*NY+(j-1)*NX+i)=DY(j);               % Length of each cell in Y direction
            NE_DZ((k-1)*NX*NY+(j-1)*NX+i)=DZ(k);               % Length of each cell in Z direction
            %--------------------------------------------------------------%
        end
    end
end

%--------------------------------------------------------------------------%
% Draw the model diagram
% MESH_plot_rho(NX,NY,NZ,DX,DY,DZ,NPML_X,NPML_Y,NPML_Z,N_air,sigma,sigma_background,Point,T)
%--------------------------------------------------------------------------%
EDGE=zeros(NE,12); % Global edge number corresponding to 12 edges of each cell
%----------------------------%
for k=1:NZ
    for i=1:NX
        for j=1:NY
            L1=(k-1)*NX*(NY+1)+(j-1)*NX+i;                     % edge 1 of this cell
            L2=(k-1)*NX*(NY+1)+j*NX+i;                         % edge 2 of this cell
            L3=k*NX*(NY+1)+(j-1)*NX+i;                         % edge 3 of this cell
            L4=k*NX*(NY+1)+j*NX+i;                             % edge 4 of this cell
            
            EDGE((k-1)*(NX*NY)+(j-1)*(NX)+i,[1,2,3,4])=[L1,L2,L3,L4];% assembly
        end
    end
end

clear L1 L2 L3 L4
%----------------------------%
for k=1:NZ
    for i=1:NX
        for j=1:NY
            L5=NX*(NY+1)*(NZ+1)+(k-1)*NY*(NX+1)+(i-1)*NY+j;    % edge 5 of this cell
            L6=NX*(NY+1)*(NZ+1)+k*NY*(NX+1)+(i-1)*NY+j;        % edge 6 of this cell
            L7=NX*(NY+1)*(NZ+1)+(k-1)*NY*(NX+1)+i*NY+j;        % edge 7 of this cell
            L8=NX*(NY+1)*(NZ+1)+k*NY*(NX+1)+i*NY+j;            % edge 8 of this cell
            
            EDGE((k-1)*(NX*NY)+(j-1)*(NX)+i,[5,6,7,8])=[L5,L6,L7,L8]; % assembly
        end
    end
end

clear L5 L6 L7 L8
%----------------------------%
for k=1:NZ
    for i=1:NX
        for j=1:NY
            L9=(2*NX*NY+NX+NY)*(NZ+1)+(k-1)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i;    % edge 9 of this cell
            L10=(2*NX*NY+NX+NY)*(NZ+1)+(k-1)*(NX+1)*(NY+1)+(j-1)*(NX+1)+i+1; % edge 10 of this cell
            L11=(2*NX*NY+NX+NY)*(NZ+1)+(k-1)*(NX+1)*(NY+1)+(j)*(NX+1)+i;     % edge 11 of this cell
            L12=(2*NX*NY+NX+NY)*(NZ+1)+(k-1)*(NX+1)*(NY+1)+(j)*(NX+1)+i+1;   % edge 12 of this cell
            
            EDGE((k-1)*(NX*NY)+(j-1)*(NX)+i,[9,10,11,12])=[L9,L10,L11,L12]; % assembly
        end
    end
end

clear L9 L10 L11 L12
%----------------------------%
%--------------------------------------------------------------------------%
NUM_EDGE=(2*NX*NY+NX+NY)*(NZ+1)+(NX+1)*(NY+1)*NZ;  %Total number of edges

NUM_EDGE_SOURCE=(2*NX*NY+NX+NY)*(NZ+1)+((NX+1)*(NY+1)*NZ+1)/2;  % Node location of current source
%--------------------------------------------------------------------------%
Top_E=1:NX*NY;                      % Topmost cell
Bottom_E=NX*NY*(NZ-1)+1:NX*NY*NZ;   % Bottommost cell
Front_E=zeros(NZ,NX);               % Foremost cell
Behind_E=zeros(NZ,NX);              % Backmost cell
Left_E=zeros(NZ,NY);                % Leftmost cell
Right_E=zeros(NZ,NY);               % Rightmost cell
for i=1:NZ
    Front_E(i,:)=NX*NY-NX+1+(i-1)*(NX*NY):NX*NY+(i-1)*(NX*NY);
    Behind_E(i,:)=1+(i-1)*(NX*NY):NX+(i-1)*(NX*NY);
    Left_E(i,:)=1+(i-1)*(NX*NY):NX:NX*NY-NX+1+(i-1)*(NX*NY);
    Right_E(i,:)=NX+(i-1)*(NX*NY):NX:NX*NY+(i-1)*(NX*NY);
end
%--------------------------------------------------------------------------%
Top_x=unique(EDGE(Top_E,[1,2]));                % Topmost x-direction edge
Bottom_x=unique(EDGE(Bottom_E,[3,4]));          % Bottommost x-direction edge
Front_x=unique(EDGE(Front_E,[2,4]));
Behind_x=unique(EDGE(Behind_E,[1,3]));

Top_y=unique(EDGE(Top_E,[5,7]));                % Topmost y-direction edge
Bottom_y=unique(EDGE(Bottom_E,[6,8]));          % Bottommost y-direction edge
Left_y=unique(EDGE(Left_E,[5,6]));
Right_y=unique(EDGE(Right_E,[7,8]));

Right_z=unique(EDGE(Right_E,[10,12]));
Left_z=unique(EDGE(Left_E,[9,11]));
Front_z=unique(EDGE(Front_E,[11,12]));
Behind_z=unique(EDGE(Behind_E,[9,10]));

outer_x=unique([Top_x;Bottom_x;Front_x;Behind_x]);
outer_y=unique([Top_y;Bottom_y;Left_y;Right_y]);
outer_z=unique([Right_z;Left_z;Front_z;Behind_z]);
%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
EDGE_all_x=unique(EDGE(:,1:4));                       % All x edges
EDGE_all_y=unique(EDGE(:,5:8));                       % All y edges
EDGE_all_z=unique(EDGE(:,9:12));                      % All z edges
%--------------------------------------------------------------------------%
% MESH_plot(Point,T,top_E,Front_E,Right_E,Air_DZ);    % plot mesh
%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
Exyz=zeros(NUM_EDGE,1);                               % Electric field of all edges
%--------------------------------------------------------------------------%
t1=EDGE(:,repmat((1:12)',12,1))';           % Coordinates required for the assembly of Ke or Me of each cell into K or M
t2=EDGE(:,reshape(repmat(1:12,12,1),[],1))';% Coordinates required for the assembly of Ke or Me of each cell into K or M
%--------------------------------------------------------------------------%
% These parameters are described in detail in many finite element method books and articles, and are not commented in detail
K1=[2,-2,1,-1;-2,2,-1,1;1,-1,2,-2;-1,1,-2,2];
K2=[2,1,-2,-1;1,2,-1,-2;-2,-1,2,1;-1,-2,1,2];
K3=[2,1,-2,-1;-2,-1,2,1;1,2,-1,-2;-1,-2,1,2];

%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
for nf=1:length(freq)
    
    disp('Current calculated frequency:');
    disp(['==>',num2str(freq(nf)),' Hz','<==']);
    disp(['Skin Depth:',num2str(503*sqrt((1/sigma_background)/freq(nf))),' m']);
    %--------------------------------------------------------------------------%
    % Conduction current/Displacement current
    rate=mean(mean(mean(sigma)))./(2*pi*freq(nf)*eps0);
    disp('-----------------------------------------')
    disp('Conduction current/Displacement current:');
    disp(num2str(rate));
    %--------------------------------------------------------------------------%
    % Wave length
    Wavelength=2*pi./(2*pi*freq(nf).*sqrt((miu0*eps0/2)*(sqrt(1+(sigma(1)./(2*pi*freq(nf)*eps0)).^2)+1)));
    disp('-----------------------------------------')
    disp('Wavelength:');
    disp([num2str(Wavelength),' m']);
    disp('-----------------------------------------')
    
    tic;
    %--------------------------------------------------------------------------%
    omega=2*pi*freq(nf);         % Angular frequency
    %--------------------------------------------------------------------------%
    m=1;
    sigma_max = find_sigma*miu0*sqrt(miu0/eps0)/DZ(end);  % Maximum sigma value in PML
    kappa_max = find_kappa;                         % Maximum kappa value in PML
    alpha_max = find_alpha;                         % *freq(nf)^(-0.5); %Maximum alpha value in PML, it needs to be greater than 0, and need to be multiplied by freq(nf)^(-0.5) when there is a Direchlet condition.
    %--------------------------------------------------------------------------%
    xekappa = ones(1,NX);
    xesigma = zeros(1,NX);
    xealpha = zeros(1,NX);
    yekappa = ones(1,NY);
    yesigma = zeros(1,NY);
    yealpha = zeros(1,NY);
    zekappa = ones(1,NZ);
    zesigma = zeros(1,NZ);
    zealpha = zeros(1,NZ);
    %--------------------------------------------------------------------------%
    for i=1:NPML_X                                   % The left side PML
        distance=(NPML_X+0.5-i)/NPML_X;              % Normalized distance
        xesigma(1,i)=sigma_max*(exp(m*distance)-1);  % Exponential spatial scaling
        xekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
        xealpha(1,i)=alpha_max*(exp(m*(1-distance))-1);
    end
    
    for i=NPML_X+N_MODEL_X+1:NX                      % The right side PML
        distance=(i+0.5-(NX+1-NPML_X))/NPML_X;
        xesigma(1,i)=sigma_max*(exp(m*distance)-1);  % Exponential spatial scaling
        xekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
        xealpha(1,i)=alpha_max*(exp(m*(1-distance))-1);
    end
    
    for i=1:NPML_Y
        distance=(NPML_Y+0.5-i)/NPML_Y;
        yesigma(1,i)=sigma_max*(exp(m*distance)-1);  % Exponential spatial scaling
        yekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
        yealpha(1,i)=alpha_max*(exp(m*(1-distance))-1);
    end
    
    for i=NPML_Y+N_MODEL_Y+1:NY
        distance=(i+0.5-(NY+1-NPML_Y))/NPML_Y;
        yesigma(1,i)=sigma_max*(exp(m*distance)-1); % Exponential spatial scaling
        yekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
        yealpha(1,i)=alpha_max*(exp(m*(1-distance))-1);
    end
    
    for i=1:NPML_Z
        distance=(NPML_Z+0.5-i)/NPML_Z;
        zesigma(1,i)=sigma_max*(exp(m*distance)-1);  % Exponential spatial scaling
        zekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
        zealpha(1,i)=alpha_max*(exp(m*(1-distance))-1);
    end
    
    for i=NPML_Z+N_MODEL_Z+1:NZ
        distance=(i+0.5-(NZ+1-NPML_Z))/NPML_Z;
        zesigma(1,i)=sigma_max*(exp(m*distance)-1);  % Exponential spatial scaling
        zekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
        zealpha(1,i)=alpha_max*(exp(m*(1-distance))-1);
    end
    %--------------------------------------------------------------------------%
    Sex_origin = xekappa+(sqrt(2)*xesigma./((xealpha+1i).*sqrt(omega*eps0.*sigma_background)));
    Sex_origin = repmat(Sex_origin,[NY,1,NZ]);
    Sex_origin = reshape(permute(Sex_origin,[2,1,3]),1,[]);
    
    Sey_origin = yekappa+(sqrt(2)*yesigma./((yealpha+1i).*sqrt(omega*eps0.*sigma_background)));
    Sey_origin = repmat(Sey_origin.',[1,NX,NZ]);
    Sey_origin = reshape(permute(Sey_origin,[2,1,3]),1,[]);
    
    Sez_origin = zekappa+(sqrt(2)*zesigma./((zealpha+1i).*sqrt(omega*eps0.*sigma_background)));
    Sez_origin = repmat(Sez_origin.',1,[]);
    Sez_origin = repmat(reshape(Sez_origin,1,1,NZ),NY,NX);
    Sez_origin = reshape(Sez_origin,1,[]);
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    %     Sex_origin=ones(1,NE);
    %     Sey_origin=ones(1,NE);
    %     Sez_origin=ones(1,NE);
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    % Stiffness Matrix
    
    Ke=zeros(144,NE);
    for i=1:NE
        
        Ke1212=zeros(12,12);
        
        
        Ke1212(1:4,1:4)   = (Sez_origin(i)/(Sex_origin(i)*Sey_origin(i)))*(NE_DX(i)*NE_DZ(i)/6/NE_DY(i))*K1+(Sey_origin(i)/(Sez_origin(i)*Sex_origin(i)))*(NE_DX(i)*NE_DY(i)/6/NE_DZ(i))*K2;   %Eexx
        Ke1212(5:8,5:8)   = (Sex_origin(i)/(Sey_origin(i)*Sez_origin(i)))*(NE_DY(i)*NE_DX(i)/6/NE_DZ(i))*K1+(Sez_origin(i)/(Sex_origin(i)*Sey_origin(i)))*(NE_DY(i)*NE_DZ(i)/6/NE_DX(i))*K2;   %Eeyy
        Ke1212(9:12,9:12) = (Sey_origin(i)/(Sez_origin(i)*Sex_origin(i)))*(NE_DZ(i)*NE_DY(i)/6/NE_DX(i))*K1+(Sex_origin(i)/(Sey_origin(i)*Sez_origin(i)))*(NE_DZ(i)*NE_DX(i)/6/NE_DY(i))*K2;   %Eezz
        
        Ke1212(1:4,5:8)=(Sez_origin(i)/(Sex_origin(i)*Sey_origin(i)))*(-NE_DZ(i)/6)*K3;
        Ke1212(5:8,1:4)=(Sez_origin(i)/(Sex_origin(i)*Sey_origin(i)))*(-NE_DZ(i)/6)*K3';
        Ke1212(5:8,9:12)=(Sex_origin(i)/(Sey_origin(i)*Sez_origin(i)))*(-NE_DX(i)/6)*K3;
        Ke1212(9:12,5:8)=(Sex_origin(i)/(Sey_origin(i)*Sez_origin(i)))*(-NE_DX(i)/6)*K3';
        Ke1212(9:12,1:4)=(Sey_origin(i)/(Sez_origin(i)*Sex_origin(i)))*(-NE_DY(i)/6)*K3;
        Ke1212(1:4,9:12)=(Sey_origin(i)/(Sez_origin(i)*Sex_origin(i)))*(-NE_DY(i)/6)*K3';
        
        Ke(:,i)= reshape(Ke1212,144,1);
        
    end
    
    K=sparse(t1,t2,Ke,NUM_EDGE,NUM_EDGE);  % Assembled K matrix
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    % Mass Matrix
    
    M1=[4,2,2,1;2,4,1,2;2,1,4,2;1,2,2,4];
    
    Me=zeros(144,NE);
    for i=1:NE
        
        Me_temp=zeros(12,12);
        
        Me_temp(1:4,1:4)  = Sey_origin(i)*Sez_origin(i)/Sex_origin(i)*(-omega*omega*eps0*miu0+1i*omega*miu0*sigma(i))*M1;
        Me_temp(5:8,5:8)  = Sez_origin(i)*Sex_origin(i)/Sey_origin(i)*(-omega*omega*eps0*miu0+1i*omega*miu0*sigma(i))*M1;
        Me_temp(9:12,9:12)= Sex_origin(i)*Sey_origin(i)/Sez_origin(i)*(-omega*omega*eps0*miu0+1i*omega*miu0*sigma(i))*M1;
        
        Me1212=(NE_DX(i)*NE_DY(i)*NE_DZ(i)/36)*Me_temp;
        Me(:,i)= reshape(Me1212,144,1);
        
    end
    
    M=sparse(t1,t2,Me,NUM_EDGE,NUM_EDGE); % Assembled M matrix
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    HH=K+M;
    
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    P=sparse(NUM_EDGE,1);
    
    P(NUM_EDGE_SOURCE)=-1i*omega*miu0*I0*dL;
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    % Imposes the First-order boundary condition (PEC boundary condition)
    for i=1:length(Top_x)
        HH(Top_x(i),Top_x(i))=HH(Top_x(i),Top_x(i))*10^10;
        P(Top_x(i))=0;
    end
    
    for i=1:length(Top_y)
        HH(Top_y(i),Top_y(i))=HH(Top_y(i),Top_y(i))*10^10;
        P(Top_y(i))=0;
    end
    
    for i=1:length(Bottom_x)
        HH(Bottom_x(i),Bottom_x(i))=HH(Bottom_x(i),Bottom_x(i))*10^10;
        P(Bottom_x(i))=0;
    end
    
    for i=1:length(Bottom_y)
        HH(Bottom_y(i),Bottom_y(i))=HH(Bottom_y(i),Bottom_y(i))*10^10;
        P(Bottom_y(i))=0;
    end
    
    for i=1:length(Left_y)
        HH(Left_y(i),Left_y(i))=HH(Left_y(i),Left_y(i))*10^10;
        P(Left_y(i))=0;
    end
    
    for i=1:length(Right_y)
        HH(Right_y(i),Right_y(i))=HH(Right_y(i),Right_y(i))*10^10;
        P(Right_y(i))=0;
    end
    
    for i=1:length(Front_x)
        HH(Front_x(i),Front_x(i))=HH(Front_x(i),Front_x(i))*10^10;
        P(Front_x(i))=0;
    end
    
    for i=1:length(Behind_x)
        HH(Behind_x(i),Behind_x(i))=HH(Behind_x(i),Behind_x(i))*10^10;
        P(Behind_x(i))=0;
    end
    
    for i=1:length(outer_z)
        HH(outer_z(i),outer_z(i))=HH(outer_z(i),outer_z(i))*10^10;
        P(outer_z(i))=0;
    end
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    
    disp('Start solving the system of equations:');
    
    if solve_choice==1
        %--------------------------------------------------------------------------%
        % [Direct solution method]
        disp('Direct solution!')
        disp('waiting...');
        Exyz=HH\P;
        %--------------------------------------------------------------------------%
    else
        %--------------------------------------------------------------------------%
        % [Iterative solution method]
        tol = 1e-40;% tolerance error
        %--------------------------------------------------------------------------%
        % SSOR pre-processed bicgstab iterative solution (by Huang Xiangyu)
        Dinv=sparse(1:length(HH),1:length(HH),diag(HH));
        ww=1; % super relaxation factor
        M=(ww*(tril(HH)-Dinv)+Dinv)/sqrt(Dinv)/sqrt(ww*(2-ww));
        %           % disp ('Bicgstab solution!')
        %         [Exyz_secondary,fl0,rr0,it0,rv0] =bicgstab(HH,P,tol,maxit,M,M.');
        disp ('QMR solution!')
        disp('waiting...');
        [Exyz,fl0,rr0,it0,rv0] =qmr(HH,P,tol,maxit,M,M.');
        %--------------------------------------------------------------------------%
        figure
        semilogy(rv0/norm(P),'-'); %
        xlabel('Iteration number');
        ylabel('Relative residual');
        %--------------------------------------------------------------------------%
    end
    
    disp('Calculation Finished!')
    toc
    disp('--------------------------------------------------------------------------')
    
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    % Analytical Solution; A book written in Chinese by Jishan He(Controllable source audio magnetotelluric method-page:36)
    k=sqrt(-1i*omega*miu0*sigma(1)); % Wave number
    R=y_axis(NPML_Y+1:end-NPML_Y);
    Ez_analysis=-1*((1/sigma(1))*I0*dL/(4*pi))*(1./(R.^3)).*exp(1i*k*R).*(1-1i*k*R-k*k*R.*R);
    
    k=omega*sqrt(miu0*(eps0-1i*sigma(1)/omega));% k=omega*sqrt(miu0*eps0);
    R=y_axis(NPML_Y+1:end-NPML_Y);
    % Ez_analysis1=(-1i*omega*I0*dL*miu0./(4*pi*R)).*(1+1i./(k*R)-1./((k*R).^2)).*exp(1i*k*R);
    Ez_analysis1=(-1i*omega*I0*dL*miu0./(4*pi*R)).*(1-1i./(k*R)-1./((k*R).^2)).*exp(-1i*k*R);
    %--------------------------------------------------------------------------%
    % drawing
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    EDGE_all_x_show=reshape(EDGE_all_x,[],1);
    Ex_show = Exyz(EDGE_all_x_show);
    Ex_show = full(Ex_show);
    Ex_show = reshape(Ex_show,NX,NY+1,NZ+1);
    
    EDGE_all_y_show=reshape(EDGE_all_y,[],1);
    Ey_show = Exyz(EDGE_all_y_show);
    Ey_show = full(Ey_show);
    Ey_show = reshape(Ey_show,NY,NX+1,NZ+1);
    
    EDGE_all_z_show=reshape(EDGE_all_z,[],1);
    Ez_show = Exyz(EDGE_all_z_show);
    Ez_show = full(Ez_show);
    Ez_show = reshape(Ez_show,NX+1,NY+1,NZ);
    %--------------------------------------------------------------------------%
    Ez_show_2D_XY=reshape(Ez_show(:,:,round((NZ+1)/2)),NX+1,NY+1);
    Ez_show_2D_XY=Ez_show_2D_XY.';
    
    Ez_show_2D_YZ=reshape(Ez_show(round((NX+1+1)/2),:,:),NY+1,NZ);
    Ez_show_2D_YZ=Ez_show_2D_YZ.';
    
    Ez_show_2D_XZ=reshape(Ez_show(:,round((NY+1+1)/2),:),NX+1,NZ);
    Ez_show_2D_XZ=Ez_show_2D_XZ.';
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    figure;
    
    subplot(3,1,1)
    %     surf([cumsum(DX)]-diff([0,cumsum(DX)])/2,[0,cumsum(DZ)],abs(Ex_secondary_show_2D_XZ));
    surf(abs(Ez_show_2D_XY));
    colormap jet
    colorbar
    xlabel('x(m)')
    ylabel('y(m)')
    % set(gca,'zscale','log')
    set(gca,'Linewidth',1.0,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    axis tight
    axis ij
    title(['The Ez filed-',num2str(freq(nf)),'Hz'])
    
    subplot(3,1,2)
    %     surf([0,cumsum(DY)],[0,cumsum(DZ)],abs(Ex_secondary_show_2D_YZ));
    surf(abs(Ez_show_2D_YZ));
    colormap jet
    colorbar
    xlabel('y(m)')
    ylabel('z(m)')
    % set(gca,'zscale','log')
    set(gca,'Linewidth',1.0,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    axis tight
    axis ij
    title(['The Ez filed-',num2str(freq(nf)),'Hz'])
    
    subplot(3,1,3)
    %     surf([cumsum(DX)]-diff([0,cumsum(DX)])/2,[0,cumsum(DZ)],abs(Ex_secondary_show_2D_XZ));
    surf(abs(Ez_show_2D_XZ));
    colormap jet
    colorbar
    xlabel('x(m)')
    ylabel('z(m)')
    % set(gca,'zscale','log')
    set(gca,'Linewidth',1.0,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    axis tight
    axis ij
    title(['The Ez filed-',num2str(freq(nf)),'Hz'])
    
    %--------------------------------------------------------------------------%
    
    [X,Y,Z]=meshgrid(1:NY+1,1:NX,1:NZ+1);
    
    figure;
    slice(X,Y,Z,abs(log10(Ex_show)),[round((NY+1)/2)],[round((NX+1)/2)],[round(NZ/2)])
    view(-100,15)
    xlabel('y axis')
    ylabel('x axis')
    title('Ex-Total Field')
    set(gca,'zdir','reverse')
    colorbar
    colormap jet
    set(gca,'Linewidth',1.0,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    % saveas(gcf,[strrep(['The Ex-Total Field at ',num2str(freq(nf)),'Hz' ],'.','dot'),'.fig'])
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    
    figure;
    slice(abs(log10(Ey_show)),[round(NX/2)],[round(NY/2)],[round(NZ/2)])
    title('Ey-Total Field')
    set(gca,'zdir','reverse')
    xlabel('x axis')
    ylabel('y axis')
    colorbar
    colormap jet
    set(gca,'Linewidth',1.0,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    % saveas(gcf,[strrep(['The Ey-Total Field at ',num2str(freq(nf)),'Hz' ],'.','dot'),'.fig'])
    %--------------------------------------------------------------------------%
    
    figure;
    slice(abs(log10(Ez_show)),[round(NY/2)],[round(NX/2)],[round(NZ/2)])
    title('Ez-Total Field')
    set(gca,'zdir','reverse')
    xlabel('y axis')
    ylabel('x axis')
    colorbar
    colormap jet
    set(gca,'Linewidth',1.0,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    % saveas(gcf,[strrep(['The Ez-Total Field at ',num2str(freq(nf)),'Hz' ],'.','dot'),'.fig'])
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    Ez_numerical=reshape(Ez_show(round((NX+1+1)/2),:,round((NZ+1)/2)),[],1);
    
    load Ez_Grid_Extension
    
    %---------------------------------------------%
    %---------------------------------------------%
    gcf=figure;
    set(gcf,'unit','centimeters','position',[1 1 14 9]); % unit:cm
    % set(gca,'Position',[0.17,0.22,0.75,0.70])
    
    p1=plot(y_axis,abs(Ez_numerical),'-o','Markersize',8,'Linewidth',1.5);
    hold on
    p2=plot(y_axis_Grid_Extension,abs(Ez_Grid_Extension),'-+','Linewidth',1.5);
    hold on
    p3=plot(R((end+1)/2+1:end),abs(Ez_analysis((end+1)/2+1:end)),'b-.*','Linewidth',1.0);
    hold off
    
    text(y_axis(NPML_Y/2+1),0.6*max(max(max(abs(Ez_show)))),'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',10)
    text(y_axis(end-NPML_Y/2),0.6*max(max(max(abs(Ez_show)))),'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',10)
    
    line([y_axis(NPML_Y+1),y_axis(NPML_Y+1)],[0,1.2*max(abs(Ez_numerical))],'color','k','Linewidth',1.5)
    line([y_axis(end-NPML_Y),y_axis(end-NPML_Y)],[0,1.2*max(abs(Ez_numerical))],'color','k','Linewidth',1.5)
    
    legend([p1 p2 p3],{'PML Method','Grid Extension','Analytic Solution'},'Location','northwest','FontSize',10)
    legend('boxoff')
    
    xlabel('r(m)');ylabel('Electric Field(V/m)');
    set(gca,'Linewidth',1.0,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    xlabel('y-axis');ylabel('Magnitude');title(['Ex Total Field in y direction','-',num2str(freq(nf)),'Hz'])
    xlim([min(y_axis),max(y_axis)])
    ylim([0,1.2*max(abs(Ez_numerical))])
    
    saveas(gcf,['Comparision-PML Method-Grid Extension',num2str(freq(nf)),'Hz','.fig'])
    
    %--------------------------------------------------%
    %--------------------------------------------------%
    
    
    %---------------------------------------------%
    gcf=figure;
    set(gcf,'unit','centimeters','position',[10 10 8.7 5.5]);% Unit:centimeter
    
    Na=20; % only show the node data of right Na th nodes
    
    p1=plot(y_axis((end+1)/2+Na:end),abs(Ez_numerical((end+1)/2+Na:end)),'r-.o','Markeredgecolor','k','Markerfacecolor','k','Markersize',2,'Linewidth',0.8);
    hold on
    %     p2=plot(y_axis_Grid_Extension((end+1)/2+Na:end-NPML_Y_Grid_Extension),abs(Ez_Grid_Extension((end+1)/2+Na:end-NPML_Y_Grid_Extension)),'b--o','Markersize',5,'Linewidth',0.8);
    p2=plot(y_axis_Grid_Extension((end+1)/2+Na:end),abs(Ez_Grid_Extension((end+1)/2+Na:end)),'b--o','Markersize',4.5,'Linewidth',0.8);
    hold off
    line([sum(DY(1:end-NPML_Y))-sum(DY)/2,sum(DY(1:end-NPML_Y))-sum(DY)/2],[0,max(abs(Ez_numerical((end+1)/2+Na:end)))],'color','k','Linewidth',0.8);
    
    legend([p1 p2],{'PML Method','Grid Extension'},'location','north')
    legend('boxoff')
    
    %     xlim([y_axis((end+1)/2+Na),max(y_axis)]);ylim([0,max(abs(Ez_numerical((end+1)/2+Na:end)))])
    xlim([0.2,0.3+12*0.002]);set(gca,'xtick',0.2:0.02:0.3+12*0.002)
    ylim([0,10]);set(gca,'ytick',0:2:10)
    
    text(y_axis(end-NPML_Y/2),max(abs(Ez_numerical((end+1)/2+Na:end)))/2,'PML','HorizontalAlignment','center','FontName','Times new roman','FontSize',10)
    %     set(gca,'xtick',0.1:0.05:0.4)
    %     set(gca,'ytick',0:20:80)
    
    % title(['Electrical Field-',num2str(freq(nf)),'Hz'],'FontName','Times new roman','FontSize',20)
    xlabel('r(m)');ylabel('Electric Field(V/m)');
    set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10);
    saveas(gcf,['Comparision-PML Method-Grid Extension',num2str(freq(nf)),'Hz','.fig'])
    print(['Comparision-PML Method-Grid Extension','.tif'],'-dtiffn','-r300')
    %--------------------------------------------------%
    %--------------------------------------------------%
    Relative_Error=abs(abs(Ez_numerical((end+1)/2+Na:end-NPML_Y))-abs(Ez_Grid_Extension((end+1)/2+Na:end-NPML_Y_Grid_Extension)))./abs(Ez_Grid_Extension((end+1)/2+Na:end-NPML_Y_Grid_Extension));
    
    gcf=figure;
    set(gcf,'unit','centimeters','position',[10 10 8.7 5.5]);% Unit:centimeter
    
    plot(y_axis((end+1)/2+Na:end-NPML_Y),Relative_Error,'r-.o','Markeredgecolor','k','Markerfacecolor','k','Markersize',2,'Linewidth',0.8)
    % axis tight
    xlabel('r(m)');ylabel('Relative Error');
    set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10);
    
    saveas(gcf,['Relative-Error-in-Scientific-Notation-PML Method-Grid Extension',num2str(freq(nf)),'Hz','.fig'])
    print(['Relative-Error-in-Scientific-Notation-PML Method-Grid Extension',num2str(freq(nf)),'Hz','.tif'],'-dtiffn','-r300')
    %--------------------------------------------------%
    gcf=figure;
    set(gcf,'unit','centimeters','position',[10 10 8.7 5.5]);% Unit:centimeter
    
    plot(y_axis((end+1)/2+Na:end-NPML_Y),20*log10(Relative_Error),'r-.o','Markeredgecolor','k','Markerfacecolor','k','Markersize',2,'Linewidth',0.8)
    % axis tight
    ylim([-60,-50])
    xlim([0.2,0.3])
    xlabel('r(m)');ylabel('Relative Error(dB)');
    set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10);
    
    saveas(gcf,['Relative-Error-in-dB-PML Method-Grid Extension',num2str(freq(nf)),'Hz','.fig'])
    print(['Relative-Error-in-dB-PML Method-Grid Extension',num2str(freq(nf)),'Hz','.tif'],'-dtiffn','-r300')
    %--------------------------------------------------%
    
    
end

save workspace




