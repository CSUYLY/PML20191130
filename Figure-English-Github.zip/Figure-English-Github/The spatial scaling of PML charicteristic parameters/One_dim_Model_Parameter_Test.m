%-------------------------------------------------------------------------%
% This code is used to show the spatial distribution of characteristic
% parameters in PML
%-------------------------------------------------------------------------%
%                             Nov. 29, 2019
%                       Liangyong Yang (PhD student)
%     Institute of Geology and Geophysics, Chinese Academy of Sciences
%                Emails: yangliangyong15@mails.ucas.ac.cn
%-------------------------------------------------------------------------%
%                          ������ (�ڶ���ʿ�о���)
%                      �й���ѧԺ��������������о���
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%

clc;
clear;
close all

NM=100;                             % Number of cells in the simulation region
NPML=12;                            % Number of cells in the each side PML region
NE=NPML+NM+NPML;                    % Total number of cells
NP=NE+1;                            % Total number of nodes
DZ=20*ones(1,NE);                   % length of each cell

%---------------------------------%
find_kappa=-1.040;                    % The optimal value of kappa
find_sigma=2.0240;                    % The optimal value of sigma
find_alpha=1.6120;                    % The optimal value of alpha
%---------------------------------%
z_axis=[0,cumsum(DZ)]-sum(DZ)/2;      % The coordinates of z direction

eps0=1/(36*pi)*1e-9;                  % Vacuum permittivity
eps1=1;                               % Relative permittivity
miu=4*pi*1e-7;                        % Magnetic permeability
%---------------------------------%
J0=1;                                 % Current magnitude
%---------------------------------%
%---------------------------------%
rho=1000*ones(1,NE);                  % The background Resistivity
sigma=1./rho;                         % The background Conductivity
%---------------------------------%
freq= logspace(-3,3,7);               % The frequency range
%---------------------------------%
% Storage the node number of cell
ME=zeros(2,NE);

for i=1:NE
    ME(1,i)=i;
    ME(2,i)=i+1;
end
%---------------------------------%

t1=ME([1;2;1;2],:);  % faster than 'repmat'
t2=ME([1;1;2;2],:);

% The element stiffness matrix or mass matrix of cell
K1e_temp=[1,-1;-1,1];
K1e_temp=reshape(K1e_temp,4,1);
K1e_par(:,1:NE)=K1e_temp./DZ(1:NE);
% The element stiffness matrix or mass matrix of cell
K2e_temp=[1/3,1/6;1/6,1/3];
K2e_temp=reshape(K2e_temp,4,1);
K2e_par(:,1:NE)=K2e_temp.*DZ(1:NE);
%--------------------------------------%
%--------------------------------------%
% PML Method
%--------------------------------------%
Ex=zeros(NP,length(freq)); %Initialization  matrix of electric field

r_distance=z_axis((length(z_axis)+1)/2:end-NPML); % z range of calcaluting analytic solution
E_analysis=zeros(length(r_distance),length(freq));
%--------------------------------------%

for nf=1:length(freq)
    
    f=freq(nf);
    w=2*pi*f; % Angular frequency
    
    %--------------------------------------%
    %--------------------------------------%
    %--------------------------------------%
    m=1;
    sigma_max = find_sigma*miu*sqrt(miu/eps0)/DZ(end);  % Maximum sigma value in PML
    kappa_max = find_kappa;                         % Maximum kappa value in PML
    alpha_max = find_alpha;                         % *freq(nf)^(-0.5); %Maximum alpha value in PML, it needs to be greater than 0, and need to be multiplied by freq(nf)^(-0.5) when there is a Direchlet condition.
    %--------------------------------------%
    
    zekappa = ones(1,NE);                           % Initialize the matrix
    zesigma = zeros(1,NE);                          % Initialize the matrix
    zealpha = zeros(1,NE);                          % Initialize the matrix
    
    for i=1:NPML    % The left side PML
        distance=(NPML+0.5-i)/NPML;                     % Normalized distance
        zesigma(1,i)=sigma_max*(exp(m*distance)-1);     % Exponential spatial scaling
        zekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
        zealpha(1,i)=alpha_max*(exp(m*(1-distance))-1); % The one is different from above zekappa and zesigma
        % zesigma(1,i)=sigma_max*(distance)^m;          % Linear spatial scaling
        % zekappa(1,i)=1+kappa_max*(distance)^m;
        % zealpha(1,i)=alpha_max*((1-distance))^m;
    end
    
    for i=NPML+NM+1:NE     % The right side PML
        distance=(i-0.5-(NPML+NM))/NPML;                % Normalized distance
        zesigma(1,i)=sigma_max*(exp(m*distance)-1);     % Exponential spatial scaling
        zekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
        zealpha(1,i)=alpha_max*(exp(m*(1-distance))-1); % The one is different from above zekappa and zesigma
        % zesigma(1,i)=sigma_max*(distance)^m;          % Linear spatial scaling
        % zekappa(1,i)=1+kappa_max*(distance)^m;
        % zealpha(1,i)=alpha_max*((1-distance))^m;
    end
    
    Sez_origin = zekappa+(sqrt(2)*zesigma./((zealpha+1i).*sqrt(w*eps0.*sigma))); % Construct the key PML parameter
    %--------------------------------------%
    %--------------------------------------%
    figure;
    
    subplot(4,1,1)
    plot(zekappa,'r-o','Linewidth',1,'Markersize',2)
    xlabel('n-th cell')
    title(['zekappa','-',num2str(freq(nf)),' Hz'])
    axis tight
    
    subplot(4,1,2)
    plot(zesigma,'b-o','Linewidth',1,'Markersize',2)
    xlabel('n-th cell')
    title(['zesigma','-',num2str(freq(nf)),' Hz'])
    axis tight
    
    subplot(4,1,3)
    plot(zealpha,'m-o','Linewidth',1,'Markersize',2)
    xlabel('n-th cell')
    title(['zealpha','-',num2str(freq(nf)),' Hz'])
    axis tight
    
    
    AA=sqrt(w*miu*sigma/2).*zekappa+sqrt(miu/eps0)*zesigma.*(zealpha-1)./(zealpha.^2+1);
    subplot(4,1,4)
    plot(AA,'-o','color',[0.67 0   1],'Linewidth',1,'Markersize',2)
    xlabel('n-th cell')
    title(['sqrt(w*miu*sigma/2).*zekappa+sqrt(miu/eps0)*zesigma.*(zealpha-1)./(zealpha.^2+1)','-',num2str(freq(nf)),' Hz'])
    axis tight
    %---------------Build K1e--------------%
    
    K1e=(1./Sez_origin(1:NE)).*K1e_par;
    K1=sparse(t1,t2,K1e,NP,NP); % Build K1 Matrix of finite element method; [The 'sparse' is very fast than tradition 'for' loop, very recommended!]
    
    %---------------Build K2e--------------%
    
    K2e=Sez_origin(1:NE).*(-w*w*miu*eps0+1i*w*miu*sigma).*K2e_par;
    K2=sparse(t1,t2,K2e,NP,NP); % Build K2 Matrix of finite element method; [The 'sparse' is very fast than tradition 'for' loop, very recommended!]
    
    %--------------------------------------%
    %---------------Build K3e--------------%
    K3=sparse(NP,NP);
    
    %------------Assembly matrix-----------%
    v=K1+K2+K3;
    %--------------------------------------%
    P=sparse(NP,1);
    P(round(NP/2))=-(1i*w*miu)*(J0); % Add the current source at the center of simulation region
    %--------------------------------------%
    % This Method is slow
    % Set the perfect electrical conductor at the both outmost side
    %             P(1)=0;
    %             v(:,1)=0;v(1,:)=0;v(1,1)=1;
    %
    %             P(NP)=0;
    %             v(:,NP)=0;v(NP,:)=0;v(NP,NP)=1;
    %--------------------------------------%
    % Set the perfect electrical conductor at the both outmost side
    % This method is fast
    Bid=[1,NP];
    for i=1:length(Bid)
        v(Bid(i),Bid(i))=v(Bid(i),Bid(i))*10^10;
        P(Bid(i))=v(Bid(i),Bid(i))*0;
    end
    %---------------------------------------------------%
    %---------------------------------------------------%
    Ex(:,nf)=v\P; % Compute the electric field
    %---------------------------------------------------%
    % Compute the analytical solution
    Z=sqrt(1i*w*miu*rho(1));
    k=sqrt(-1i*w*miu*sigma(1));
    
    E_analysis(:,nf)=-1*(Z/2)*J0*exp(-1i*k*r_distance);  % Current and electric field have opposite directions
    %---------------------------------------------------%
    % Calculate the relative error
    Exs_FEM=Ex((size(Ex,1)+1)/2:end-NPML,nf); % Only the right side of the current source is considered
    
    Relative_Error=abs(abs(Exs_FEM)-abs(E_analysis(:,nf)))./max(abs(E_analysis(:,nf))); % compute the the relative error
    %---------------------------------------------------%
    figure
    subplot(2,1,1)
    % plot the comparison of the solution of the FEM with PML, and the analytical solution
    p1=plot(z_axis((length(z_axis)+1)/2:end),abs(Ex((size(Ex,1)+1)/2:end,nf)),'-.','Linewidth',1);
    hold on
    p2=plot(r_distance,abs(E_analysis(:,nf)),':','Linewidth',1);
    hold off
    
    axis tight
    
    ylim([0,1.2*max(abs((Ex(:,nf))))])
    line([sum(DZ(1:NPML+NM))-sum(DZ)/2,sum(DZ(1:NPML+NM))-sum(DZ)/2],[0,1.2*max(abs((Ex(:,nf))))],'color','k')
    
    legend([p1 p2],{'PML Method','Analytical Solution'},'Location','southwest','NumColumns',1,'FontSize',10)
    legend('boxoff')
    
    text(sum(DZ(1:NPML+round(0.75*NM)))-sum(DZ)/2,max(abs((Ex(:,nf))))/2,'Model Region','HorizontalAlignment','center','FontName','Times new roman','FontSize',10)
    text(sum(DZ(1:NPML+NM+round(NPML/2)))-sum(DZ)/2,max(abs((Ex(:,nf))))/2,'PML Region','HorizontalAlignment','center','FontName','Times new roman','FontSize',10)
    
    title([num2str(freq(nf)),'Hz'])
    xlabel('r(m)');ylabel('Magnitude(V/m)');
    set(gca,'Linewidth',1.5,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    
    subplot(2,1,2)
    % plot the relative error
    plot(r_distance,20*log10(Relative_Error),'Linewidth',1)
    
    text(mean(r_distance),(min(20*log10(Relative_Error))+max(20*log10(Relative_Error)))/2,'Model Region','HorizontalAlignment','center','FontName','Times new roman','FontSize',10)
    xlabel('r(m)');ylabel('Relative Error (dB)');
    set(gca,'Linewidth',1.5,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    
end


