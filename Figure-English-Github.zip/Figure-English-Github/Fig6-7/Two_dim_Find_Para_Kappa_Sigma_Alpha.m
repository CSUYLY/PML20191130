%-------------------------------------------------------------------------%
% This code is used to find the optimal characteristic parameters of PML 
% for 2D radiation problems.
%-------------------------------------------------------------------------%
%                             Nov. 29, 2019
%                       Liangyong Yang (PhD student)
%     Institute of Geology and Geophysics, Chinese Academy of Sciences
%                Emails: yangliangyong15@mails.ucas.ac.cn
%-------------------------------------------------------------------------%
%                          ������ (�ڶ���ʿ�о���)
%                      �й���ѧԺ��������������о���
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%


clc;
clear;
close all
warning off
tic;
disp('PML��')

J0=1;

tic;
%--------------------------------------------------------------------------%
% kappa����,sigma����,alpha����ֱ�Ϊ��
%      7     7     7
% 
% �Ƽ�kappaΪ��
%      3
% 
% �Ƽ�sigmaΪ��
%     1.2600
% 
% �Ƽ�alphaΪ��
%     1.0600
% 
% ��С���Ϊ��
%    3.0038e-05
% 
% ��С���(dB)Ϊ��
%   -90.4466
%--------------------------------------------------------------------------%

% find_kappa_range=linspace(-8,8,6);
% find_sigma_range=linspace(0.1,10,6);
% find_alpha_range=linspace(0.1,10,6);

find_kappa_range=linspace(-3,15,19);
find_sigma_range=linspace(0.7,2.1,16);
find_alpha_range=linspace(0.1,2.5,16);

%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%

NY_Model=200;
NZ_Model=200;
NPML_Y=12;
NPML_Z=12;

NY=NPML_Y+NY_Model+NPML_Y;
NZ=NPML_Z+NZ_Model+NPML_Z;
DY=0.005*ones(1,NY);
DZ=0.005*ones(1,NZ);

DY(1:NPML_Y)=0.005;
DY(end-NPML_Y+1:end)=0.005;

DZ(1:NPML_Z)=0.005;
DZ(end-NPML_Z+1:end)=0.005;
%--------------------------------------------------------------------------%
y_axis=[0,cumsum(DY)]-sum(DY)/2;
z_axis=[0,cumsum(DZ)]-sum(DZ)/2;
%--------------------------------------------------------------------------%

freq=[1e4,1e6]; %logspace(4,7,4);

NYP=NY+1;            % Y����ڵ�����
NZP=NZ+1;            % Z����ڵ�����
NP=(NY+1)*(NZ+1);    % �ڵ�����
NE=NY*NZ;            % ��Ԫ����
ME=zeros(4,NE);      % �����ڴ�%�ֲ���Ŷ�Ӧ��ȫ�ֱ��
%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
rho=5*ones(NZ,NY); % the resistivity of seawater or copper!

sigma=1./rho;
%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
rho=reshape(rho,1,NE);

%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
eps0=1/(36*pi)*1e-9;
miu=4*pi*1e-7;

%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
for IY=1:NY   %���ÿ����Ԫ�ľֲ��������Ӧ��ȫ�ֱ��
    for IZ=1:NZ
        N=(IY-1)*NZ+IZ;  %��Ԫ���
        N1=(IY-1)*(NZ+1)+IZ;  %��N����Ԫ���Ͻǵ�ȫ�ֱ��
        ME(1,N)=N1;
        ME(2,N)=N1+1;
        ME(3,N)=N1+1+NZ+1;
        ME(4,N)=N1+NZ+1;
    end
end
t1=ME([1;2;3;4;1;2;3;4;1;2;3;4;1;2;3;4],:); %��repmat����
t2=ME([1;1;1;1;2;2;2;2;3;3;3;3;4;4;4;4],:);


% ÿ����Ԫ����Ӧ��DY��DZ�����
n_DZ=repmat((1:NZ),1,NY);
n_DY=repmat((1:NY),NZ,1);
n_DY=reshape(n_DY,1,NE);

%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
K1e_temp_1=[2,1,-1,-2;1,2,-2,-1;-1,-2,2,1;-2,-1,1,2];
K1e_temp_2=[2,-2,-1,1;-2,2,1,-1;-1,1,2,-2;1,-1,-2,2];
K1e_par1=reshape(K1e_temp_1,16,1);
K1e_par2=reshape(K1e_temp_2,16,1);

% K2e����
K2e_temp=[4,2,1,2;2,4,2,1;1,2,4,2;2,1,2,4];
K2e_par=reshape(K2e_temp,16,1);

%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
Data=zeros(length(find_kappa_range),length(find_sigma_range),length(find_alpha_range));

for n_kappa=1:length(find_kappa_range)
    
    disp(n_kappa)
    
    for n_sigma=1:length(find_sigma_range)
        for n_alpha=1:length(find_alpha_range)
            
            %---------------------------------%
            %---------------------------------%
            find_kappa=find_kappa_range(n_kappa); %
            find_sigma=find_sigma_range(n_sigma); %
            find_alpha=find_alpha_range(n_alpha); %
            %---------------------------------%
            %---------------------------------%
            Relative_Error_nf=zeros(1,size(freq,2));
            %---------------------------------%
            for nf=1:size(freq,2)
                
                %--------------------------------------------------------------------------%
                %--------------------------------------------------------------------------%
                w=2*pi*freq(nf);
                %--------------------------------------------------------------------------%
                %--------------------------------------------------------------------------%
                order=1;
                m=1;
                sigma_max = find_sigma*miu*sqrt(miu/eps0)/DZ(end);
                kappa_max = find_kappa;% 0.6364*1/w;             % kappa���ֵ ,kappaֵ��������Ϊ�˸���PML�Ա��沨����������
                alpha_max = find_alpha; %*freq(nf)^(-0.5);             % 0-0.05�� alphaֵ��Ϊ�˸���PML�Ե�Ƶ�������������ԡ�
                %--------------------------------------------------------------------------%
                yekappa = ones(1,NY);
                yesigma = zeros(1,NY);
                yealpha = zeros(1,NY);
                zekappa = ones(1,NZ);
                zesigma = zeros(1,NZ);
                zealpha = zeros(1,NZ);
                %--------------------------------------------------------------------------%
                for i=1:NPML_Z     % (NP-NPML-1)*ds=(NP-NPML-1)*ds ; ��i=NP-NPMLҲ�൱�ڴ�NP-NPML+1 ;
                    distance=(NPML_Z+0.5-i)/NPML_Z;
                    zesigma(1,i)=sigma_max*(exp(m*distance)-1); %  �������ʵ����(i-50)*ds
                    zekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
                    zealpha(1,i)=alpha_max*(exp(m*(1-distance))-1);
                    %         zesigma(1,i)=sigma_max*(distance)^m;
                    %         zekappa(1,i)=1+kappa_max*(distance)^m;
                    %         zealpha(1,i)=alpha_max*((1-distance))^m;
                end
                for i=NPML_Z+NZ_Model+1:NZ    % (NP-NPML-1)*ds=(NP-NPML-1)*ds ; ��i=NP-NPMLҲ�൱�ڴ�NP-NPML+1 ;
                    distance=(i+0.5-(NPML_Z+NZ_Model+1))/NPML_Z;
                    zesigma(1,i)=sigma_max*(exp(m*distance)-1); %  �������ʵ����(i-50)*ds
                    zekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
                    zealpha(1,i)=alpha_max*(exp(m*(1-distance))-1);
                    %         zesigma(1,i)=sigma_max*(distance)^m;
                    %         zekappa(1,i)=1+kappa_max*(distance)^m;
                    %         zealpha(1,i)=alpha_max*((1-distance))^m;
                end
                for i=1:NPML_Y    % (NP-NPML-1)*ds=(NP-NPML-1)*ds ; ��i=NP-NPMLҲ�൱�ڴ�NP-NPML+1 ;
                    distance=(NPML_Y+0.5-i)/NPML_Y;
                    yesigma(1,i)=sigma_max*(exp(m*distance)-1); %  �������ʵ����(i-50)*ds
                    yekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
                    yealpha(1,i)=alpha_max*(exp(m*(1-distance))-1);
                    %         yesigma(1,i)=sigma_max*(distance)^m;
                    %         yekappa(1,i)=1+kappa_max*(distance)^m;
                    %         yealpha(1,i)=alpha_max*((1-distance))^m;
                end
                for i=NPML_Y+NY_Model+1:NY    % (NP-NPML-1)*ds=(NP-NPML-1)*ds ; ��i=NP-NPMLҲ�൱�ڴ�NP-NPML+1 ;
                    distance=(i+0.5-(NYP-NPML_Y))/NPML_Y;
                    yesigma(1,i)=sigma_max*(exp(m*distance)-1); %  �������ʵ����(i-50)*ds
                    yekappa(1,i)=1+kappa_max*(exp(m*distance)-1);
                    yealpha(1,i)=alpha_max*(exp(m*(1-distance))-1);
                    %         yesigma(1,i)=sigma_max*(distance)^m;
                    %         yekappa(1,i)=1+kappa_max*(distance)^m;
                    %         yealpha(1,i)=alpha_max*((1-distance))^m;
                end
                %--------------------------------------------------------------------------%
                
                %--------------------------------------------------------------------------%
                yekappa=repmat(yekappa,NZ,1);
                yesigma=repmat(yesigma,NZ,1);
                yealpha=repmat(yealpha,NZ,1);
                
                zekappa=repmat(zekappa',1,NY);
                zesigma=repmat(zesigma',1,NY);
                zealpha=repmat(zealpha',1,NY);
                
                Sey_origin=yekappa+(sqrt(2)*yesigma./((yealpha+1i).*sqrt(w*eps0*sigma)));
                Sez_origin=zekappa+(sqrt(2)*zesigma./((zealpha+1i).*sqrt(w*eps0*sigma)));
                
                Sey_origin=reshape(Sey_origin,1,NE);
                Sez_origin=reshape(Sez_origin,1,NE);
                %--------------------------------------------------------------------------%
                %--------------------------------------------------------------------------%
                % Sez_origin = ones(1,NE);
                % Sey_origin = ones(1,NE);
                %--------------------------------------------------------------------------%
                alpha=(Sez_origin(1:NE)./Sey_origin(1:NE)).*DZ(n_DZ(1:NE))./(6*DY(n_DY(1:NE)));
                belta=(Sey_origin(1:NE)./Sez_origin(1:NE)).*DY(n_DY(1:NE))./(6*DZ(n_DZ(1:NE)));
                K1e=K1e_par1*alpha+K1e_par2*belta;
                K1=sparse(t1,t2,K1e,NP,NP);
                %--------------------------------------------------------------------------%
                AREA=DY(n_DY(1:NE)).*DZ(n_DZ(1:NE));
                lambda=(Sey_origin(1:NE).*Sez_origin(1:NE)).*(-w*w*miu*eps0+1i*w*miu*sigma(1:NE));
                K2e=(K2e_par/36)*(AREA(1:NE).*lambda);  %[�����С��16*NE]
                K2=sparse(t1,t2,K2e,NP,NP); %nzmax��Ĭ�� % S = sparse(i,j,s,m,n,nzmax)��nzmax������ڵ���s��16*NE������Ŀ
                %--------------------------------------------------------------------------%
                %--------------------------------------------------------------------------%
                K3=sparse(NP,NP);
                %--------------------------------------------------------------------------%
                %--------------------------------------------------------------------------%
                K=K1+K2+K3;
                %--------------------------------------------------------------------------%
                %--------------------------------------------------------------------------%
                P=sparse(NP,1);
                
                P((NY+1)*round(NZ/2)+round((NY+1)/2))=-(1i*w*miu)*(J0); % Add the current source at the center of simulation region
                
                %--------------------------------------------------------------------------%
                %--------------------------------------------------------------------------%
                % ����ʩ�ӵ糡
                for n_top=1:(NZ+1):NP
                    K(n_top,n_top)=K(n_top,n_top)*10^10;
                    P(n_top)=0;
                end
                
                % �ײ�PML�����糡����Ϊ0
                for n_top=NZ+1:(NZ+1):NP
                    K(n_top,n_top)=K(n_top,n_top)*10^10;
                    P(n_top)=0;
                end
                
                % ���PML�����糡����Ϊ0
                for n_top=1:NZP
                    
                    K(n_top,n_top)=K(n_top,n_top)*10^10;
                    P(n_top)=0;
                end
                
                % �Ҳ�PML�����糡����Ϊ0
                for n_top=NP-NZP+1:NP
                    K(n_top,n_top)=K(n_top,n_top)*10^10;
                    P(n_top)=0;
                end
                
                %--------------------------------------------------------------------------%
                %--------------------------------------------------------------------------%
                Ex=K\P;  % ��⣬��ó�ֵ
                
                %--------------------------------------------------------------------------%
                %--------------------------------------------------------------------------%
                Ex_show=reshape(Ex,NZ+1,NY+1);
                %-----------------------------------------------------------------%
                %-----------------------------------------------------------------%
                k_wavenumber=sqrt(-1i*w*miu*sigma(1)); % omega*sqrt(eps0*mu0);
                
                r=y_axis((length(y_axis)+1)/2:end);
                Ez_analysis=-1*(J0*w*miu/4)*besselh(0,2,k_wavenumber*r,0);  % Current and electric field have opposite directions
                %-----------------------------------------------------------------%
                
                %-----------------------------------------------------------------%
                %-----------------------------------------------------------------%
                tempA=abs(Ez_analysis(1:end-NPML_Y));
                tempB=abs(Ex_show((end+1)/2:end-NPML_Y,round((NY+1)/2)).');
                
                Relative_Error_PML=abs(tempB-tempA)./max(tempA);
                %-----------------------------------------------------------------%
                %                 figure
                %                 set(gcf,'unit','centimeters','position',[1 1 14 9]);%ͼ�ε�������
                %                 set(gca,'Position',[0.17,0.22,0.75,0.70])
                %
                %                 plot(y_axis((end+1)/2:end-NPML_Y),20*log10(Relative_Error_PML),'k:','Linewidth',1.5)
                %
                %                 xlim([0,0.5])
                %                 set(gca,'xtick',0:0.1:0.5)
                %
                %                 xlabel('y(km)');ylabel('Relative Error(dB)')
                %                 set(gca,'Linewidth',1.5,'FontName','Times new roman','FontSize',20);
                
                %-----------------------------------------------------------------%
                %-----------------------------------------------------------------%
                
                Relative_Error_nf(nf)=max(Relative_Error_PML(end/2:end));
                % ����
                % Relative_Error_nf(nf)=max(Relative_Error_PML(1:end));
            end
            
            Data(n_kappa,n_sigma,n_alpha)=max(Relative_Error_nf);
            
            
        end
    end
end



min_x=min(Data(:));%������άά����x����Сֵ

s=size(Data);%������άά����Ĵ�С

Lin=find(Data<=min_x);%������Сֵλ�õĵ��±�

[i,j,k]=ind2sub(s,Lin);%����Сֵ���±�תΪ��ά���±�

Loc_in=[i,j,k];%��Сֵλ���±�

disp('---------------------------------------------------------------------');
disp('kappa����,sigma����,alpha����ֱ�Ϊ��');disp([i,j,k]);
disp('�Ƽ�kappaΪ��');disp(find_kappa_range(i))
disp('�Ƽ�sigmaΪ��');disp(find_sigma_range(j))
disp('�Ƽ�alphaΪ��');disp(find_alpha_range(k))
disp('��С���Ϊ��');disp(min_x);
disp('��С���(dB)Ϊ��');disp(20*log10(min_x));
disp('---------------------------------------------------------------------');

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
[x,y,z]=meshgrid(find_sigma_range,find_kappa_range,find_alpha_range);

figure
set(gcf,'unit','centimeters','position',[1 1 14 12]);%ͼ�ε�������
% slice(x,y,z,20*log10(Data),find_sigma_range(j),find_kappa_range(i),find_alpha_range(k),'EdgeColor','none');
h=slice(x,y,z,20*log10(Data),find_sigma_range(j),find_kappa_range(i),find_alpha_range(k));
set(h,'FaceColor', 'interp', 'EdgeColor', 'none');
colorbar;
% colormap jet
xlabel('\sigma');ylabel('\kappa');zlabel('\alpha')
% xlabel('sigma');ylabel('kappa');zlabel('alpha')
% set(gca,'Xtick',0:1:4)
set(gca,'Fontname','Times new roman','Fontsize',20)

saveas(gcf,['Output_Find_Para_alpha_sigma_kappa','.fig'])
 print(['Output_Find_Para_alpha_sigma_kappa','.tif'],'-dtiffn','-r300')
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%

toc;

%-----------------------------------------------------------------%
%-----------------------------------------------------------------%
