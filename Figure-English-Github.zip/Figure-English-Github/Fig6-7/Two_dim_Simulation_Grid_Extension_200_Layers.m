%-------------------------------------------------------------------------%
% This code uses the traditional grid continuation method to calculate the
% finite element solution of the two-dimensional radiation problem. 
% The number of extended grids is 200 layers, and the size of the extended
% grids gradually increases.
% This result provides a reference for the PML method
%-------------------------------------------------------------------------%
%                             Nov. 29, 2019
%                       Liangyong Yang (PhD student)
%     Institute of Geology and Geophysics, Chinese Academy of Sciences
%                Emails: yangliangyong15@mails.ucas.ac.cn
%-------------------------------------------------------------------------%
%                          ������ (�ڶ���ʿ�о���)
%                      �й���ѧԺ��������������о���
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%

clc;
clear;
close all
warning off
tic;
disp('Grid Extension Method')

J0=1;

%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
NY_Model=200;                  % Number of simulation region cells in the y direction
NZ_Model=200;                  % Number of simulation region cells in the z direction
Grid_Extension_Y=200;          % Number of grid extension in the y direction
Grid_Extension_Z=200;          % Number of grid extension in the z direction

NY=NY_Model+2*Grid_Extension_Y;   % Total number of cells in the y direction
NZ=NZ_Model+2*Grid_Extension_Z;   % Total number of cells in the z direction

Grid_Extension=0.005*1.05.^(1:Grid_Extension_Y); % the cell thick of grid extension
disp('---------------------------------')
disp('The total distance of grid extension��')
disp(sum(Grid_Extension))
disp('---------------------------------')

DY=[fliplr(Grid_Extension),0.005*ones(1,NY-2*Grid_Extension_Y),Grid_Extension];   % length of each cell in the y direction
DZ=[fliplr(Grid_Extension),0.005*ones(1,NZ-2*Grid_Extension_Z),Grid_Extension];   % length of each cell in the z direction

%--------------------------------------------------------------------------%
y_axis=[0,cumsum(DY)]-sum(DY)/2;  % The coordinates of y direction
z_axis=[0,cumsum(DZ)]-sum(DZ)/2;  % The coordinates of z direction
%--------------------------------------------------------------------------%
freq=[1e4,1e6]; %logspace(4,7,4); % The frequency range

NYP=NY+1;            % Total node number in y direction
NZP=NZ+1;            % Total node number in z direction
NP=(NY+1)*(NZ+1);    % Total node number of simulation
NE=NY*NZ;            % Total cell(element) number of simulation
ME=zeros(4,NE);      % Allocate memory % Global node number corresponding to Local node number
%--------------------------------------------------------------------------%
rho=5*ones(NZ,NY);   % the resistivity of seawater or copper!

sigma=1./rho;        % Conductivity
%--------------------------------------------------------------------------%
disp('---------------------------------')
disp('Skin Depth of each frequency:')
disp(num2str(503*sqrt(rho(1)./freq)))
disp('---------------------------------')
%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
rho=reshape(rho,1,NE);        % Convert to vector
%--------------------------------------------------------------------------%
eps0=1/(36*pi)*1e-9;          % Vacuum permittivity
miu=4*pi*1e-7;                % Magnetic permeability
%--------------------------------------------------------------------------%
% The ratio of Conduction current to Displacement current
rate=mean(mean(sigma))./(2*pi*freq*eps0);
disp('---------------------------------')
disp('Conduction current/Displacement current:');
disp(rate);
disp('---------------------------------')
%--------------------------------------------------------------------------%
% %Find the global node number corresponding to the local node number of each cell
for IY=1:NY
    for IZ=1:NZ
        N=(IY-1)*NZ+IZ;        % cell(element) number
        N1=(IY-1)*(NZ+1)+IZ;   % Global number of the top left corner of the Nth cell
        ME(1,N)=N1;            % the Global number of the top-left corner of the Nth cell
        ME(2,N)=N1+1;          % the Global number of the bottom-left corner of the Nth cell
        ME(3,N)=N1+1+NZ+1;     % the Global number of the bottom-right corner of the Nth cell
        ME(4,N)=N1+NZ+1;       % the Global number of the top-right corner of the Nth cell
    end
end

t1=ME([1;2;3;4;1;2;3;4;1;2;3;4;1;2;3;4],:); % faster than 'repmat'
t2=ME([1;1;1;1;2;2;2;2;3;3;3;3;4;4;4;4],:);

% Location of each cell
n_DZ=repmat((1:NZ),1,NY);
n_DY=repmat((1:NY),NZ,1);
n_DY=reshape(n_DY,1,NE);

%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
% The element stiffness matrix or mass matrix of cell
K1e_temp_1=[2,1,-1,-2;1,2,-2,-1;-1,-2,2,1;-2,-1,1,2];
K1e_temp_2=[2,-2,-1,1;-2,2,1,-1;-1,1,2,-2;1,-1,-2,2];
K1e_par1=reshape(K1e_temp_1,16,1);
K1e_par2=reshape(K1e_temp_2,16,1);
%--------------------------------------------------------------------------%
% The element stiffness matrix or mass matrix of cell
K2e_temp=[4,2,1,2;2,4,2,1;1,2,4,2;2,1,2,4];
K2e_par=reshape(K2e_temp,16,1);
%--------------------------------------------------------------------------%
%--------------------------------------------------------------------------%
Ex_Grid_Extension=zeros(length(freq),NY+1);   % Initialization matrix
%--------------------------------------------------------------------------%

for nf=1:length(freq)
    
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    w=2*pi*freq(nf);
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    Sez_origin = ones(1,NE);
    Sey_origin = ones(1,NE);
    %--------------------------------------------------------------------------%
    %-----------Build K1e------------------------------------------------------%
    alpha=(Sez_origin(1:NE)./Sey_origin(1:NE)).*DZ(n_DZ(1:NE))./(6*DY(n_DY(1:NE)));
    belta=(Sey_origin(1:NE)./Sez_origin(1:NE)).*DY(n_DY(1:NE))./(6*DZ(n_DZ(1:NE)));
    K1e=K1e_par1*alpha+K1e_par2*belta;
    K1=sparse(t1,t2,K1e,NP,NP);% Build K1 Matrix of finite element method; [The 'sparse' is very fast than tradition 'for' loop, very recommended!]
    %-----------Build K2e------------------------------------------------------%
    AREA=DY(n_DY(1:NE)).*DZ(n_DZ(1:NE));
    lambda=(Sey_origin(1:NE).*Sez_origin(1:NE)).*(-w*w*miu*eps0+1i*w*miu*sigma(1:NE));
    K2e=(K2e_par/36)*(AREA(1:NE).*lambda); %[matrix size: 16*NE]
    K2=sparse(t1,t2,K2e,NP,NP);  % S = sparse(i,j,s,m,n,nzmax)<= you can find function 'sparse' for details in Matlab website
    %--------------------------------------------------------------------------%
    %-----------Build K3e------------------------------------------------------%
    K3=sparse(NP,NP);
    %--------------------------------------------------------------------------%
    %-----------Assembly Matrix------------------------------------------------%
    K=K1+K2+K3;
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    P=sparse(NP,1);
    
    P((NY+1)*round(NZ/2)+round((NY+1)/2))=-(1i*w*miu)*(J0); % Add the current source at the center of simulation region
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    % Force the top outer boundary electric field equal to 0 (PEC boundary condition)
    for n_top=1:(NZ+1):NP
        K(n_top,n_top)=K(n_top,n_top)*10^10;
        P(n_top)=0;
    end
    
    % Force the bottom outer boundary electric field equal to 0 (PEC boundary condition)
    for n_top=NZ+1:(NZ+1):NP
        K(n_top,n_top)=K(n_top,n_top)*10^10;
        P(n_top)=0;
    end
    
    % Force the left outer boundary electric field equal to 0 (PEC boundary condition)
    for n_top=1:NZP
        
        K(n_top,n_top)=K(n_top,n_top)*10^10;
        P(n_top)=0;
    end
    
    % Force the right outer boundary electric field equal to 0 (PEC boundary condition)
    for n_top=NP-NZP+1:NP
        K(n_top,n_top)=K(n_top,n_top)*10^10;
        P(n_top)=0;
    end
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    Ex=K\P;  %Solve to get the Electric field value
    %--------------------------------------------------------------------------%
    %--------------------------------------------------------------------------%
    Ex_show=reshape(Ex,NZ+1,NY+1);  % convert one-dim vector to two-dim matrix, which is easy to show
    %-----------------------------------------------------------------%
    %-----------------------------------------------------------------%
    % Compute the analytical solution
    k_wavenumber=sqrt(-1i*w*miu*sigma(1)); % omega*sqrt(eps0*mu0);
    
    r=y_axis((length(y_axis)+1)/2:end-Grid_Extension_Y);
    Ez_analysis=-1*(J0*w*miu/4)*besselh(0,2,k_wavenumber*r,0);
    %-----------------------------------------------------------------%
    %-----------------------------------------------------------------%
    figure
    set(gcf,'Position',[100,100,1300,600])
    
    subplot(2,2,1)
    % Plot the y-direction electric field curve through the center of the simulation region
    plot(y_axis(Grid_Extension_Y+1:Grid_Extension_Y+NY_Model+1),abs(Ex_show(round((NZ+1)/2),Grid_Extension_Y+1:Grid_Extension_Y+NY_Model+1)),'--','Linewidth',0.8);
    hold on
    plot(r(2:end),abs(Ez_analysis(2:end)),'-.','Linewidth',0.8)
    legend('Grid Extension','Analytic Solution')
    legend('boxoff')
    xlim([y_axis(Grid_Extension_Y+1),y_axis(Grid_Extension_Y+NY_Model+1)])
    xlabel('y(m)');ylabel('Electric Field(V/m)')
    title(['Frequency: ',num2str(freq(nf)),' Hz'],'FontName','Times new roman','FontSize',10,'FontWeight','bold')
    set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    %-----------------------------------------------------------------%
    %-----------------------------------------------------------------%
    subplot(2,2,3)
    % Plot the z-direction electric field curve through the center of the simulation region
    plot(z_axis(Grid_Extension_Z+1:Grid_Extension_Z+NZ_Model+1),abs(Ex_show(Grid_Extension_Z+1:Grid_Extension_Z+NZ_Model+1,round((NY+1)/2))),'--','Linewidth',0.8);
    hold on
    plot(r(2:end),abs(Ez_analysis(2:end)),'-.','Linewidth',0.8)
    legend('Grid Extension','Analytic Solution')
    legend('boxoff')
    xlim([z_axis(Grid_Extension_Z+1),z_axis(Grid_Extension_Z+NZ_Model+1)])
    xlabel('z(m)');ylabel('Electric Field(V/m)')
    title(['Frequency: ',num2str(freq(nf)),' Hz'],'FontName','Times new roman','FontSize',10,'FontWeight','bold')
    set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    %-----------------------------------------------------------------%
    %-----------------------------------------------------------------%
    [Y,Z]=meshgrid(y_axis(Grid_Extension_Y+1:Grid_Extension_Y+NY_Model+1),z_axis(Grid_Extension_Z+1:Grid_Extension_Z+NZ_Model+1));
    subplot(2,2,2)
    % Plot the electric field curve of the simulated region
    surf(Y,Z,abs(Ex_show(Grid_Extension_Z+1:Grid_Extension_Z+NZ_Model+1,Grid_Extension_Y+1:Grid_Extension_Y+NY_Model+1)),'Edgecolor','none');
    colormap jet
    xlabel('y(m)');ylabel('z(m)');zlabel('Electric Field(V/m)')
    axis tight
    title(['Frequency: ',num2str(freq(nf)),' Hz'],'FontName','Times new roman','FontSize',10,'FontWeight','bold')
    set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    %-----------------------------------------------------------------%
    %-----------------------------------------------------------------%
    % Calculate the relative error of Electric field
    tempA_Analytic=abs(Ez_analysis(2:NY_Model/2+1)); % abs(Ex_Bigmodel(nf,(size(Ex_Bigmodel,2)+1)/2-NY_Model/2:(size(Ex_Bigmodel,2)+1)/2+NY_Model/2));
    tempB_PML=abs(Ex_show((end+1)/2+1:(end+1)/2+NZ_Model/2,round((NY+1)/2)).');
    
    % Relative_Error=abs(tempB_PML-tempA_Analytic)./(tempA_Analytic);
    Relative_Error=abs(tempB_PML-tempA_Analytic)./max(tempA_Analytic);
    
    subplot(2,2,4)
    plot(z_axis((end+1)/2+1:(end+1)/2+NZ_Model/2),20*log10(Relative_Error),'--')
    
    xlabel('z(m)');ylabel('Relative Error(dB)')
    set(gca,'Linewidth',0.8,'FontName','Times new roman','FontSize',10,'FontWeight','bold');
    %-----------------------------------------------------------------%
    %-----------------------------------------------------------------%
    Ex_Grid_Extension(nf,:)=Ex_show(round((NZ+1)/2),:);
    
    
end

%-----------------------------------------------------------------%
%-----------------------------------------------------------------%
% save data for purpose of comparison
y_axis_Grid_Extension=y_axis;
NY_Model_Grid_Extension=NY_Model;

save Data_Grid_Extension Ex_Grid_Extension y_axis_Grid_Extension Grid_Extension_Y NY_Model_Grid_Extension

toc;